package com.mhmmad.coloringpages

import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.*

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[29],application=ColoringApplication::class,qualifiers="en-rGB-w360dp-h640dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class LanguageSwitchTest {
    @get:Rule val rule=createAndroidComposeRule<MainActivity>()
    @Test fun choosingArabicUpdatesTheRunningAppAndSurvivesRecreation(){
        rule.waitUntil(60_000){rule.onAllNodesWithTag("home-screen").fetchSemanticsNodes().isNotEmpty()}
        rule.onNodeWithTag("parent-button").performClick()
        val question=rule.onAllNodes(SemanticsMatcher("arithmetic"){it.config.contains(SemanticsProperties.Text)&&it.config[SemanticsProperties.Text].any{t->Regex("\\d+ × \\d+ = \\?").matches(t.text)}}).fetchSemanticsNodes().first()
        val numbers=Regex("\\d+").findAll(question.config[SemanticsProperties.Text].joinToString(""){it.text}).map{it.value.toInt()}.toList()
        (numbers[0]*numbers[1]).toString().forEach{rule.onNodeWithTag("parent-digit-$it").performClick()}
        rule.onNodeWithTag("parent-enter").performClick()
        rule.onNodeWithTag("language-setting").performScrollTo().performClick()
        rule.onNodeWithTag("language-ar").performClick()
        rule.waitUntil(60_000){
            rule.waitForIdle()
            AppCompatDelegate.getApplicationLocales().toLanguageTags()=="ar"
        }
        rule.activityRule.scenario.recreate()
        rule.waitUntil(60_000){rule.onAllNodesWithTag("home-screen").fetchSemanticsNodes().isNotEmpty()}
        assertEquals("ar",androidx.core.os.ConfigurationCompat.getLocales(rule.activity.resources.configuration).get(0)?.language)
        assertEquals(1,rule.activity.resources.configuration.layoutDirection)
        assertEquals("رسومات تلوين للأطفال",rule.activity.getString(R.string.app_name))
        val app=rule.activity.application as ColoringApplication
        assertEquals("ar",runBlocking{app.preferences.data.first().language})
    }
}
