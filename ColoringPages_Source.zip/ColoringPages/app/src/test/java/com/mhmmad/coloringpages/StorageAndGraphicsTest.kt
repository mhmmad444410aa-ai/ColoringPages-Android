package com.mhmmad.coloringpages

import android.content.Context
import android.content.res.Configuration
import android.graphics.BitmapFactory
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.mhmmad.coloringpages.core.database.*
import com.mhmmad.coloringpages.core.graphics.ArtRenderer
import com.mhmmad.coloringpages.core.model.*
import com.mhmmad.coloringpages.core.preferences.AppPreferences
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.ByteArrayOutputStream
import java.util.Locale

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[29],application=ColoringApplication::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class StorageAndGraphicsTest {
    private val context:Context get()=ApplicationProvider.getApplicationContext()
    @Test fun all72ArtworksHaveUniqueIdsValidPathsAndCorrectHitLabels()=runBlocking {
        val repository=ArtRepository(context)
        assertEquals(72,repository.catalog.size)
        assertEquals(72,repository.catalog.map{it.id}.distinct().size)
        repository.catalog.groupBy{it.category}.values.forEach{assertEquals(12,it.size)}
        var regions=0
        for(art in repository.catalog){
            val drawing=repository.drawing(art.id);val renderer=ArtRenderer(drawing)
            assertEquals(art.regionCount,drawing.regions.size)
            for(region in drawing.regions){
                assertTrue(region.colour in drawing.palette.indices)
                for(label in region.labels){assertEquals("${art.id}/${region.id}",region.id,renderer.hitTest(label.x,label.y)?.id)}
            }
            regions+=drawing.regions.size
        }
        assertTrue(regions>=1800)
    }
    @Test fun pixelExportProducesDecodable1600SquareImage()=runBlocking {
        val art=ArtRepository(context).drawing("flowers_01");val renderer=ArtRenderer(art)
        val colours=art.regions.associate{it.id to it.colour}
        val bytes=ByteArrayOutputStream().apply{assertTrue(renderer.exportPng(this,colours))}.toByteArray()
        val bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.size)
        assertNotNull(bitmap);assertEquals(1600,bitmap.width);assertEquals(1600,bitmap.height)
        assertTrue(bytes.size>5000)
        bitmap.recycle()
    }
    @Test fun savedCompletionAndUndoHistorySurviveClosingTheDatabase()=runBlocking {
        val filename="persist-test.db";context.deleteDatabase(filename)
        val region=ArtRegion("region","",2,emptyList())
        val complete=ColourEngine.paint(ColourSession("flower",ColourMode.NUMBERS),region,2,8,1,123)
        val first=Room.databaseBuilder(context,ArtDatabase::class.java,filename).addMigrations(ArtDatabase.MIGRATION_1_2).build()
        first.artDao().save(ArtRepository.encode(complete),DailyChallengeEntity("2026-11-13","flower",123))
        first.close()
        val second=Room.databaseBuilder(context,ArtDatabase::class.java,filename).addMigrations(ArtDatabase.MIGRATION_1_2).build()
        val recovered=ArtRepository.decode(second.artDao().session(complete.key)!!)
        assertEquals(complete,recovered);assertEquals(1,second.artDao().observeChallenges().first().size)
        assertTrue(ColourEngine.undo(recovered,1,124).colours.isEmpty())
        second.artDao().clearProgress();assertTrue(second.artDao().observeAll().first().isEmpty());assertTrue(second.artDao().observeChallenges().first().isEmpty())
        second.close();context.deleteDatabase(filename);Unit
    }
    @Test fun roomMigrationKeepsExistingColoursAndAddsChallengeTable(){
        val filename="migration-test.db";context.deleteDatabase(filename)
        val sqlite=context.openOrCreateDatabase(filename,Context.MODE_PRIVATE,null)
        sqlite.execSQL("CREATE TABLE sessions (sessionKey TEXT NOT NULL PRIMARY KEY, artId TEXT NOT NULL, mode TEXT NOT NULL, coloursJson TEXT NOT NULL, undoJson TEXT NOT NULL, redoJson TEXT NOT NULL, updatedAt INTEGER NOT NULL, completedAt INTEGER)")
        sqlite.execSQL("INSERT INTO sessions VALUES ('art:NUMBERS','art','NUMBERS','{\"r1\":2}','[]','[]',1,NULL)")
        val wrapped=androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory().create(androidx.sqlite.db.SupportSQLiteOpenHelper.Configuration.builder(context).name(filename).callback(object:androidx.sqlite.db.SupportSQLiteOpenHelper.Callback(2){
            override fun onCreate(db:androidx.sqlite.db.SupportSQLiteDatabase){}
            override fun onUpgrade(db:androidx.sqlite.db.SupportSQLiteDatabase,oldVersion:Int,newVersion:Int){ArtDatabase.MIGRATION_1_2.migrate(db)}
        }).build())
        sqlite.version=1;sqlite.close()
        wrapped.writableDatabase.query("SELECT coloursJson FROM sessions").use{assertTrue(it.moveToFirst());assertEquals("{\"r1\":2}",it.getString(0))}
        wrapped.writableDatabase.query("SELECT * FROM daily_challenges").use{assertEquals(0,it.count)}
        wrapped.close();context.deleteDatabase(filename)
    }
    @Test fun namesAndLayoutDirectionMatchAllThreeLocales(){
        val expected=mapOf("en-GB" to "Coloring Pages","ar" to "رسومات تلوين للأطفال","pt-BR" to "Desenhos para Colorir")
        expected.forEach{(tag,name)->
            val config=Configuration(context.resources.configuration);val locale=Locale.forLanguageTag(tag)
            config.setLocale(locale);config.setLayoutDirection(locale)
            val localized=context.createConfigurationContext(config)
            assertEquals(name,localized.getString(R.string.app_name))
            assertEquals(if(tag=="ar")1 else 0,localized.resources.configuration.layoutDirection)
            assertFalse(localized.getString(R.string.start_colouring).isBlank())
        }
    }
    @Test fun preferencesPersistAllUserChoices()=runBlocking {
        val prefs=AppPreferences(context);prefs.theme("dark");prefs.language("ar");prefs.sound(false)
        val restored=AppPreferences(context).data.first()
        assertEquals("dark",restored.theme);assertEquals("ar",restored.language);assertFalse(restored.sound)
    }
    @Test fun offlinePackageDeclaresNoNetworkOrDangerousPermissions(){
        val info=context.packageManager.getPackageInfo(context.packageName,android.content.pm.PackageManager.GET_PERMISSIONS)
        assertTrue(info.requestedPermissions?.none{it=="android.permission.INTERNET" || it.contains("CAMERA") || it.contains("LOCATION") || it.contains("RECORD_AUDIO")} ?: true)
    }
}
