package com.mhmmad.coloringpages

import com.mhmmad.coloringpages.core.model.*
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

class ColourEngineTest {
    private val a=ArtRegion("a","",0,emptyList())
    private val b=ArtRegion("b","",1,emptyList())
    private fun session(mode:ColourMode=ColourMode.NUMBERS)=ColourSession("test",mode)
    @Test fun correctTapColoursOnlyTheSelectedRegion(){
        val next=ColourEngine.paint(session(),a,0,8,2,100)
        assertEquals(mapOf("a" to 0),next.colours);assertEquals(.5f,next.progress(2));assertNull(next.completedAt)
    }
    @Test fun wrongNumberIsRejectedWithoutHistoryOrTimestampChange(){
        val original=session();assertEquals(original,ColourEngine.paint(original,a,1,8,2,100))
    }
    @Test fun invalidPaletteIsRejected(){assertEquals(session(),ColourEngine.paint(session(),a,-1,8,2,100));assertEquals(session(),ColourEngine.paint(session(),a,8,8,2,100))}
    @Test fun tappingSameColourDoesNotAddUndo(){
        val next=ColourEngine.paint(session(),a,0,8,2,100)
        assertEquals(next,ColourEngine.paint(next,a,0,8,2,200))
    }
    @Test fun freeModeAllowsAnyPaletteColour(){assertEquals(mapOf("a" to 6),ColourEngine.paint(session(ColourMode.FREE),a,6,8,2,100).colours)}
    @Test fun undoRedoRestoresTheExactColours(){
        val first=ColourEngine.paint(session(),a,0,8,2,100)
        val second=ColourEngine.paint(first,b,1,8,2,200)
        val undo=ColourEngine.undo(second,2,300)
        assertEquals(first.colours,undo.colours);assertNull(undo.completedAt)
        val redo=ColourEngine.redo(undo,2,400)
        assertEquals(second.colours,redo.colours);assertNotNull(redo.completedAt)
    }
    @Test fun freeRecolourUndoRestoresPriorColour(){
        val first=ColourEngine.paint(session(ColourMode.FREE),a,2,8,2,100)
        val second=ColourEngine.paint(first,a,5,8,2,200)
        assertEquals(2,ColourEngine.undo(second,2,300).colours["a"])
    }
    @Test fun newPaintAfterUndoDropsRedoBranch(){
        val first=ColourEngine.paint(session(),a,0,8,2,100)
        val undo=ColourEngine.undo(first,2,200)
        val next=ColourEngine.paint(undo,b,1,8,2,300)
        assertTrue(next.redo.isEmpty());assertFalse(next.colours.containsKey("a"))
    }
    @Test fun completionUsesActualDistinctRegions(){
        val first=ColourEngine.paint(session(),a,0,8,2,100)
        val second=ColourEngine.paint(first,b,1,8,2,200)
        assertEquals(1f,second.progress(2));assertEquals(200L,second.completedAt)
        assertEquals(0f,session().progress(0))
    }
    @Test fun dailyChallengeIsStableForDateAndHandlesPastDates(){
        val list=(0..47).map{ArtSummary("$it","x",mapOf("en" to "$it"),"easy",3)}
        val d=LocalDate.of(2026,11,13)
        assertEquals(ColourEngine.dailyArt(d,list),ColourEngine.dailyArt(d,list))
        assertNotEquals(ColourEngine.dailyArt(d,list),ColourEngine.dailyArt(d.plusDays(1),list))
        assertTrue(ColourEngine.dailyArt(LocalDate.of(1900,1,1),list) in list)
    }
    @Test fun zoomedPannedHitCoordinatesRoundTrip(){
        for((w,h) in listOf(1080f to 1000f,320f to 600f,2000f to 1600f))for(z in listOf(1f,2.3f,5f)){
            val t=CanvasTransform(w,h,z,130f,-76f)
            val screen=t.toScreen(320.25f,680.75f);val art=t.toArt(screen.first,screen.second)
            assertEquals(320.25f,art.first,.001f);assertEquals(680.75f,art.second,.001f)
        }
    }
    @Test fun zoomPreservesPointUnderTheFingers(){
        val t=CanvasTransform(1080f,1200f)
        val before=t.toArt(400f,550f);val next=t.zoomAt(400f,550f,2f)
        val after=next.toArt(400f,550f)
        assertEquals(before.first,after.first,.001f);assertEquals(before.second,after.second,.001f)
    }
    @Test fun zoomIsClamped(){assertEquals(5f,CanvasTransform(1000f,1000f).zoomAt(500f,500f,100f).zoom);assertEquals(1f,CanvasTransform(1000f,1000f).zoomAt(500f,500f,.1f).zoom)}
}
