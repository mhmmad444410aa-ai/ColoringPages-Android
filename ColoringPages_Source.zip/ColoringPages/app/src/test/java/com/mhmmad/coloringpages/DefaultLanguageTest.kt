package com.mhmmad.coloringpages

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.core.os.ConfigurationCompat
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.*

/** Regression for the user's Arabic phone: English is the initial app language. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[29],application=ColoringApplication::class,qualifiers="ar-rJO-w360dp-h640dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class DefaultLanguageTest {
    @get:Rule val rule=createAndroidComposeRule<MainActivity>()
    @Test fun englishIsDefaultOnArabicDeviceAndAllThreeChoicesAreVisible(){
        rule.waitUntil(60_000){rule.onAllNodesWithTag("home-screen").fetchSemanticsNodes().isNotEmpty()}
        assertEquals("en",ConfigurationCompat.getLocales(rule.activity.resources.configuration).get(0)?.language)
        assertEquals(0,rule.activity.resources.configuration.layoutDirection)
        assertEquals("Coloring Pages",rule.activity.getString(R.string.app_name))
        rule.onNodeWithTag("home-language").performClick()
        rule.onNodeWithTag("language-en-GB").assertIsDisplayed()
        rule.onNodeWithTag("language-ar").assertIsDisplayed()
        rule.onNodeWithTag("language-pt-BR").assertIsDisplayed()
        rule.onNodeWithText(rule.activity.getString(R.string.close)).performClick()
    }
}
