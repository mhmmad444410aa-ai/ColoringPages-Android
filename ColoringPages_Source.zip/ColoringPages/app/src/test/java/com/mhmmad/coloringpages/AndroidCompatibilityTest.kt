package com.mhmmad.coloringpages

import android.content.Context
import android.content.res.Configuration
import androidx.core.os.ConfigurationCompat
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.Locale

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[23,35],application=ColoringApplication::class)
class AndroidCompatibilityTest {
    @Test fun launcherAndLocalisedNamesWorkOnMinimumAndModernAndroid(){
        val context:Context=ApplicationProvider.getApplicationContext()
        for(tag in listOf("en-GB","ar","pt-BR")){
            val config=Configuration(context.resources.configuration).apply{setLocale(Locale.forLanguageTag(tag))}
            val localized=context.createConfigurationContext(config)
            assertFalse(localized.getString(R.string.app_name).isBlank())
            assertNotNull(ConfigurationCompat.getLocales(config).get(0))
        }
        val controller=Robolectric.buildActivity(MainActivity::class.java).create().start().resume()
        assertFalse(controller.get().isFinishing)
        controller.pause().stop().destroy()
    }
}
