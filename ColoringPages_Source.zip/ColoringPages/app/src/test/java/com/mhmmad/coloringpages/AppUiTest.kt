package com.mhmmad.coloringpages

import androidx.compose.ui.geometry.Offset
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import com.mhmmad.coloringpages.core.model.*
import com.mhmmad.coloringpages.core.graphics.RendererCache
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.flow.first
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.*
import android.graphics.Bitmap
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[29],application=ColoringApplication::class,qualifiers="en-rGB-w360dp-h640dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class AppUiTest {
    @get:Rule val rule=createAndroidComposeRule<MainActivity>()
    private val repo get()=(rule.activity.application as ColoringApplication).repository
    @Before fun prepare(){
        rule.waitUntil(60_000){repo.ready.value}
        runBlocking{repo.resetAll();(rule.activity.application as ColoringApplication).preferences.theme("light");(rule.activity.application as ColoringApplication).preferences.language("en-GB");(rule.activity.application as ColoringApplication).preferences.motion(true)}
        rule.activityRule.scenario.onActivity{AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags("en-GB"))}
        rule.waitForIdle()
        // Activity recreation deliberately restores an open studio. Each journey starts at Home.
        repeat(3) {
            if(rule.onAllNodesWithTag("home-screen").fetchSemanticsNodes().isEmpty()) {
                rule.activityRule.scenario.onActivity{it.onBackPressedDispatcher.onBackPressed()}
                rule.waitForIdle()
            }
        }
        rule.waitUntil(60_000){rule.onAllNodesWithTag("home-screen").fetchSemanticsNodes().isNotEmpty()}
    }
    private fun image(name:String){
        rule.waitForIdle()
        val file=File("../store/rendered-screenshots/$name.png");file.parentFile?.mkdirs()
        val bitmap=rule.runOnIdle {
            val view=rule.activity.window.decorView
            Bitmap.createBitmap(view.width,view.height,Bitmap.Config.ARGB_8888).also { view.draw(android.graphics.Canvas(it)) }
        }
        file.outputStream().use{bitmap.compress(Bitmap.CompressFormat.PNG,100,it)}
        assertTrue(file.length()>10000)
    }
    private fun chooseLanguage(tag:String){
        rule.onNodeWithTag("home-language").performClick()
        rule.onNodeWithTag("language-"+tag).performClick()
        rule.waitUntil(60_000){rule.waitForIdle();androidx.core.os.ConfigurationCompat.getLocales(rule.activity.resources.configuration).get(0)?.toLanguageTag()==tag}
        rule.waitUntil(60_000){rule.onAllNodesWithTag("home-screen").fetchSemanticsNodes().isNotEmpty()}
    }
    private fun studio(){
        rule.onNodeWithTag("start-colouring").performClick()
        rule.waitUntil(60_000){rule.onAllNodesWithTag("colouring-canvas").fetchSemanticsNodes().isNotEmpty()}
    }
    private fun tap(region:ArtRegion){
        rule.onNodeWithTag("palette").performScrollToNode(hasTestTag("colour-${region.colour}"))
        rule.onNodeWithTag("colour-${region.colour}").performClick()
        val canvas=rule.onNodeWithTag("colouring-canvas");val b=canvas.fetchSemanticsNode().boundsInRoot
        val p=region.labels.maxBy{it.radius};val pos=CanvasTransform(b.width,b.height).toScreen(p.x,p.y)
        canvas.performTouchInput{click(Offset(pos.first,pos.second))}
        rule.waitUntil(30_000){repo.pendingSaves.value==0}
        rule.waitForIdle()
    }
    @Test fun actualHomeGalleryAndStudioRenderAndTapsPersist(){
        runBlocking{listOf("flowers_09","nature_09","vehicles_09","flowers_01").forEach{RendererCache.get(repo,it)}}
        rule.waitForIdle();image("01_Home_EN")
        rule.onNodeWithTag("home-screen").performScrollToNode(hasTestTag("category-flowers"));image("15_Illustrated_Collections_EN")
        rule.onNodeWithTag("home-screen").performScrollToIndex(0)
        rule.onNodeWithTag("nav-gallery").performClick();image("02_Gallery_EN")
        rule.onNodeWithTag("gallery-grid").performScrollToNode(hasTestTag("art-flowers_01"))
        rule.onNodeWithTag("art-flowers_01").performClick()
        rule.waitUntil(60_000){rule.onAllNodesWithTag("colouring-canvas").fetchSemanticsNodes().isNotEmpty()}
        val drawing=runBlocking{repo.drawing("flowers_01")};val region=drawing.regions.first{it.colour<4 && it.labels.any{p->p.radius>20}}
        tap(region)
        rule.waitUntil(30_000){repo.sessions.value.any{region.id in it.colours}}
        image("03_Studio_EN")
        rule.onNodeWithTag("undo").performClick();rule.waitUntil(30_000){repo.pendingSaves.value==0};rule.waitForIdle()
        assertFalse(repo.sessions.value.first().colours.containsKey(region.id))
        rule.onNodeWithTag("redo").performClick();rule.waitUntil(30_000){repo.pendingSaves.value==0};rule.waitForIdle()
        assertTrue(repo.sessions.value.first().colours.containsKey(region.id))
        val count=repo.sessions.value.first().colours.size
        rule.onNodeWithTag("colouring-canvas").performTouchInput{swipe(Offset(120f,160f),Offset(300f,310f),500)}
        rule.waitForIdle();assertEquals(count,repo.sessions.value.first().colours.size)
        rule.onNodeWithTag("fit").performClick()
        rule.onNodeWithTag("studio-back").performClick();rule.onNodeWithTag("nav-artwork").performClick();image("04_My_Art_EN")
    }
    @Test @Config(qualifiers="ar-rJO-w360dp-h640dp-xxhdpi") fun arabicInterfaceRendersInRtl(){
        chooseLanguage("ar")
        runBlocking{RendererCache.get(repo,"flowers_01")}
        rule.onNodeWithText(rule.activity.getString(R.string.greeting)).assertIsDisplayed()
        assertEquals(1,rule.activity.resources.configuration.layoutDirection)
        image("05_Home_AR");studio();image("06_Studio_AR")
    }
    @Test @Config(qualifiers="pt-rBR-w360dp-h640dp-xxhdpi") fun portugueseInterfaceAndFreeColourWork(){
        chooseLanguage("pt-BR")
        rule.onNodeWithTag("nav-gallery").performClick();rule.onNodeWithTag("free-mode").performClick()
        image("07_Gallery_PTBR")
        rule.onNodeWithTag("gallery-grid").performScrollToNode(hasTestTag("art-flowers_01"))
        rule.onNodeWithTag("art-flowers_01").performClick()
        rule.waitUntil(60_000){rule.onAllNodesWithTag("colouring-canvas").fetchSemanticsNodes().isNotEmpty()}
        val drawing=runBlocking{repo.drawing("flowers_01")};val original=drawing.regions.first{it.labels.any{p->p.radius>20}}
        val arbitrary=original.copy(colour=(original.colour+3)%8)
        tap(arbitrary)
        rule.waitUntil(30_000){repo.sessions.value.any{it.mode==ColourMode.FREE && it.colours[original.id]==arbitrary.colour}}
        image("08_Free_Colour_PTBR")
    }
    @Test fun parentGateAndPrivacyAndDailyAreRealScreens(){
        rule.onNodeWithTag("home-screen").performScrollToNode(hasTestTag("daily-button"))
        rule.onNodeWithTag("daily-button").performClick()
        rule.onNodeWithText(rule.activity.getString(R.string.daily_title)).assertExists();image("09_Daily_EN")
        rule.activityRule.scenario.onActivity{it.onBackPressedDispatcher.onBackPressed()};rule.waitForIdle()
        rule.onNodeWithTag("parent-button").performClick()
        println("Parent gate: numeric entry")
        rule.onNodeWithTag("parent-digit-0").assertIsDisplayed().performClick();rule.onNodeWithTag("parent-enter").performClick()
        rule.onNodeWithText(rule.activity.getString(R.string.wrong_answer)).assertExists()
        val node=rule.onAllNodes(SemanticsMatcher("arithmetic"){it.config.contains(SemanticsProperties.Text)&&it.config[SemanticsProperties.Text].any{t->Regex("\\d+ × \\d+ = \\?").matches(t.text)}}).fetchSemanticsNodes().first()
        val numbers=Regex("\\d+").findAll(node.config[SemanticsProperties.Text].joinToString(""){it.text}).map{it.value.toInt()}.toList()
        rule.onNodeWithTag("parent-clear").performClick();(numbers[0]*numbers[1]).toString().forEach{digit->rule.onNodeWithTag("parent-digit-$digit").performClick()};rule.onNodeWithTag("parent-enter").performClick()
        println("Parent gate: accepted")
        rule.onNodeWithTag("parent-screen").assertExists();image("10_Parent_Area_EN")
        rule.onNodeWithTag("privacy-setting").performScrollTo().performClick();rule.onNodeWithText(rule.activity.getString(R.string.privacy_body)).assertExists()
        rule.onNodeWithText(rule.activity.getString(R.string.close)).performClick()
        rule.activityRule.scenario.onActivity{it.onBackPressedDispatcher.onBackPressed()};rule.waitForIdle()
        println("Parent journey: complete")
    }
    @Test fun completionAndActivityRecreationKeepRealColours(){
        rule.onNodeWithTag("nav-gallery").performClick()
        rule.onNodeWithTag("gallery-grid").performScrollToNode(hasTestTag("art-vehicles_02"))
        rule.onNodeWithTag("art-vehicles_02").performClick()
        rule.waitUntil(60_000){rule.onAllNodesWithTag("colouring-canvas").fetchSemanticsNodes().isNotEmpty()}
        val drawing=runBlocking{repo.drawing("vehicles_02")}
        drawing.regions.forEach(::tap)
        rule.waitUntil(30_000){repo.sessions.value.any{it.artId==drawing.id && it.completedAt!=null}}
        rule.onNodeWithText(rule.activity.getString(R.string.completed_title)).assertIsDisplayed()
        rule.onNodeWithText(rule.activity.getString(R.string.close)).performClick()
        image("11_Completed_Artwork_EN")
        rule.activityRule.scenario.recreate()
        rule.waitUntil(60_000){rule.onAllNodesWithTag("colouring-canvas").fetchSemanticsNodes().isNotEmpty()}
        assertEquals(drawing.regions.size,repo.sessions.value.first{it.artId==drawing.id}.colours.size)
        image("12_Resumed_After_Recreation_EN")
    }
    @Test fun searchAndNewIllustrationsWorkWithoutChangingTheColourEngine(){
        rule.onNodeWithTag("nav-gallery").performClick()
        rule.onNodeWithTag("art-search").performTextInput("Cosmic")
        rule.onNodeWithTag("art-space_09").assertIsDisplayed().performClick()
        rule.waitUntil(60_000){rule.onAllNodesWithTag("colouring-canvas").fetchSemanticsNodes().isNotEmpty()}
        val drawing=runBlocking{repo.drawing("space_09")}
        tap(drawing.regions.first{it.labels.any{p->p.radius>25}})
        rule.waitUntil(30_000){repo.sessions.value.any{it.artId=="space_09" && it.colours.isNotEmpty()}}
        image("13_New_Cosmic_Studio_EN")
        rule.onNodeWithTag("studio-back").performClick()
    }

    @Test fun animatedPreviewProducesDifferentFramesAndCanBeDisabled(){
        runBlocking{RendererCache.get(repo,"flowers_09")}
        runBlocking{(rule.activity.application as ColoringApplication).preferences.motion(false)}
        rule.waitForIdle()
        rule.mainClock.autoAdvance=false
        try {
            // Infinite animations cancelled by the auto-advancing test clock must be restarted.
            runBlocking{(rule.activity.application as ColoringApplication).preferences.motion(true)}
            rule.mainClock.advanceTimeBy(32)
            rule.waitForIdle()
            repeat(8){frame->
                rule.mainClock.advanceTimeBy(1000)
                rule.waitForIdle()
                image("motion/frame-"+frame)
            }
            val frames=(0..7).map{File("../store/rendered-screenshots/motion/frame-"+it+".png").readBytes().contentHashCode()}
            assertTrue("The actual animated cover must change between frames",frames.distinct().size>3)
        } finally {rule.mainClock.autoAdvance=true}
        runBlocking{(rule.activity.application as ColoringApplication).preferences.motion(false)}
        rule.waitForIdle()
        image("14_Motion_Disabled_EN")
        assertFalse(runBlocking{(rule.activity.application as ColoringApplication).preferences.data.first()}.motion)
    }

}
