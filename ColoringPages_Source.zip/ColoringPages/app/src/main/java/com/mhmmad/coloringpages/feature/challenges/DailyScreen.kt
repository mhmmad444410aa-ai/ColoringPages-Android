package com.mhmmad.coloringpages.feature.challenges

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.*
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.mhmmad.coloringpages.R
import com.mhmmad.coloringpages.core.database.*
import com.mhmmad.coloringpages.core.designsystem.*
import com.mhmmad.coloringpages.core.model.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable fun DailyScreen(repository: ArtRepository, language: String, today: LocalDate,
    challenges: List<DailyChallengeEntity>, onBack: () -> Unit, onStart: (ArtSummary) -> Unit) {
    val art=ColourEngine.dailyArt(today,repository.catalog)
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){
            IconButton(onClick=onBack){Icon(Icons.AutoMirrored.Rounded.ArrowBack,stringResource(R.string.back))}
            Text(stringResource(R.string.daily_challenge),style=MaterialTheme.typography.headlineSmall)
        }
        Column(Modifier.verticalScroll(rememberScrollState()).padding(24.dp),verticalArrangement=Arrangement.spacedBy(18.dp)) {
            Pill(today.format(DateTimeFormatter.ofPattern("d MMMM yyyy",Locale.forLanguageTag(language))))
            Text(stringResource(R.string.daily_title),style=MaterialTheme.typography.headlineLarge)
            Text(stringResource(R.string.daily_description),color=MaterialTheme.colorScheme.onSurfaceVariant)
            ArtThumbnail(repository,art,Modifier.fillMaxWidth().aspectRatio(1f),language=language)
            Text(art.title(language),style=MaterialTheme.typography.titleLarge)
            if(challenges.any{it.date==today.toString()})Text(stringResource(R.string.daily_done),color=MaterialTheme.colorScheme.secondary)
            Button(onClick={onStart(art)},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp),contentPadding=PaddingValues(17.dp)){Text(stringResource(R.string.start_colouring))}
            Text(stringResource(R.string.daily_history,challenges.size),style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
