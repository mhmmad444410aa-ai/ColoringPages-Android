package com.mhmmad.coloringpages.core.graphics

import android.media.AudioAttributes
import android.media.SoundPool
import android.content.Context

/** A short generated noise click, never a melody or a musical note. */
class ColourSound(context: Context) {
    private val pool = SoundPool.Builder().setMaxStreams(2).setAudioAttributes(AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).build()
    private var ready = false
    private val sound: Int
    init {
        pool.setOnLoadCompleteListener { _, _, status -> ready = status == 0 }
        val file = context.cacheDir.resolve("colour-click.wav")
        context.assets.open("colour-click.wav").use { source -> file.outputStream().use { source.copyTo(it) } }
        sound = pool.load(file.path, 1)
    }
    fun click() { if (ready) pool.play(sound, .2f, .2f, 1, 0, 1f) }
    fun release() { pool.release() }
}
