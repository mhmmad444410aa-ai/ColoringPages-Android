package com.mhmmad.coloringpages.core.database

import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "sessions")
data class SessionEntity(@PrimaryKey val sessionKey: String, val artId: String, val mode: String,
    val coloursJson: String, val undoJson: String, val redoJson: String,
    val updatedAt: Long, val completedAt: Long?)
@Entity(tableName = "daily_challenges")
data class DailyChallengeEntity(@PrimaryKey val date: String, val artId: String, val completedAt: Long)
@Dao
interface ArtDao {
    @Query("SELECT * FROM sessions ORDER BY updatedAt DESC") fun observeAll(): Flow<List<SessionEntity>>
    @Query("SELECT * FROM daily_challenges ORDER BY date DESC") fun observeChallenges(): Flow<List<DailyChallengeEntity>>
    @Query("SELECT * FROM sessions WHERE sessionKey = :key") suspend fun session(key: String): SessionEntity?
    @Upsert suspend fun upsert(session: SessionEntity)
    @Upsert suspend fun upsertChallenge(challenge: DailyChallengeEntity)
    @Query("DELETE FROM sessions") suspend fun clearSessions()
    @Query("DELETE FROM daily_challenges") suspend fun clearChallenges()
    @Transaction suspend fun save(session: SessionEntity, challenge: DailyChallengeEntity?) {
        upsert(session)
        if (challenge != null) upsertChallenge(challenge)
    }
    @Transaction suspend fun clearProgress() { clearSessions(); clearChallenges() }
}
@Database(entities = [SessionEntity::class, DailyChallengeEntity::class], version = 2, exportSchema = true)
abstract class ArtDatabase: RoomDatabase() {
    abstract fun artDao(): ArtDao
    companion object {
        val MIGRATION_1_2 = object: Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `daily_challenges` (`date` TEXT NOT NULL, `artId` TEXT NOT NULL, `completedAt` INTEGER NOT NULL, PRIMARY KEY(`date`))")
            }
        }
    }
}
