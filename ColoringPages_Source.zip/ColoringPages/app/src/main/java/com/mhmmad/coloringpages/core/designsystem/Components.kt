package com.mhmmad.coloringpages.core.designsystem

import androidx.annotation.StringRes
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.*
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.mhmmad.coloringpages.R
import com.mhmmad.coloringpages.core.database.ArtRepository
import com.mhmmad.coloringpages.core.graphics.*
import com.mhmmad.coloringpages.core.model.*

val categoryIds=listOf("flowers","nature","vehicles","buildings","space","geometric")
@StringRes fun categoryName(category:String):Int=when(category){
    "flowers"->R.string.flowers;"nature"->R.string.nature;"vehicles"->R.string.vehicles
    "buildings"->R.string.buildings;"space"->R.string.space;else->R.string.geometric
}
fun categoryIcon(category:String):ImageVector=when(category){
    "flowers"->Icons.Rounded.LocalFlorist;"nature"->Icons.Rounded.Landscape;"vehicles"->Icons.Rounded.Train
    "buildings"->Icons.Rounded.Cottage;"space"->Icons.Rounded.AutoAwesome;else->Icons.Rounded.Widgets
}
fun categoryColour(category:String)=when(category){
    "flowers"->Color(0xFFFFE8E5);"nature"->Color(0xFFE0F3D9);"vehicles"->Color(0xFFFFEFC9)
    "buildings"->Color(0xFFECE6FA);"space"->Color(0xFFE0EFFC);else->Color(0xFFFFE9D5)
}
@StringRes fun difficultyName(difficulty:String)=when(difficulty){"easy"->R.string.easy;"medium"->R.string.medium;else->R.string.hard}
fun ArtSummary.isNew()=id.substringAfterLast('_').toIntOrNull()?.let{it>8}==true

@Composable fun ArtThumbnail(repository:ArtRepository,art:ArtSummary,modifier:Modifier=Modifier,
    colours:Map<String,Int>?=null,preview:Boolean=true,language:String="en",animated:Boolean=false,
    paperColour:Color=Color.White) {
    val renderer by produceState<ArtRenderer?>(null,art.id){value=runCatching{RendererCache.get(repository,art.id)}.getOrNull()}
    val motion=animated && LocalArtMotion.current
    val progress=if(motion){
        val infinite=rememberInfiniteTransition(label="paint-preview")
        infinite.animateFloat(0.12f,1.5f,infiniteRepeatable(tween(9500,easing=LinearEasing),RepeatMode.Restart),label="colour-reveal")
    }else remember{mutableFloatStateOf(1f)}
    Box(modifier.clip(RoundedCornerShape(20.dp)).background(paperColour).semantics{contentDescription=art.title(language)},contentAlignment=Alignment.Center){
        if(renderer==null) Icon(Icons.Rounded.Brush,null,Modifier.size(30.dp),tint=Color(0xFFB6CFC5))
        else Canvas(Modifier.fillMaxSize().padding(5.dp)){
            drawIntoCanvas{compose->
                val native=compose.nativeCanvas;native.save()
                val scale=minOf(size.width,size.height)/1000f
                native.translate((size.width-1000*scale)/2,(size.height-1000*scale)/2);native.scale(scale,scale)
                val current=renderer!!
                val demo=if(motion)current.drawing.regions.take((current.regions.size*progress.value.coerceAtMost(1f)).toInt()).associate{it.id to it.colour}else colours?:emptyMap()
                current.draw(native,demo,preview=preview && !motion)
                native.restore()
            }
        }
    }
}
@Composable fun Pill(text:String,colour:Color=MaterialTheme.colorScheme.surfaceVariant,textColour:Color=MaterialTheme.colorScheme.onSurfaceVariant){
    Surface(color=colour,shape=CircleShape){Text(text,Modifier.padding(horizontal=9.dp,vertical=4.dp),style=MaterialTheme.typography.labelSmall,color=textColour,maxLines=1)}
}
@Composable fun ArtCard(repository:ArtRepository,art:ArtSummary,language:String,session:ColourSession?,onClick:()->Unit,modifier:Modifier=Modifier,showMode:Boolean=false){
    Card(onClick=onClick,modifier=modifier,shape=RoundedCornerShape(23.dp),border=BorderStroke(1.dp,MaterialTheme.colorScheme.outlineVariant),
        colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){
        Box(Modifier.fillMaxWidth().padding(7.dp)){
            ArtThumbnail(repository,art,Modifier.fillMaxWidth().aspectRatio(1.03f),session?.colours,session==null,language,paperColour=categoryColour(art.category).copy(alpha=.32f))
            if(session?.completedAt!=null)Surface(color=Mint,shape=CircleShape,modifier=Modifier.align(Alignment.TopEnd).padding(3.dp)){
                Icon(Icons.Rounded.Check,stringResource(R.string.finished),Modifier.padding(5.dp).size(16.dp),tint=Ink)
            }else if(art.isNew() && session==null)Pill(stringResource(R.string.new_label),Coral,Ink)
        }
        Column(Modifier.padding(start=12.dp,end=12.dp,bottom=12.dp)){
            Text(art.title(language),style=MaterialTheme.typography.titleMedium,maxLines=1,overflow=TextOverflow.Ellipsis)
            Spacer(Modifier.height(5.dp))
            if(session!=null && session.colours.isNotEmpty()){
                Text(stringResource(R.string.progress_percent,(session.progress(art.regionCount)*100).toInt()),style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(6.dp));LinearProgressIndicator(progress={session.progress(art.regionCount)},modifier=Modifier.fillMaxWidth().height(5.dp).clip(CircleShape),color=Teal,trackColor=MaterialTheme.colorScheme.surfaceVariant,gapSize=0.dp,drawStopIndicator={})
            }else Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){
                Pill(stringResource(difficultyName(art.difficulty)),categoryColour(art.category),Ink)
                Icon(Icons.AutoMirrored.Rounded.ArrowForward,null,tint=MaterialTheme.colorScheme.primary,modifier=Modifier.size(16.dp))
            }
            if(showMode){Spacer(Modifier.height(4.dp));Text(stringResource(if(session?.mode==ColourMode.FREE)R.string.free_colour else R.string.numbers),style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}
        }
    }
}
@Composable fun SectionHeading(title:String,action:String?=null,onAction:()->Unit={}){
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){
        Text(title,style=MaterialTheme.typography.titleLarge,modifier=Modifier.weight(1f))
        if(action!=null)TextButton(onClick=onAction,contentPadding=PaddingValues(start=8.dp,end=0.dp)){Text(action,style=MaterialTheme.typography.labelMedium);Icon(Icons.AutoMirrored.Rounded.ArrowForward,null,Modifier.padding(start=4.dp).size(15.dp))}
    }
}
@Composable fun PaintSprinkles(modifier:Modifier=Modifier){
    Canvas(modifier){
        val colours=listOf(Coral,Sunshine,Purple,Teal)
        repeat(13){i->val x=((i*173+40)%1000)/1000f*size.width;val y=((i*137+30)%1000)/1000f*size.height
            if(i%2==0)drawCircle(colours[i%4].copy(alpha=.45f),3.dp.toPx(),Offset(x,y))
            else drawLine(colours[i%4].copy(alpha=.4f),Offset(x,y),Offset(x+5.dp.toPx(),y-8.dp.toPx()),3.dp.toPx(),StrokeCap.Round)
        }
    }
}
@Composable fun EmptyArtwork(onExplore:()->Unit){
    Column(Modifier.fillMaxWidth().padding(horizontal=30.dp,vertical=35.dp),horizontalAlignment=Alignment.CenterHorizontally){
        Box(Modifier.size(140.dp).clip(CircleShape).background(Color(0xFFE2F3E5)),contentAlignment=Alignment.Center){
            PaintSprinkles(Modifier.matchParentSize());Image(painterResource(R.drawable.brand_mark),null,Modifier.size(86.dp))
        }
        Spacer(Modifier.height(22.dp));Text(stringResource(R.string.empty_art),style=MaterialTheme.typography.headlineSmall,textAlign=TextAlign.Center)
        Spacer(Modifier.height(10.dp));Text(stringResource(R.string.empty_art_body),style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant,textAlign=TextAlign.Center)
        Spacer(Modifier.height(22.dp));Button(onClick=onExplore,shape=CircleShape,contentPadding=PaddingValues(24.dp,14.dp)){Icon(Icons.Rounded.Brush,null,Modifier.size(18.dp));Spacer(Modifier.width(8.dp));Text(stringResource(R.string.explore))}
    }
}
@Composable fun LanguageDialog(current:String,onSelect:(String)->Unit,onDismiss:()->Unit){
    AlertDialog(onDismissRequest=onDismiss,icon={Icon(Icons.Rounded.Language,null)},title={Text(stringResource(R.string.language_choice))},text={
        Column(verticalArrangement=Arrangement.spacedBy(9.dp)){
            listOf("en-GB" to R.string.english,"ar" to R.string.arabic,"pt-BR" to R.string.portuguese).forEach{(value,label)->
                OutlinedCard(onClick={onSelect(value)},shape=RoundedCornerShape(17.dp),border=BorderStroke(if(current==value)2.dp else 1.dp,if(current==value)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),modifier=Modifier.fillMaxWidth().testTag("language-"+value)){
                    Row(Modifier.fillMaxWidth().padding(15.dp),verticalAlignment=Alignment.CenterVertically){Text(stringResource(label),Modifier.weight(1f),style=MaterialTheme.typography.titleMedium);if(current==value)Icon(Icons.Rounded.CheckCircle,null,tint=MaterialTheme.colorScheme.primary)}
                }
            }
        }
    },confirmButton={TextButton(onClick=onDismiss){Text(stringResource(R.string.close))}})
}
@Composable fun ColourNavigation(screen:String,onSelect:(String)->Unit){
    Surface(color=MaterialTheme.colorScheme.surface,shadowElevation=12.dp,shape=RoundedCornerShape(topStart=26.dp,topEnd=26.dp)){
        Row(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=8.dp),horizontalArrangement=Arrangement.SpaceEvenly){
            listOf(Triple("home",R.string.home,Icons.Rounded.Home),Triple("gallery",R.string.gallery,Icons.Rounded.AutoAwesomeMosaic),Triple("artwork",R.string.my_art,Icons.Rounded.Palette)).forEach{(route,label,icon)->
                val selected=screen==route
                val background by androidx.compose.animation.animateColorAsState(if(selected)MaterialTheme.colorScheme.primary else Color.Transparent,label="nav-colour")
                Surface(onClick={onSelect(route)},shape=RoundedCornerShape(19.dp),color=background,modifier=Modifier.weight(1f).testTag("nav-"+route).semantics{this.selected=selected}){
                    Column(Modifier.padding(vertical=8.dp),horizontalAlignment=Alignment.CenterHorizontally){
                        Icon(icon,null,Modifier.size(23.dp),tint=if(selected)MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(stringResource(label),style=MaterialTheme.typography.labelSmall,color=if(selected)MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                if(route!="artwork")Spacer(Modifier.width(8.dp))
            }
        }
    }
}
