package com.mhmmad.coloringpages.core.graphics

import com.mhmmad.coloringpages.core.database.ArtRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object RendererCache {
    private val cache = LinkedHashMap<String, ArtRenderer>(12, .75f, true)
    suspend fun get(repository: ArtRepository, id: String): ArtRenderer {
        synchronized(cache) { cache[id] }?.let { return it }
        val drawing = repository.drawing(id)
        val renderer = withContext(Dispatchers.Default) { ArtRenderer(drawing) }
        synchronized(cache) {
            cache[id] = renderer
            while (cache.size > 12) cache.remove(cache.keys.first())
        }
        return renderer
    }
}
