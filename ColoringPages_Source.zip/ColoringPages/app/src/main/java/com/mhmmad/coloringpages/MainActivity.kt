package com.mhmmad.coloringpages

import android.os.Bundle
import android.content.Context
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.core.view.WindowCompat
import androidx.compose.ui.graphics.luminance
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.os.ConfigurationCompat
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.*
import androidx.lifecycle.compose.*
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mhmmad.coloringpages.core.designsystem.*
import com.mhmmad.coloringpages.core.model.*
import com.mhmmad.coloringpages.feature.home.*
import com.mhmmad.coloringpages.feature.gallery.GalleryScreen
import com.mhmmad.coloringpages.feature.challenges.DailyScreen
import com.mhmmad.coloringpages.feature.coloring.*
import com.mhmmad.coloringpages.feature.parents.*
import com.mhmmad.coloringpages.ads.ChildSafeAdsManager
import com.mhmmad.coloringpages.ads.ChildSafeBanner
import java.time.LocalDate

class MainActivity: AppCompatActivity() {
    private var startingLanguage="en-GB"
    private val adsManager by lazy { ChildSafeAdsManager(this) }
    override fun attachBaseContext(newBase:Context) {
        // Use the explicit saved locale before the first composition, including on Arabic phones.
        startingLanguage=runBlocking(Dispatchers.IO) {
            runCatching { (newBase.applicationContext as ColoringApplication).preferences.data.first().language }.getOrDefault("en-GB")
        }
        val configuration=Configuration(newBase.resources.configuration)
        val locale=java.util.Locale.forLanguageTag(startingLanguage)
        configuration.setLocale(locale);configuration.setLayoutDirection(locale)
        super.attachBaseContext(newBase.createConfigurationContext(configuration))
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(startingLanguage))
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {val vm:AppViewModel=viewModel(factory=ViewModelProvider.AndroidViewModelFactory(application));val preferences by vm.preferences.collectAsStateWithLifecycle()
            val systemMotion=android.provider.Settings.Global.getFloat(contentResolver,android.provider.Settings.Global.ANIMATOR_DURATION_SCALE,1f)>0f
            ColoringTheme(preferences.theme,preferences.motion && systemMotion){
                val lightBars=MaterialTheme.colorScheme.background.luminance()>.5f
                SideEffect { WindowCompat.getInsetsController(window,window.decorView).apply {isAppearanceLightStatusBars=lightBars;isAppearanceLightNavigationBars=lightBars} }
                LaunchedEffect(preferences.adsDecision) {
                    if (preferences.adsDecision == "approved") adsManager.enableAfterParentAcknowledgement()
                    else adsManager.disable()
                }
                ColoringApp(vm,adsManager)
            }
        }
    }
}
@Composable private fun ColoringApp(vm:AppViewModel, adsManager:ChildSafeAdsManager) {
    val preferences by vm.preferences.collectAsStateWithLifecycle()
    val sessions by vm.repository.sessions.collectAsStateWithLifecycle()
    val challenges by vm.repository.challenges.collectAsStateWithLifecycle()
    val storageError by vm.repository.storageError.collectAsStateWithLifecycle()
    val ready by vm.repository.ready.collectAsStateWithLifecycle()
    val config=LocalConfiguration.current
    val language=ConfigurationCompat.getLocales(config).get(0)?.toLanguageTag() ?: "en-GB"
    var screen by rememberSaveable {mutableStateOf("home")}
    var galleryCategory by rememberSaveable {mutableStateOf<String?>(null)}
    var artId by rememberSaveable {mutableStateOf("flowers_01")}
    var modeName by rememberSaveable {mutableStateOf(ColourMode.NUMBERS.name)}
    var studioToken by rememberSaveable {mutableLongStateOf(0)}
    var previous by rememberSaveable {mutableStateOf("home")}
    var challengeDate by rememberSaveable {mutableStateOf<String?>(null)}
    var parentGate by rememberSaveable {mutableStateOf(false)}
    var gatePurpose by rememberSaveable { mutableStateOf("settings") }
    var advertisingNotice by rememberSaveable { mutableStateOf(false) }
    var languagePicker by rememberSaveable {mutableStateOf(false)}
    var parentAuthorized by remember {mutableStateOf(false)}
    var today by remember {mutableStateOf(LocalDate.now())}
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME){today=LocalDate.now()}
    LifecycleEventEffect(Lifecycle.Event.ON_STOP){parentAuthorized=false;if(screen=="parents")screen="home"}
    LaunchedEffect(screen,parentAuthorized){if(screen=="parents" && !parentAuthorized)screen="home"}
    fun back(){screen=if(screen=="studio")previous else "home"}
    BackHandler(enabled=screen!="home"){back()}
    fun open(art:ArtSummary,mode:ColourMode,daily:Boolean=false){
        previous=screen;artId=art.id;modeName=mode.name;challengeDate=if(daily)today.toString() else null;studioToken++;screen="studio"
    }
    val bottomVisible=screen in listOf("home","gallery","artwork")
    Scaffold(modifier=Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing),bottomBar={
        if(bottomVisible) Column {
            if(preferences.adsDecision=="approved" && adsManager.isEnabled()) {
                ChildSafeBanner(Modifier.padding(vertical=4.dp))
            }
            ColourNavigation(screen){route->screen=route;if(route=="gallery")galleryCategory=null}
        }
    }){padding->
        Surface(Modifier.fillMaxSize().padding(padding),color=MaterialTheme.colorScheme.background) {
            if(!ready) Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Text(stringResource(R.string.loading))}
            else when(screen){
                "home"->HomeScreen(vm.repository,sessions,language,{art,mode->open(art,mode)},{category->galleryCategory=category;screen="gallery"},{screen="daily"},{gatePurpose="settings";parentGate=true},{languagePicker=true})
                "gallery","artwork"->GalleryScreen(vm.repository,sessions,language,galleryCategory,screen=="artwork",{art,mode->open(art,mode)},{screen="gallery";galleryCategory=null})
                "daily"->DailyScreen(vm.repository,language,today,challenges,{back()},{art->open(art,ColourMode.NUMBERS,true)})
                "parents"->ParentScreen(vm,preferences,storageError,{back()},{advertisingNotice=true})
                "studio"->{
                    val art=vm.repository.catalog.firstOrNull{it.id==artId}
                    if(art!=null){
                        val owner=remember(studioToken){object:ViewModelStoreOwner{override val viewModelStore=ViewModelStore()}}
                        DisposableEffect(owner){onDispose{owner.viewModelStore.clear()}}
                        val studio:StudioViewModel=viewModel(viewModelStoreOwner=owner,factory=object:ViewModelProvider.Factory{
                            @Suppress("UNCHECKED_CAST") override fun<T:ViewModel>create(modelClass:Class<T>):T=StudioViewModel(vm.repository,art.id,ColourMode.valueOf(modeName),challengeDate?.let(LocalDate::parse)) as T
                        })
                        StudioScreen(studio,vm.repository,art,language,preferences.sound,{back()},{adsManager.onCompletedPictureNext();screen="gallery";galleryCategory=null})
                    }
                }
            }
        }
    }
    if(languagePicker)LanguageDialog(preferences.language,{value->languagePicker=false;vm.language(value){AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(value))}},{languagePicker=false})
    if(preferences.adsDecision=="unset") {
        AlertDialog(onDismissRequest={vm.adsDecision("declined")},
            title={Text(stringResource(R.string.ad_parent_title))},
            text={Text(stringResource(R.string.ad_parent_message))},
            confirmButton={TextButton(onClick={gatePurpose="ads";parentGate=true}) { Text(stringResource(R.string.ad_parent_review)) }},
            dismissButton={TextButton(onClick={vm.adsDecision("declined")}) { Text(stringResource(R.string.ad_continue_without)) }})
    }
    if(parentGate) ParentGate({parentGate=false},{
        parentGate=false;parentAuthorized=true
        if(gatePurpose=="ads")advertisingNotice=true else screen="parents"
    })
    if(advertisingNotice && parentAuthorized) {
        AlertDialog(onDismissRequest={advertisingNotice=false},
            title={Text(stringResource(R.string.ad_consent_title))},
            text={Text(stringResource(R.string.ad_consent_message))},
            confirmButton={TextButton(onClick={vm.adsDecision("approved");advertisingNotice=false}){Text(stringResource(R.string.ad_agree))}},
            dismissButton={TextButton(onClick={vm.adsDecision("declined");advertisingNotice=false}){Text(stringResource(R.string.ad_continue_without))}})
    }
}
