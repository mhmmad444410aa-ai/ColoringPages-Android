package com.mhmmad.coloringpages.core.designsystem

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.*
import androidx.compose.ui.unit.sp
import com.mhmmad.coloringpages.R

val Purple = Color(0xFF7356D8)
val Ink = Color(0xFF283C47)
val Mint = Color(0xFF7DDBB5)
val Coral = Color(0xFFFF826C)
val Sunshine = Color(0xFFFFD566)
val Teal = Color(0xFF168575)
val Paper = Color(0xFFFFFCF7)
val LocalArtMotion = staticCompositionLocalOf { true }
private val Light = lightColorScheme(
    primary=Teal,onPrimary=Color.White,secondary=Purple,tertiary=Coral,
    background=Paper,surface=Color.White,onSurface=Ink,onBackground=Ink,
    surfaceVariant=Color(0xFFF0F2EE),onSurfaceVariant=Color(0xFF687D81),
    outline=Color(0xFFCBD8D1),outlineVariant=Color(0xFFE7EBE4)
)
private val Dark = darkColorScheme(
    primary=Mint,onPrimary=Color(0xFF123C33),secondary=Color(0xFFC6B5FF),tertiary=Coral,
    background=Color(0xFF172625),surface=Color(0xFF223432),onSurface=Color(0xFFF5F4E9),onBackground=Color(0xFFF5F4E9),
    surfaceVariant=Color(0xFF314845),onSurfaceVariant=Color(0xFFBACDC7),outline=Color(0xFF607E76),outlineVariant=Color(0xFF3D5550)
)
@Composable fun ColoringTheme(theme:String,motion:Boolean=true,content:@Composable ()->Unit) {
    val dark=theme=="dark" || (theme=="system" && isSystemInDarkTheme())
    val rounded=FontFamily(Font(R.font.rounded_regular,FontWeight.Normal),Font(R.font.rounded_bold,FontWeight.Bold),Font(R.font.rounded_extrabold,FontWeight.ExtraBold))
    fun text(size:Int,line:Int,weight:FontWeight=FontWeight.Normal)=TextStyle(fontFamily=rounded,fontWeight=weight,fontSize=size.sp,lineHeight=line.sp)
    CompositionLocalProvider(LocalArtMotion provides motion) {
        MaterialTheme(colorScheme=if(dark)Dark else Light,typography=Typography(
            displaySmall=text(34,40,FontWeight.ExtraBold),headlineLarge=text(30,37,FontWeight.ExtraBold),
            headlineMedium=text(27,34,FontWeight.ExtraBold),headlineSmall=text(24,30,FontWeight.ExtraBold),
            titleLarge=text(21,28,FontWeight.ExtraBold),titleMedium=text(16,22,FontWeight.ExtraBold),
            titleSmall=text(14,20,FontWeight.Bold),bodyLarge=text(16,24),bodyMedium=text(14,21),bodySmall=text(12,18),
            labelLarge=text(14,20,FontWeight.ExtraBold),labelMedium=text(12,17,FontWeight.Bold),labelSmall=text(10,14,FontWeight.Bold)
        ),content=content)
    }
}
