package com.mhmmad.coloringpages

import android.app.Application
import com.mhmmad.coloringpages.core.database.ArtRepository
import com.mhmmad.coloringpages.core.preferences.AppPreferences

class ColoringApplication: Application() {
    val repository by lazy { ArtRepository(this) }
    val preferences by lazy { AppPreferences(this) }
}
