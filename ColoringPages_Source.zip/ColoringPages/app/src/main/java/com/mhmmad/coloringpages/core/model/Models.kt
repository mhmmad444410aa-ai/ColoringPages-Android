package com.mhmmad.coloringpages.core.model

import java.time.LocalDate

data class ArtSummary(
    val id: String, val category: String, val titles: Map<String, String>,
    val difficulty: String, val regionCount: Int
) {
    fun title(language: String): String = titles[language.substringBefore('-')] ?: titles.getValue("en")
}
data class LabelPoint(val x: Float, val y: Float, val radius: Float)
data class ArtRegion(val id: String, val path: String, val colour: Int, val labels: List<LabelPoint>)
data class ArtDrawing(val id: String, val palette: List<Int>, val regions: List<ArtRegion>)
enum class ColourMode { NUMBERS, FREE }
data class ColourChange(val regionId: String, val before: Int?, val after: Int?)
data class ColourSession(
    val artId: String, val mode: ColourMode,
    val colours: Map<String, Int> = emptyMap(),
    val undo: List<ColourChange> = emptyList(), val redo: List<ColourChange> = emptyList(),
    val updatedAt: Long = 0, val completedAt: Long? = null
) {
    val key: String get() = "$artId:${mode.name}"
    fun progress(total: Int): Float = if (total <= 0) 0f else (colours.size.toFloat() / total).coerceIn(0f, 1f)
}

/** Pure reducer: the renderer cannot paint a wrong number or mutate history. */
object ColourEngine {
    fun paint(session: ColourSession, region: ArtRegion, selected: Int, paletteSize: Int, total: Int, now: Long): ColourSession {
        if (selected !in 0 until paletteSize) return session
        if (session.mode == ColourMode.NUMBERS && selected != region.colour) return session
        val before = session.colours[region.id]
        if (before == selected) return session
        val next = session.colours + (region.id to selected)
        return session.copy(colours = next, undo = (session.undo + ColourChange(region.id, before, selected)).takeLast(500),
            redo = emptyList(), updatedAt = now, completedAt = if (next.size == total) session.completedAt ?: now else null)
    }
    fun undo(session: ColourSession, total: Int, now: Long): ColourSession {
        val change = session.undo.lastOrNull() ?: return session
        val colours = session.colours.toMutableMap().apply { if (change.before == null) remove(change.regionId) else put(change.regionId, change.before) }
        return session.copy(colours = colours, undo = session.undo.dropLast(1), redo = session.redo + change,
            updatedAt = now, completedAt = if (colours.size == total) session.completedAt ?: now else null)
    }
    fun redo(session: ColourSession, total: Int, now: Long): ColourSession {
        val change = session.redo.lastOrNull() ?: return session
        val colours = session.colours.toMutableMap().apply { if (change.after == null) remove(change.regionId) else put(change.regionId, change.after) }
        return session.copy(colours = colours, undo = session.undo + change, redo = session.redo.dropLast(1),
            updatedAt = now, completedAt = if (colours.size == total) session.completedAt ?: now else null)
    }
    fun dailyArt(date: LocalDate, catalog: List<ArtSummary>): ArtSummary {
        require(catalog.isNotEmpty())
        return catalog[Math.floorMod(date.toEpochDay(), catalog.size.toLong()).toInt()]
    }
}

/** Coordinates are independent of screen density and never mirror for RTL. */
data class CanvasTransform(val width: Float, val height: Float, val zoom: Float = 1f, val panX: Float = 0f, val panY: Float = 0f) {
    val baseScale: Float get() = minOf(width, height) / 1000f
    val scale: Float get() = baseScale * zoom
    val left: Float get() = (width - 1000f * scale) / 2 + panX
    val top: Float get() = (height - 1000f * scale) / 2 + panY
    fun toArt(x: Float, y: Float): Pair<Float, Float> = (x - left) / scale to (y - top) / scale
    fun toScreen(x: Float, y: Float): Pair<Float, Float> = x * scale + left to y * scale + top
    fun zoomAt(x: Float, y: Float, factor: Float, dx: Float = 0f, dy: Float = 0f): CanvasTransform {
        val before = toArt(x, y)
        val next = copy(zoom = (zoom * factor).coerceIn(1f, 5f))
        val panLimit = 500f * next.scale
        return next.copy(
            panX = (x + dx - (width - 1000 * next.scale) / 2 - before.first * next.scale).coerceIn(-panLimit, panLimit),
            panY = (y + dy - (height - 1000 * next.scale) / 2 - before.second * next.scale).coerceIn(-panLimit, panLimit)
        )
    }
}
