package com.mhmmad.coloringpages.ads

import android.app.Activity
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import android.os.SystemClock
import android.util.Log
import com.huawei.hms.ads.AdListener
import com.huawei.hms.ads.HwAds
import com.huawei.hms.ads.InterstitialAd

/** Never initialises an advertising SDK before parent acknowledgement. */
class ChildSafeAdsManager(private val activity: Activity) {
    private var enabled by mutableStateOf(false)
    private var interstitial: InterstitialAd? = null
    private var artworkCompletions = 0
    private var lastShownAt = 0L

    fun isEnabled(): Boolean = enabled

    fun enableAfterParentAcknowledgement() {
        if (enabled) return
        try {
            HwAds.setRequestOptions(AdPolicy.globalRequestOptions())
            HwAds.init(activity.applicationContext)
            enabled = true
            prepareInterstitial()
        } catch (e: Exception) {
            enabled = false
            Log.w("ColouringAds", "Ads unavailable; game remains usable", e)
        }
    }

    fun disable() {
        enabled = false
        interstitial?.adListener = null
        interstitial = null
    }

    private fun prepareInterstitial() {
        if (!enabled) return
        val ad = interstitial ?: InterstitialAd(activity).also { newAd ->
            newAd.adId = AdPolicy.interstitialId
            newAd.adListener = object: AdListener() {
                override fun onAdClosed() { prepareInterstitial() }
                override fun onAdFailed(errorCode: Int) {
                    Log.d("ColouringAds", "Interstitial unavailable ($errorCode)")
                }
            }
            interstitial = newAd
        }
        if (!ad.isLoaded && !ad.isLoading) {
            try { ad.loadAd(AdPolicy.request()) }
            catch (e: Exception) { Log.w("ColouringAds", "Interstitial request skipped", e) }
        }
    }

    /** Only after a completed colouring, at most once per 4 completions and 5 minutes. */
    fun onCompletedPictureNext() {
        if (!enabled) return
        artworkCompletions++
        val now = SystemClock.elapsedRealtime()
        val ad = interstitial
        if (artworkCompletions % 4 == 0 && now - lastShownAt >= 300_000L && ad?.isLoaded == true) {
            try {
                lastShownAt = now
                ad.show(activity)
            } catch (e: Exception) { Log.w("ColouringAds", "Interstitial failed; navigation continues", e) }
        } else if (ad?.isLoaded != true) {
            prepareInterstitial()
        }
    }
}
