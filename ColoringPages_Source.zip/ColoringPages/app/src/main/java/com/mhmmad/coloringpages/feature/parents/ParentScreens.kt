package com.mhmmad.coloringpages.feature.parents

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import com.mhmmad.coloringpages.R
import com.mhmmad.coloringpages.core.designsystem.*
import com.mhmmad.coloringpages.core.preferences.Preferences
import com.mhmmad.coloringpages.core.model.PublishingInfo
import com.mhmmad.coloringpages.feature.home.AppViewModel
import kotlin.random.Random
import kotlinx.coroutines.launch

@Composable fun ParentGate(onDismiss: () -> Unit, onPassed: () -> Unit) {
    val a=rememberSaveable {Random.nextInt(13,29)}
    val b=rememberSaveable {Random.nextInt(12,27)}
    var answer by rememberSaveable {mutableStateOf("")}
    var wrong by rememberSaveable {mutableStateOf(false)}
    AlertDialog(onDismissRequest=onDismiss,title={Text(stringResource(R.string.parent_gate_title))},text={
        Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Text(stringResource(R.string.parent_gate_body),style=MaterialTheme.typography.bodySmall)
            Text("$a × $b = ?",style=MaterialTheme.typography.headlineSmall)
            OutlinedCard(shape=RoundedCornerShape(14.dp),modifier=Modifier.fillMaxWidth()) {
                Text(answer.ifEmpty { "…" },Modifier.fillMaxWidth().padding(10.dp).testTag("parent-answer"),style=MaterialTheme.typography.titleLarge,textAlign=androidx.compose.ui.text.style.TextAlign.Center)
            }
            Column(verticalArrangement=Arrangement.spacedBy(4.dp)) {
                listOf(listOf("1","2","3"),listOf("4","5","6"),listOf("7","8","9"),listOf("clear","0","backspace")).forEach { row ->
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        row.forEach { key ->
                            OutlinedButton(onClick={answer=when(key){"clear"->"";"backspace"->answer.dropLast(1);else->(answer+key).take(4)};wrong=false},
                                shape=RoundedCornerShape(12.dp),contentPadding=PaddingValues(0.dp),modifier=Modifier.weight(1f).height(45.dp).testTag(if(key.length==1)"parent-digit-$key" else "parent-$key")) {
                                when(key){
                                    "clear"->Icon(Icons.Rounded.RestartAlt,stringResource(R.string.clear_answer))
                                    "backspace"->Icon(Icons.AutoMirrored.Rounded.Backspace,stringResource(R.string.delete_digit))
                                    else->Text(key,style=MaterialTheme.typography.titleLarge)
                                }
                            }
                        }
                    }
                }
            }
            if(wrong) Text(stringResource(R.string.wrong_answer),color=MaterialTheme.colorScheme.error)
        }
    },confirmButton={TextButton(onClick={if(answer.toIntOrNull()==a*b)onPassed()else wrong=true},modifier=Modifier.testTag("parent-enter")){Text(stringResource(R.string.enter_parent_area))}},dismissButton={TextButton(onClick=onDismiss){Text(stringResource(R.string.cancel))}})
}
@Composable fun ParentScreen(vm: AppViewModel, preferences: Preferences, storageError: Boolean, onBack: () -> Unit, onReviewAdvertising: () -> Unit) {
    var dialog by rememberSaveable {mutableStateOf<String?>(null)}
    var deleting by remember {mutableStateOf(false)}
    val snack=remember {SnackbarHostState()}
    val scope=rememberCoroutineScope()
    val deleted=stringResource(R.string.data_deleted)
    val failure=stringResource(R.string.data_error)
    val linkError=stringResource(R.string.link_error)
    val context=LocalContext.current
    Scaffold(snackbarHost={SnackbarHost(snack)}) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).testTag("parent-screen")) {
            Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically) {
                IconButton(onClick=onBack){Icon(Icons.AutoMirrored.Rounded.ArrowBack,stringResource(R.string.back))}
                Text(stringResource(R.string.parents),style=MaterialTheme.typography.headlineSmall)
            }
            Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal=22.dp),verticalArrangement=Arrangement.spacedBy(18.dp)) {
                Surface(color=MaterialTheme.colorScheme.surfaceVariant,shape=RoundedCornerShape(25.dp)) {
                    Text(stringResource(R.string.parent_intro),Modifier.padding(20.dp),style=MaterialTheme.typography.bodyLarge)
                }
                if(storageError) Text(stringResource(R.string.data_error),color=MaterialTheme.colorScheme.error)
                Text(stringResource(R.string.settings),style=MaterialTheme.typography.titleLarge)
                Card(shape=RoundedCornerShape(25.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)) {
                    ListItem(headlineContent={Text(stringResource(R.string.language))},supportingContent={Text(stringResource(when(preferences.language){"ar"->R.string.arabic;"pt-BR"->R.string.portuguese;"en-GB"->R.string.english;else->R.string.system_default}))},leadingContent={Icon(Icons.Rounded.Language,null)},trailingContent={TextButton(onClick={dialog="language"},modifier=Modifier.testTag("language-setting")){Icon(Icons.Rounded.Edit,stringResource(R.string.language_choice))}})
                    HorizontalDivider(color=MaterialTheme.colorScheme.surfaceVariant)
                    ListItem(headlineContent={Text(stringResource(R.string.theme))},supportingContent={Text(stringResource(when(preferences.theme){"light"->R.string.light;"dark"->R.string.dark;else->R.string.system_default}))},leadingContent={Icon(Icons.Rounded.Contrast,null)},trailingContent={TextButton(onClick={dialog="theme"},modifier=Modifier.testTag("theme-setting")){Icon(Icons.Rounded.Edit,stringResource(R.string.theme))}})
                    HorizontalDivider(color=MaterialTheme.colorScheme.surfaceVariant)
                    ListItem(headlineContent={Text(stringResource(R.string.motion_title))},supportingContent={Text(stringResource(R.string.motion_description))},leadingContent={Icon(Icons.Rounded.AutoAwesome,null)},trailingContent={Switch(checked=preferences.motion,onCheckedChange=vm::motion,modifier=Modifier.testTag("motion-setting"))})
                    HorizontalDivider(color=MaterialTheme.colorScheme.surfaceVariant)
                    ListItem(headlineContent={Text(stringResource(R.string.sound_effects))},supportingContent={Text(stringResource(R.string.sound_description))},leadingContent={Icon(Icons.Rounded.TouchApp,null)},trailingContent={Switch(checked=preferences.sound,onCheckedChange=vm::sound,modifier=Modifier.testTag("sound-setting"))})
                }
                Card(shape=RoundedCornerShape(25.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)) {
                    ListItem(headlineContent={Text(stringResource(R.string.privacy_policy))},supportingContent={Text(stringResource(R.string.privacy_intro))},leadingContent={Icon(Icons.Rounded.Shield,null)},trailingContent={TextButton(onClick={dialog="privacy"},modifier=Modifier.testTag("privacy-setting")){Icon(Icons.Rounded.ChevronRight,stringResource(R.string.privacy_policy))}})
                    HorizontalDivider(color=MaterialTheme.colorScheme.surfaceVariant)
                    ListItem(headlineContent={Text(stringResource(R.string.ads_title))},supportingContent={Text(stringResource(if(preferences.adsDecision=="approved")R.string.ads_status else R.string.ads_inactive))},leadingContent={Icon(Icons.Rounded.Info,null)},trailingContent={TextButton(onClick=onReviewAdvertising){Text(stringResource(R.string.ad_parent_review))}})
                }
                Text(stringResource(R.string.data_title),style=MaterialTheme.typography.titleLarge)
                OutlinedButton(onClick={dialog="delete"},enabled=!deleting,shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth().testTag("delete-progress"),contentPadding=PaddingValues(18.dp)) {
                    Icon(Icons.Rounded.DeleteOutline,null);Spacer(Modifier.width(9.dp));Text(stringResource(R.string.reset_all))
                }
                Card(shape=RoundedCornerShape(25.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                        Text(stringResource(R.string.about),style=MaterialTheme.typography.titleLarge)
                        Text(stringResource(R.string.about_body),style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(Modifier.height(22.dp))
            }
        }
    }
    when(dialog) {
        "language" -> AlertDialog(onDismissRequest={dialog=null},title={Text(stringResource(R.string.language_choice))},text={
            Column {
                listOf("en-GB" to R.string.english,"ar" to R.string.arabic,"pt-BR" to R.string.portuguese).forEach {(value,label)->
                    TextButton(onClick={dialog=null;vm.language(value){AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(if(value=="system")""else value))}},modifier=Modifier.fillMaxWidth().testTag("language-$value")){
                        Text(stringResource(label),Modifier.weight(1f));if(preferences.language==value)Icon(Icons.Rounded.Check,null)
                    }
                }
            }
        },confirmButton={TextButton(onClick={dialog=null}){Text(stringResource(R.string.cancel))}})
        "theme" -> AlertDialog(onDismissRequest={dialog=null},title={Text(stringResource(R.string.theme))},text={
            Column {
                listOf("system" to R.string.system_default,"light" to R.string.light,"dark" to R.string.dark).forEach{(value,label)->
                    TextButton(onClick={vm.theme(value);dialog=null},modifier=Modifier.fillMaxWidth().testTag("theme-$value")){
                        Text(stringResource(label),Modifier.weight(1f));if(preferences.theme==value)Icon(Icons.Rounded.Check,null)
                    }
                }
            }
        },confirmButton={TextButton(onClick={dialog=null}){Text(stringResource(R.string.cancel))}})
        "privacy" -> AlertDialog(onDismissRequest={dialog=null},title={Text(stringResource(R.string.privacy_policy))},text={
            Column(Modifier.heightIn(max=450.dp).verticalScroll(rememberScrollState())) {Text(stringResource(R.string.privacy_body),style=MaterialTheme.typography.bodyMedium)}
        },confirmButton={TextButton(onClick={dialog=null}){Text(stringResource(R.string.close))}},dismissButton={
            TextButton(onClick={
                runCatching { context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW,android.net.Uri.parse(PublishingInfo.PRIVACY_URL))) }
                    .onFailure { scope.launch { snack.showSnackbar(linkError) } }
            }){Text(stringResource(R.string.online_policy))}
        })
        "delete" -> AlertDialog(onDismissRequest={dialog=null},title={Text(stringResource(R.string.reset_all))},text={Text(stringResource(R.string.reset_all_message))},
            confirmButton={TextButton(onClick={dialog=null;deleting=true;vm.reset{ok->deleting=false;scope.launch{snack.showSnackbar(if(ok)deleted else failure)}}},modifier=Modifier.testTag("confirm-delete")){Text(stringResource(R.string.delete))}},dismissButton={TextButton(onClick={dialog=null}){Text(stringResource(R.string.cancel))}})
    }
}
