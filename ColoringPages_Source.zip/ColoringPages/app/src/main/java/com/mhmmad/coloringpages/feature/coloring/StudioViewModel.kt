package com.mhmmad.coloringpages.feature.coloring

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mhmmad.coloringpages.core.database.ArtRepository
import com.mhmmad.coloringpages.core.graphics.ArtRenderer
import com.mhmmad.coloringpages.core.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.time.LocalDate

data class StudioState(val renderer: ArtRenderer? = null, val session: ColourSession? = null,
    val selected: Int = 0, val hint: String? = null, val error: Boolean = false, val showCompletion: Boolean = false)
class StudioViewModel(private val repository: ArtRepository, private val artId: String, private val mode: ColourMode,
    private val challengeDate: LocalDate?): ViewModel() {
    private val mutable = MutableStateFlow(StudioState())
    val state = mutable.asStateFlow()
    init { load() }
    fun load() {
        viewModelScope.launch {
            try {
                val drawing = repository.drawing(artId)
                val renderer = withContext(Dispatchers.Default) { ArtRenderer(drawing) }
                val raw = repository.session(artId, mode)
                val valid = drawing.regions.associateBy { it.id }
                val colours = raw.colours.filter { (id,c) -> c in drawing.palette.indices && valid[id]?.let { mode == ColourMode.FREE || it.colour == c } == true }
                val session = raw.copy(colours = colours)
                mutable.value = StudioState(renderer, session, drawing.regions.firstOrNull { it.id !in colours }?.colour ?: 0)
            } catch (_: Exception) { mutable.update { it.copy(error = true) } }
        }
    }
    fun select(colour: Int) { mutable.update { it.copy(selected = colour, hint = null) } }
    fun paint(region: ArtRegion): Boolean {
        val s = mutable.value
        val renderer = s.renderer ?: return false
        val before = s.session ?: return false
        val after = ColourEngine.paint(before, region, s.selected, renderer.drawing.palette.size, renderer.regions.size, System.currentTimeMillis())
        if (before == after) return false
        commit(after)
        return true
    }
    private fun commit(next: ColourSession) {
        val total = mutable.value.renderer?.regions?.size ?: return
        val wasComplete = mutable.value.session?.colours?.size == total
        mutable.update { it.copy(session = next, hint = null, showCompletion = !wasComplete && next.colours.size == total) }
        repository.save(next, challengeDate)
    }
    fun undo() { state.value.session?.let { commit(ColourEngine.undo(it, state.value.renderer!!.regions.size, System.currentTimeMillis())) } }
    fun redo() { state.value.session?.let { commit(ColourEngine.redo(it, state.value.renderer!!.regions.size, System.currentTimeMillis())) } }
    fun hint(): ArtRegion? {
        val s = mutable.value
        val region = s.renderer?.drawing?.regions?.firstOrNull { it.id !in (s.session?.colours ?: emptyMap()) && (mode == ColourMode.FREE || it.colour == s.selected) }
            ?: s.renderer?.drawing?.regions?.firstOrNull { it.id !in (s.session?.colours ?: emptyMap()) }
        if (region != null) mutable.update { it.copy(hint = region.id, selected = if (mode == ColourMode.NUMBERS) region.colour else it.selected) }
        return region
    }
    fun retrySave() { state.value.session?.let { repository.save(it, challengeDate) } }
    fun reset() { commit(ColourSession(artId, mode, updatedAt = System.currentTimeMillis())) }
    fun dismissCompletion() { mutable.update { it.copy(showCompletion = false) } }
}
