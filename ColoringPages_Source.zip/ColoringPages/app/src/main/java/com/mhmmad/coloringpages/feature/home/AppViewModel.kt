package com.mhmmad.coloringpages.feature.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mhmmad.coloringpages.ColoringApplication
import com.mhmmad.coloringpages.core.preferences.Preferences
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel(application: Application): AndroidViewModel(application) {
    private val app = application as ColoringApplication
    val repository = app.repository
    val preferences = app.preferences.data.stateIn(viewModelScope, SharingStarted.Eagerly, Preferences())
    fun theme(value: String) { viewModelScope.launch { app.preferences.theme(value) } }
    fun sound(value: Boolean) { viewModelScope.launch { app.preferences.sound(value) } }
    fun motion(value: Boolean) { viewModelScope.launch { app.preferences.motion(value) } }
    fun language(value: String, after: () -> Unit) { viewModelScope.launch { app.preferences.language(value); after() } }
    fun adsDecision(value: String) { viewModelScope.launch { app.preferences.adsDecision(value) } }
    fun reset(done: (Boolean) -> Unit) { viewModelScope.launch { done(repository.resetAll()) } }
}
