package com.mhmmad.coloringpages.ads

import com.huawei.hms.ads.AdParam
import com.huawei.hms.ads.RequestOptions

/** Children are the intended audience: contextual, non-personalised ads only. */
object AdPolicy {
    const val bannerId = "k1i3em3bm0"
    const val interstitialId = "s9jruxhcil"
    const val enabled = true
    const val sdkIncluded = true
    private const val CHILD_DIRECTED = 1
    private const val NON_PERSONALISED_ONLY = 1
    private const val GENERAL_AUDIENCE = "W"

    fun globalRequestOptions(): RequestOptions = RequestOptions.Builder()
        .setTagForChildProtection(CHILD_DIRECTED)
        .setTagForUnderAgeOfPromise(CHILD_DIRECTED)
        .setNonPersonalizedAd(NON_PERSONALISED_ONLY)
        .setAdContentClassification(GENERAL_AUDIENCE)
        .setRequestLocation(false)
        .build()

    fun request(): AdParam = AdParam.Builder()
        .setTagForChildProtection(CHILD_DIRECTED)
        .setTagForUnderAgeOfPromise(CHILD_DIRECTED)
        .setNonPersonalizedAd(NON_PERSONALISED_ONLY)
        .setAdContentClassification(GENERAL_AUDIENCE)
        .setRequestLocation(false)
        .build()
}
