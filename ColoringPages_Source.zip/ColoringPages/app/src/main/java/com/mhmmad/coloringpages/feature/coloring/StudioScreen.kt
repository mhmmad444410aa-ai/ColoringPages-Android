package com.mhmmad.coloringpages.feature.coloring

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mhmmad.coloringpages.R
import com.mhmmad.coloringpages.core.database.ArtRepository
import com.mhmmad.coloringpages.core.designsystem.*
import com.mhmmad.coloringpages.core.graphics.ColourSound
import com.mhmmad.coloringpages.core.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable fun StudioScreen(vm: StudioViewModel, repository: ArtRepository, art: ArtSummary, language: String,
    soundEnabled: Boolean, onBack: () -> Unit, onNewPicture: () -> Unit) {
    val state by vm.state.collectAsStateWithLifecycle()
    val saving by repository.pendingSaves.collectAsStateWithLifecycle()
    val storageError by repository.storageError.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val sound = remember { ColourSound(context) }
    DisposableEffect(sound) { onDispose { sound.release() } }
    val currentSound by rememberUpdatedState(soundEnabled)
    val scope = rememberCoroutineScope()
    val snackbars = remember { SnackbarHostState() }
    val exportSuccess = stringResource(R.string.export_success)
    val exportError = stringResource(R.string.export_error)
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        if (uri != null) scope.launch {
            val renderer = vm.state.value.renderer
            val colours = vm.state.value.session?.colours
            val ok = withContext(Dispatchers.IO) { runCatching {
                requireNotNull(renderer); requireNotNull(colours)
                context.contentResolver.openOutputStream(uri)?.use { renderer.exportPng(it,colours) } ?: false
            }.getOrDefault(false) }
            snackbars.showSnackbar(if(ok) exportSuccess else exportError)
        }
    }
    var transform by remember(art.id) { mutableStateOf(CanvasTransform(1f,1f)) }
    var options by rememberSaveable { mutableStateOf(false) }
    var showNumbers by rememberSaveable { mutableStateOf(true) }
    var highlight by rememberSaveable { mutableStateOf(true) }
    var restart by rememberSaveable { mutableStateOf(false) }
    val renderer = state.renderer
    val session = state.session
    val motion=LocalArtMotion.current
    var tapGlow by remember {mutableStateOf(Offset.Zero)}
    val glow=remember {Animatable(1f)}
    LaunchedEffect(state.hint) {
        state.hint?.let { id ->
            val label = renderer?.drawing?.regions?.firstOrNull {it.id==id}?.labels?.firstOrNull() ?: return@let
            val zoom = if(label.radius<22) 3f else 1.8f
            val scale = transform.baseScale * zoom
            transform = transform.copy(zoom=zoom,panX=(500-label.x)*scale,panY=(500-label.y)*scale)
        }
    }
    Scaffold(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.45f), snackbarHost = {SnackbarHost(snackbars)}) { insets ->
        Column(Modifier.fillMaxSize().padding(insets).testTag("studio-screen")) {
            Row(Modifier.fillMaxWidth().padding(horizontal=10.dp,vertical=5.dp),verticalAlignment=Alignment.CenterVertically) {
                FilledTonalIconButton(onClick=onBack,shape=RoundedCornerShape(15.dp),colors=IconButtonDefaults.filledTonalIconButtonColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.testTag("studio-back")) {Icon(Icons.AutoMirrored.Rounded.ArrowBack,stringResource(R.string.back))}
                Column(Modifier.weight(1f).padding(horizontal=7.dp)) {
                    Text(art.title(language),style=MaterialTheme.typography.titleMedium,maxLines=1)
                    Text(stringResource(if(session?.mode==ColourMode.FREE) R.string.free_colour else R.string.numbers),style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                }
                FilledTonalIconButton(onClick={options=true},shape=RoundedCornerShape(15.dp),colors=IconButtonDefaults.filledTonalIconButtonColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.testTag("studio-options")) {Icon(Icons.Rounded.Tune,stringResource(R.string.view_options))}
            }
            if (state.error) {
                Column(Modifier.fillMaxSize().padding(30.dp),verticalArrangement=Arrangement.Center) {
                    Text(stringResource(R.string.load_error));Button(onClick=vm::load){Text(stringResource(R.string.retry))}
                }
            } else if (renderer==null || session==null) {
                Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){CircularProgressIndicator()}
            } else {
                Row(Modifier.fillMaxWidth().padding(horizontal=22.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                    LinearProgressIndicator(progress={session.progress(renderer.regions.size)},modifier=Modifier.weight(1f).height(8.dp).clip(CircleShape),color=Teal,trackColor=MaterialTheme.colorScheme.surfaceVariant,gapSize=0.dp,drawStopIndicator={})
                    Text(stringResource(R.string.progress_percent,(session.progress(renderer.regions.size)*100).toInt()),style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.primary,modifier=Modifier.testTag("studio-progress"))
                }
                Text(stringResource(if(session.mode==ColourMode.FREE) R.string.free_instruction else R.string.numbers_instruction),Modifier.padding(horizontal=22.dp,vertical=10.dp),style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                val canvasDescription=stringResource(R.string.studio)
                Canvas(Modifier.padding(horizontal=12.dp).weight(1f).fillMaxWidth().shadow(5.dp,RoundedCornerShape(26.dp)).clip(RoundedCornerShape(26.dp)).background(Color.White)
                    .onSizeChanged { transform=transform.copy(width=it.width.toFloat(),height=it.height.toFloat()) }
                    .testTag("colouring-canvas").semantics {contentDescription=canvasDescription}
                    .pointerInput(renderer) {
                        awaitEachGesture {
                            val down=awaitFirstDown(requireUnconsumed=false)
                            var transformed=false
                            var multiple=false
                            var movement=Offset.Zero
                            var last=down.position
                            do {
                                val event=awaitPointerEvent()
                                val pressed=event.changes.count {it.pressed}
                                if(pressed>1) multiple=true
                                val pan=event.calculatePan()
                                movement+=pan
                                if(multiple || movement.getDistance()>viewConfiguration.touchSlop) transformed=true
                                if(transformed && pressed>0) {
                                    val centroid=event.calculateCentroid(useCurrent=false)
                                    if(centroid.isSpecified) transform=transform.zoomAt(centroid.x,centroid.y,event.calculateZoom(),pan.x,pan.y)
                                    event.changes.forEach { if(it.positionChanged()) it.consume() }
                                }
                                event.changes.firstOrNull {it.id==down.id}?.let {last=it.position}
                            } while(event.changes.any {it.pressed})
                            if(!transformed && !multiple) {
                                val point=transform.toArt(last.x,last.y)
                                renderer.hitTest(point.first,point.second)?.let { region ->
                                    if(vm.paint(region)) {
                                        if(currentSound)sound.click()
                                        if(motion){tapGlow=last;scope.launch{glow.snapTo(0f);glow.animateTo(1f,tween(450))}}
                                    }
                                }
                            }
                        }
                    }) {
                    drawIntoCanvas { composed ->
                        val canvas=composed.nativeCanvas
                        canvas.save();canvas.translate(transform.left,transform.top);canvas.scale(transform.scale,transform.scale)
                        renderer.draw(canvas,session.colours,state.selected,session.mode==ColourMode.NUMBERS && showNumbers,highlight,hintId=state.hint)
                        canvas.restore()
                    }
                    if(glow.value<1f) {
                        drawCircle(Color(renderer.drawing.palette[state.selected]).copy(alpha=(1f-glow.value)*.45f),radius=(8+glow.value*35).dp.toPx(),center=tapGlow,style=androidx.compose.ui.graphics.drawscope.Stroke(3.dp.toPx()))
                    }
                }
                Row(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=6.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceEvenly) {
                    StudioTool(Icons.AutoMirrored.Rounded.Undo,stringResource(R.string.undo),"undo",session.undo.isNotEmpty(),onClick=vm::undo)
                    StudioTool(Icons.AutoMirrored.Rounded.Redo,stringResource(R.string.redo),"redo",session.redo.isNotEmpty(),onClick=vm::redo)
                    StudioTool(Icons.Rounded.Lightbulb,stringResource(R.string.hint),"hint",highlighted=true,onClick={vm.hint()})
                    StudioTool(Icons.Rounded.CenterFocusStrong,stringResource(R.string.reset_view),"fit",onClick={transform=transform.copy(zoom=1f,panX=0f,panY=0f)})
                    StudioTool(Icons.Rounded.FileDownload,stringResource(R.string.save_image),"export",onClick={export.launch("ColoringPages-"+art.id+".png")})
                }
                Text(stringResource(R.string.gesture_instruction),Modifier.fillMaxWidth().padding(bottom=8.dp),style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant,textAlign=androidx.compose.ui.text.style.TextAlign.Center)
                Surface(color=MaterialTheme.colorScheme.surface,shape=RoundedCornerShape(topStart=27.dp,topEnd=27.dp)) {
                    Column {
                        Text(stringResource(R.string.palette_title),Modifier.padding(start=20.dp,top=12.dp),style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurface)
                        LazyRow(Modifier.fillMaxWidth().testTag("palette"),contentPadding=PaddingValues(horizontal=18.dp,vertical=10.dp),horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                            val indices=if(session.mode==ColourMode.NUMBERS) renderer.drawing.regions.map{it.colour}.distinct().sorted() else renderer.drawing.palette.indices.toList()
                            items(indices.size) { slot ->
                                val index=indices[slot]
                                val selected=state.selected==index
                                val matching=renderer.drawing.regions.filter {it.colour==index}
                                val done=matching.isNotEmpty() && matching.all {it.id in session.colours}
                                val desc=stringResource(R.string.colour_number,index+1)
                                val colour=Color(renderer.drawing.palette[index])
                                val ink=if(colour.luminance()>.35f)Ink else Color.White
                                Box(Modifier.size(54.dp).clip(RoundedCornerShape(18.dp)).background(if(selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                                    .padding(3.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface)
                                    .padding(3.dp).clip(RoundedCornerShape(13.dp)).background(colour)
                                    .clickable {vm.select(index)}.testTag("colour-$index")
                                    .semantics {contentDescription=desc;this.selected=selected},contentAlignment=Alignment.Center) {
                                    if(session.mode==ColourMode.NUMBERS && done) Icon(Icons.Rounded.Check,null,tint=ink,modifier=Modifier.size(25.dp))
                                    else if(session.mode==ColourMode.NUMBERS) Text((index+1).toString(),color=ink,fontWeight=FontWeight.ExtraBold,fontSize=21.sp)
                                    else if(selected) Box(Modifier.size(14.dp).clip(CircleShape).background(Color.White))
                                }
                            }
                        }
                        if(storageError) TextButton(onClick=vm::retrySave,modifier=Modifier.fillMaxWidth()) {Text(stringResource(R.string.save_error),color=MaterialTheme.colorScheme.error,style=MaterialTheme.typography.labelSmall)}
                        else Row(Modifier.fillMaxWidth().padding(bottom=10.dp),horizontalArrangement=Arrangement.Center,verticalAlignment=Alignment.CenterVertically) {
                            Icon(if(saving>0) Icons.Rounded.Sync else Icons.Rounded.CheckCircle,null,tint=MaterialTheme.colorScheme.secondary,modifier=Modifier.size(13.dp))
                            Spacer(Modifier.width(5.dp));Text(stringResource(if(saving>0) R.string.saving else R.string.saved),style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
    if(options) AlertDialog(onDismissRequest={options=false},title={Text(stringResource(R.string.view_options))},text={
        Column {
            if(session?.mode==ColourMode.NUMBERS) {
                Row(verticalAlignment=Alignment.CenterVertically){Text(stringResource(R.string.show_numbers),Modifier.weight(1f));Switch(checked=showNumbers,onCheckedChange={showNumbers=it})}
                Row(verticalAlignment=Alignment.CenterVertically){Text(stringResource(R.string.highlight_areas),Modifier.weight(1f));Switch(checked=highlight,onCheckedChange={highlight=it})}
            }
            TextButton(onClick={options=false;restart=true}){Text(stringResource(R.string.restart_picture))}
        }
    },confirmButton={TextButton(onClick={options=false}){Text(stringResource(R.string.close))}})
    if(restart) AlertDialog(onDismissRequest={restart=false},title={Text(stringResource(R.string.restart_picture))},text={Text(stringResource(R.string.restart_message))},
        confirmButton={TextButton(onClick={vm.reset();restart=false}){Text(stringResource(R.string.restart))}},dismissButton={TextButton(onClick={restart=false}){Text(stringResource(R.string.cancel))}})
    if(state.showCompletion && renderer!=null && session!=null) {
        androidx.compose.ui.window.Dialog(onDismissRequest=vm::dismissCompletion) {
            Surface(shape=RoundedCornerShape(30.dp),color=MaterialTheme.colorScheme.surface) {
                Box {
                    Column(Modifier.padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                        Icon(Icons.Rounded.AutoAwesome,null,tint=Sunshine,modifier=Modifier.size(42.dp))
                        Text(stringResource(R.string.completed_title),style=MaterialTheme.typography.headlineSmall)
                        Spacer(Modifier.height(8.dp));Text(stringResource(R.string.completed_body),style=MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(12.dp));ArtThumbnail(repository,art,Modifier.fillMaxWidth().aspectRatio(1f),session.colours,false,language)
                        Spacer(Modifier.height(14.dp));Button(onClick={vm.dismissCompletion();onNewPicture()},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp)){Text(stringResource(R.string.new_picture))}
                        TextButton(onClick={export.launch("ColoringPages-${art.id}.png")}){Text(stringResource(R.string.save_image))}
                        TextButton(onClick=vm::dismissCompletion){Text(stringResource(R.string.close))}
                    }
                    Confetti(Modifier.matchParentSize())
                }
            }
        }
    }
}
@Composable private fun Confetti(modifier: Modifier) {
    val animation=remember {Animatable(0f)}
    LaunchedEffect(Unit){animation.animateTo(1f,tween(1600,easing=LinearEasing))}
    Canvas(modifier) {
        if(animation.value<1f) repeat(26) {i ->
            val x=((i*137)%1000)/1000f*size.width
            val y=(-.2f+animation.value*1.3f+((i*43)%100)/500f)*size.height
            drawCircle(listOf(Purple,Sunshine,Coral,Mint)[i%4],radius=4.dp.toPx(),center=Offset(x,y),alpha=1f-animation.value)
        }
    }
}

@Composable private fun StudioTool(icon:androidx.compose.ui.graphics.vector.ImageVector,label:String,tag:String,enabled:Boolean=true,highlighted:Boolean=false,onClick:()->Unit){
    Surface(onClick=onClick,enabled=enabled,shape=RoundedCornerShape(16.dp),color=if(highlighted)Teal else MaterialTheme.colorScheme.surface,
        contentColor=if(highlighted)Color.White else MaterialTheme.colorScheme.onSurface,modifier=Modifier.widthIn(min=53.dp,max=66.dp).testTag(tag)){
        Column(Modifier.padding(horizontal=4.dp,vertical=7.dp),horizontalAlignment=Alignment.CenterHorizontally){
            Icon(icon,null,Modifier.size(21.dp),tint=if(!enabled)MaterialTheme.colorScheme.onSurface.copy(alpha=.3f)else if(highlighted)Color.White else MaterialTheme.colorScheme.onSurface)
            Text(label,style=MaterialTheme.typography.labelSmall,maxLines=1,overflow=androidx.compose.ui.text.style.TextOverflow.Ellipsis,color=if(!enabled)MaterialTheme.colorScheme.onSurface.copy(alpha=.3f)else if(highlighted)Color.White else MaterialTheme.colorScheme.onSurface)
        }
    }
}
