package com.mhmmad.coloringpages.core.graphics

import android.graphics.*
import androidx.core.graphics.PathParser
import com.mhmmad.coloringpages.core.model.*
import java.io.OutputStream

/** Parsed paths and integer hit masks are created once per cached artwork. */
class ArtRenderer(val drawing: ArtDrawing) {
    data class Cached(val source: ArtRegion, val path: Path, val hit: Region)
    val regions: List<Cached> = drawing.regions.map { r ->
        val path = requireNotNull(PathParser.createPathFromPathData(r.path)).apply { fillType = Path.FillType.EVEN_ODD }
        val highResolution = Path(path).apply { transform(Matrix().apply { setScale(4f, 4f) }) }
        Cached(r, path, Region().apply { setPath(highResolution, Region(0, 0, 4001, 4001)) })
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(37, 48, 74); style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND; strokeWidth = 3.2f }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) }

    fun hitTest(x: Float, y: Float): ArtRegion? {
        if (x !in 0f..1000f || y !in 0f..1000f) return null
        return regions.lastOrNull { it.hit.contains((x * 4).toInt(), (y * 4).toInt()) }?.source
    }
    @Synchronized fun draw(canvas: Canvas, colours: Map<String, Int>, selected: Int = -1, numbers: Boolean = false,
             highlight: Boolean = true, preview: Boolean = false, hintId: String? = null) {
        regions.forEach { cached ->
            val r = cached.source
            val colour = if (preview) r.colour else colours[r.id]
            fill.color = when {
                colour != null && colour in drawing.palette.indices -> drawing.palette[colour]
                r.id == hintId -> Color.rgb(255, 226, 116)
                numbers && highlight && r.colour == selected -> Color.rgb(229, 220, 255)
                else -> Color.WHITE
            }
            canvas.drawPath(cached.path, fill)
            canvas.drawPath(cached.path, outline)
        }
        if (numbers && !preview) regions.forEach { cached ->
            val r = cached.source
            if (r.id !in colours) r.labels.forEach { label ->
                text.textSize = (label.radius * 1.2f).coerceIn(14f, 28f)
                text.color = if (r.colour == selected) Color.rgb(89, 52, 180) else Color.rgb(70, 80, 100)
                canvas.drawText((r.colour + 1).toString(), label.x, label.y - (text.ascent() + text.descent()) / 2, text)
            }
        }
    }
    fun bitmap(colours: Map<String, Int>, size: Int = 1600): Bitmap {
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)
        canvas.scale(size / 1000f, size / 1000f)
        draw(canvas, colours)
        return bitmap
    }
    fun exportPng(stream: OutputStream, colours: Map<String, Int>): Boolean {
        val bitmap = bitmap(colours)
        return try { bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream) } finally { bitmap.recycle() }
    }
}
