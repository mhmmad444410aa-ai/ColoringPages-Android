package com.mhmmad.coloringpages.core.model

object PublishingInfo {
    const val PRIVACY_URL = "https://coloring-pages-privacy-mhmmad.mhmmad444410aa.chatgpt.site"
}
