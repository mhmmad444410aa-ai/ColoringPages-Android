package com.mhmmad.coloringpages.feature.home

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.*
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import com.mhmmad.coloringpages.R
import com.mhmmad.coloringpages.core.database.ArtRepository
import com.mhmmad.coloringpages.core.designsystem.*
import com.mhmmad.coloringpages.core.model.*
import kotlinx.coroutines.launch
import java.time.LocalDate

@Composable fun HomeScreen(repository:ArtRepository,sessions:List<ColourSession>,language:String,
    openArt:(ArtSummary,ColourMode)->Unit,openGallery:(String?)->Unit,openDaily:()->Unit,openParents:()->Unit,openLanguage:()->Unit={}){
    val catalog=repository.catalog
    val daily=ColourEngine.dailyArt(LocalDate.now(),catalog)
    val fresh=remember(catalog){catalog.filter{it.isNew()}.filter{it.id.endsWith("09")}.ifEmpty{catalog.take(6)}}
    LazyColumn(Modifier.fillMaxSize().testTag("home-screen"),contentPadding=PaddingValues(start=20.dp,end=20.dp,top=12.dp,bottom=24.dp),verticalArrangement=Arrangement.spacedBy(18.dp)){
        item{
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                Image(painterResource(R.drawable.brand_mark),null,Modifier.size(43.dp).clip(RoundedCornerShape(13.dp)))
                Column(Modifier.weight(1f).padding(start=10.dp,end=6.dp)){
                    Text(stringResource(R.string.app_name),style=MaterialTheme.typography.titleLarge,maxLines=1,overflow=TextOverflow.Ellipsis)
                    Text(stringResource(R.string.welcome),style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                }
                OutlinedButton(onClick=openLanguage,shape=CircleShape,contentPadding=PaddingValues(0.dp),border=BorderStroke(1.dp,MaterialTheme.colorScheme.outlineVariant),modifier=Modifier.size(40.dp).testTag("home-language")){
                    Text(when(language.substringBefore('-')){"ar"->"AR";"pt"->"PT";else->"EN"},style=MaterialTheme.typography.labelMedium)
                }
                Spacer(Modifier.width(7.dp))
                FilledTonalIconButton(onClick=openParents,modifier=Modifier.size(40.dp).testTag("parent-button"),shape=CircleShape,colors=IconButtonDefaults.filledTonalIconButtonColors(containerColor=MaterialTheme.colorScheme.surfaceVariant)){
                    Icon(Icons.Rounded.Settings,stringResource(R.string.parents),Modifier.size(20.dp))
                }
            }
        }
        item{FeaturedBook(repository,language,openArt)}
        val ongoing=sessions.filter{it.colours.isNotEmpty()&&it.completedAt==null}.take(5)
        if(ongoing.isNotEmpty()){
            item{SectionHeading(stringResource(R.string.continue_colouring))}
            item{LazyRow(horizontalArrangement=Arrangement.spacedBy(12.dp)){items(ongoing,key={it.key}){session->
                catalog.firstOrNull{it.id==session.artId}?.let{art->ArtCard(repository,art,language,session,{openArt(art,session.mode)},Modifier.width(151.dp))}
            }}}
        }
        item{SectionHeading(stringResource(R.string.fresh_pictures),stringResource(R.string.view_all),{openGallery(null)})}
        item{LazyRow(horizontalArrangement=Arrangement.spacedBy(12.dp)){items(fresh,key={it.id}){art->
            ArtCard(repository,art,language,sessions.firstOrNull{it.artId==art.id&&it.mode==ColourMode.NUMBERS},{openArt(art,ColourMode.NUMBERS)},Modifier.width(151.dp).testTag("featured-"+art.id))
        }}}
        item{SectionHeading(stringResource(R.string.categories))}
        items(categoryIds.chunked(2)){pair->
            Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){
                pair.forEach{category->
                    val art=catalog.firstOrNull{it.id==category+"_09"}?:catalog.first{it.category==category}
                    Surface(onClick={openGallery(category)},color=categoryColour(category),shape=RoundedCornerShape(25.dp),modifier=Modifier.weight(1f).testTag("category-"+category)){
                        Column(Modifier.padding(10.dp)){
                            ArtThumbnail(repository,art,Modifier.fillMaxWidth().aspectRatio(1.45f),language=language,paperColour=Color.Transparent)
                            Spacer(Modifier.height(4.dp));Text(stringResource(categoryName(category)),style=MaterialTheme.typography.titleMedium,color=Ink,minLines=2,maxLines=2)
                            Text(stringResource(R.string.picture_count,catalog.count{it.category==category}),style=MaterialTheme.typography.labelSmall,color=Ink.copy(alpha=.7f))
                        }
                    }
                }
            }
        }
        item{
            Surface(onClick=openDaily,color=Color(0xFFEEE7FD),shape=RoundedCornerShape(26.dp),modifier=Modifier.fillMaxWidth().testTag("daily-button")){
                Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){
                    ArtThumbnail(repository,daily,Modifier.size(80.dp),language=language)
                    Column(Modifier.weight(1f).padding(horizontal=13.dp)){
                        Text(stringResource(R.string.daily_subtitle),color=Purple,style=MaterialTheme.typography.labelSmall)
                        Text(daily.title(language),color=Ink,style=MaterialTheme.typography.titleMedium,maxLines=2)
                        Text(stringResource(R.string.daily_microcopy),color=Ink.copy(alpha=.7f),style=MaterialTheme.typography.labelSmall)
                    }
                    Icon(Icons.AutoMirrored.Rounded.ArrowForward,null,tint=Purple,modifier=Modifier.size(20.dp))
                }
            }
        }
        item{
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.Center){
                listOf(Coral,Sunshine,Mint,Purple).forEach{colour->Box(Modifier.padding(3.dp).size(7.dp).clip(CircleShape).background(colour))}
                Spacer(Modifier.width(6.dp));Text(stringResource(R.string.made_for_creativity),style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
@Composable private fun FeaturedBook(repository:ArtRepository,language:String,openArt:(ArtSummary,ColourMode)->Unit){
    val ids=listOf("flowers_09","buildings_09","space_09")
    val headings=listOf(R.string.greeting,R.string.hero_architecture,R.string.hero_space)
    val backgrounds=listOf(Color(0xFFDFF3E8),Color(0xFFFCE8D7),Color(0xFFEAE6FC))
    val pager=rememberPagerState(pageCount={ids.size});val scope=rememberCoroutineScope()
    Column{
        HorizontalPager(state=pager,pageSpacing=12.dp,modifier=Modifier.fillMaxWidth().testTag("featured-carousel")){page->
            val art=repository.catalog.firstOrNull{it.id==ids[page]}?:repository.catalog.first()
            val floating=if(LocalArtMotion.current){
                val loop=rememberInfiniteTransition(label="floating-art")
                loop.animateFloat(-3f,3f,infiniteRepeatable(tween(2600,easing=FastOutSlowInEasing),RepeatMode.Reverse),label="float")
            }else remember{mutableFloatStateOf(0f)}
            Surface(color=backgrounds[page],shape=RoundedCornerShape(29.dp),modifier=Modifier.fillMaxWidth()){
                Box(Modifier.heightIn(min=240.dp)){
                    PaintSprinkles(Modifier.matchParentSize())
                    Row(Modifier.padding(start=18.dp,end=11.dp,top=19.dp,bottom=18.dp),verticalAlignment=Alignment.CenterVertically){
                        Column(Modifier.weight(1.05f)){
                            Pill(stringResource(R.string.hero_eyebrow),Color.White.copy(alpha=.8f),Teal)
                            Spacer(Modifier.height(12.dp));Text(stringResource(headings[page]),style=MaterialTheme.typography.headlineSmall,color=Ink)
                            Spacer(Modifier.height(7.dp));Text(stringResource(R.string.hero_body),style=MaterialTheme.typography.bodySmall,color=Ink.copy(alpha=.72f))
                            Spacer(Modifier.height(14.dp));Button(onClick={openArt(art,ColourMode.NUMBERS)},shape=CircleShape,contentPadding=PaddingValues(14.dp,11.dp),colors=ButtonDefaults.buttonColors(containerColor=Ink,contentColor=Color.White),modifier=Modifier.testTag("start-colouring")){
                                Text(stringResource(R.string.start_colouring),style=MaterialTheme.typography.labelMedium);Spacer(Modifier.width(5.dp));Icon(Icons.AutoMirrored.Rounded.ArrowForward,null,Modifier.size(16.dp))
                            }
                        }
                        Box(Modifier.weight(1f).height(200.dp).padding(start=6.dp),contentAlignment=Alignment.Center){
                            Surface(color=Color.White.copy(alpha=.5f),shape=RoundedCornerShape(20.dp),modifier=Modifier.fillMaxWidth().height(172.dp).rotate(-9f).offset(x=4.dp,y=3.dp)){}
                            ArtThumbnail(repository,art,Modifier.fillMaxWidth().height(181.dp).graphicsLayer{rotationZ=5f;translationY=floating.value.dp.toPx()}.shadow(8.dp,RoundedCornerShape(20.dp)),language=language,animated=true)
                            Surface(color=Sunshine,shape=CircleShape,modifier=Modifier.align(Alignment.BottomEnd).size(41.dp).rotate(-12f)){
                                Box(contentAlignment=Alignment.Center){Icon(Icons.Rounded.Brush,null,Modifier.size(23.dp),tint=Ink)}
                            }
                        }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top=10.dp),horizontalArrangement=Arrangement.Center){
            repeat(ids.size){index->Box(Modifier.padding(horizontal=3.dp).size(width=if(pager.currentPage==index)22.dp else 7.dp,height=7.dp).clip(CircleShape).background(if(pager.currentPage==index)Teal else Color(0xFFDCE3DA)).clickable{scope.launch{pager.animateScrollToPage(index)}})}
        }
    }
}
