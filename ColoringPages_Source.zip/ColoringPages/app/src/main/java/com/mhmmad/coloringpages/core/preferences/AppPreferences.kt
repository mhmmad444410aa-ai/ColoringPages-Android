package com.mhmmad.coloringpages.core.preferences

import android.content.Context
import androidx.datastore.core.handlers.ReplaceFileCorruptionHandler
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.*
import java.io.IOException

private val Context.preferenceStore by preferencesDataStore("settings", corruptionHandler = ReplaceFileCorruptionHandler { emptyPreferences() })
data class Preferences(val language: String = "en-GB", val theme: String = "light", val sound: Boolean = true, val motion: Boolean = true, val adsDecision: String = "loading")
class AppPreferences(private val context: Context) {
    private val language = stringPreferencesKey("language")
    private val theme = stringPreferencesKey("theme")
    private val sound = booleanPreferencesKey("sound")
    private val motion = booleanPreferencesKey("motion")
    private val adsDecision = stringPreferencesKey("ads_decision")
    val data: Flow<Preferences> = context.preferenceStore.data.catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { Preferences(it[language]?.takeIf { tag -> tag in listOf("en-GB","ar","pt-BR") } ?: "en-GB", it[theme] ?: "light", it[sound] ?: true, it[motion] ?: true, it[adsDecision] ?: "unset") }
    suspend fun language(value: String) { context.preferenceStore.edit { it[language] = value } }
    suspend fun theme(value: String) { context.preferenceStore.edit { it[theme] = value } }
    suspend fun sound(value: Boolean) { context.preferenceStore.edit { it[sound] = value } }
    suspend fun motion(value: Boolean) { context.preferenceStore.edit { it[motion] = value } }
    suspend fun adsDecision(value: String) { require(value in listOf("approved", "declined")); context.preferenceStore.edit { it[adsDecision] = value } }
}
