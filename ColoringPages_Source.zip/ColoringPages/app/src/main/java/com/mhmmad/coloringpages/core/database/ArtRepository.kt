package com.mhmmad.coloringpages.core.database

import android.content.Context
import androidx.room.Room
import com.mhmmad.coloringpages.core.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

class ArtRepository(private val context: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private fun open() = Room.databaseBuilder(context, ArtDatabase::class.java, "colouring.db")
        .addMigrations(ArtDatabase.MIGRATION_1_2).build()
    private var db = open()
    private val drawings = mutableMapOf<String, ArtDrawing>()
    val sessions = MutableStateFlow<List<ColourSession>>(emptyList())
    val challenges = MutableStateFlow<List<DailyChallengeEntity>>(emptyList())
    val storageError = MutableStateFlow(false)
    val pendingSaves = MutableStateFlow(0)
    val ready = MutableStateFlow(false)
    val catalog: List<ArtSummary> by lazy {
        val array = JSONArray(context.assets.open("catalog.json").bufferedReader().use { it.readText() })
        (0 until array.length()).map { i -> array.getJSONObject(i).let { obj ->
            val titles = obj.getJSONObject("titles")
            ArtSummary(obj.getString("id"), obj.getString("category"),
                mapOf("en" to titles.getString("en"), "ar" to titles.getString("ar"), "pt" to titles.getString("pt")),
                obj.getString("difficulty"), obj.getInt("regionCount"))
        } }
    }
    private var observeJob: Job? = null
    private sealed interface Write {
        data class Save(val session: ColourSession, val date: LocalDate?): Write
        data class Reset(val done: CompletableDeferred<Boolean>): Write
    }
    private val writes = Channel<Write>(Channel.UNLIMITED)
    init {
        observe()
        scope.launch {
            for (write in writes) when (write) {
                is Write.Save -> {
                    try {
                        val s = write.session
                        val challenge = if (write.date != null && s.completedAt != null)
                            DailyChallengeEntity(write.date.toString(), s.artId, s.completedAt) else null
                        db.artDao().save(encode(s), challenge)
                        storageError.value = false
                    } catch (_: Exception) { storageError.value = true }
                    finally { pendingSaves.update { (it - 1).coerceAtLeast(0) } }
                }
                is Write.Reset -> {
                    try {
                        observeJob?.cancelAndJoin()
                        if (storageError.value) {
                            db.close()
                            context.deleteDatabase("colouring.db")
                            db = open()
                        } else db.artDao().clearProgress()
                        sessions.value = emptyList(); challenges.value = emptyList(); storageError.value = false
                        observe(); write.done.complete(true)
                    } catch (_: Exception) { storageError.value = true; write.done.complete(false) }
                }
            }
        }
    }
    private fun observe() {
        observeJob = scope.launch {
            try {
                coroutineScope {
                    launch { db.artDao().observeAll().collect { data -> sessions.value = data.map(::decode); ready.value = true } }
                    launch { db.artDao().observeChallenges().collect { challenges.value = it } }
                }
            } catch (cancelled: CancellationException) { throw cancelled }
            catch (_: Exception) { storageError.value = true; ready.value = true }
        }
    }
    fun save(session: ColourSession, date: LocalDate? = null) {
        pendingSaves.update { it + 1 }
        if (!writes.trySend(Write.Save(session, date)).isSuccess) {
            pendingSaves.update { (it - 1).coerceAtLeast(0) }; storageError.value = true
        }
    }
    suspend fun resetAll(): Boolean {
        val done = CompletableDeferred<Boolean>()
        writes.send(Write.Reset(done))
        return done.await()
    }
    suspend fun session(id: String, mode: ColourMode): ColourSession = withContext(Dispatchers.IO) {
        // Drain accepted saves before loading another studio for the same picture.
        pendingSaves.first { it == 0 }
        try { db.artDao().session("$id:${mode.name}")?.let(::decode) ?: ColourSession(id, mode) }
        catch (_: Exception) { storageError.value = true; ColourSession(id, mode) }
    }
    suspend fun drawing(id: String): ArtDrawing = withContext(Dispatchers.IO) {
        synchronized(drawings) { drawings[id] } ?: run {
            require(catalog.any { it.id == id })
            val o = JSONObject(context.assets.open("art/$id.json").bufferedReader().use { it.readText() })
            val p = o.getJSONArray("palette")
            val r = o.getJSONArray("regions")
            val art = ArtDrawing(id, (0 until p.length()).map { android.graphics.Color.parseColor(p.getString(it)) },
                (0 until r.length()).map { i -> r.getJSONObject(i).let { region ->
                    val labels = region.getJSONArray("labels")
                    ArtRegion(region.getString("id"), region.getString("d"), region.getInt("colour"),
                        (0 until labels.length()).map { j -> labels.getJSONArray(j).let { LabelPoint(it.getDouble(0).toFloat(), it.getDouble(1).toFloat(), it.getDouble(2).toFloat()) } })
                } })
            synchronized(drawings) { drawings[id] = art }
            art
        }
    }
    companion object {
        private fun history(changes: List<ColourChange>): String = JSONArray().apply {
            changes.forEach { put(JSONArray().put(it.regionId).put(it.before ?: JSONObject.NULL).put(it.after ?: JSONObject.NULL)) }
        }.toString()
        private fun parseHistory(json: String): List<ColourChange> = JSONArray(json).let { array ->
            (0 until array.length()).map { i -> array.getJSONArray(i).let { ColourChange(it.getString(0), if (it.isNull(1)) null else it.getInt(1), if (it.isNull(2)) null else it.getInt(2)) } }
        }
        fun encode(s: ColourSession) = SessionEntity(s.key, s.artId, s.mode.name, JSONObject(s.colours).toString(), history(s.undo), history(s.redo), s.updatedAt, s.completedAt)
        fun decode(e: SessionEntity): ColourSession {
            val colours = JSONObject(e.coloursJson)
            return ColourSession(e.artId, ColourMode.valueOf(e.mode), colours.keys().asSequence().associateWith { colours.getInt(it) },
                parseHistory(e.undoJson), parseHistory(e.redoJson), e.updatedAt, e.completedAt)
        }
    }
}
