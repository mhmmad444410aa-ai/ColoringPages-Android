package com.mhmmad.coloringpages.feature.gallery

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mhmmad.coloringpages.R
import com.mhmmad.coloringpages.core.database.ArtRepository
import com.mhmmad.coloringpages.core.designsystem.*
import com.mhmmad.coloringpages.core.model.*

@Composable fun GalleryScreen(repository:ArtRepository,sessions:List<ColourSession>,language:String,
    initialCategory:String?,myArtwork:Boolean,openArt:(ArtSummary,ColourMode)->Unit,openGallery:()->Unit){
    var category by rememberSaveable(initialCategory,myArtwork){mutableStateOf(initialCategory)}
    var completedOnly by rememberSaveable(myArtwork){mutableStateOf(false)}
    var freeMode by rememberSaveable{mutableStateOf(false)}
    var query by rememberSaveable(myArtwork){mutableStateOf("")}
    val saved=sessions.filter{it.colours.isNotEmpty()}.associateBy{it.key}
    val names=categoryIds.associateWith{stringResource(categoryName(it))}
    fun matches(art:ArtSummary)= (category==null||art.category==category) &&
        (query.isBlank()||art.title(language).contains(query,true)||art.titles.values.any{it.contains(query,true)}||names[art.category]?.contains(query,true)==true)
    val entries:List<Pair<ArtSummary,ColourSession?>> = if(myArtwork)saved.values.filter{if(completedOnly)it.completedAt!=null else it.completedAt==null}
        .sortedByDescending{it.updatedAt}.mapNotNull{session->repository.catalog.firstOrNull{it.id==session.artId&&matches(it)}?.let{it to session}}
    else repository.catalog.filter(::matches).map{art->art to saved[art.id+":"+if(freeMode)ColourMode.FREE.name else ColourMode.NUMBERS.name]}
    Column(Modifier.fillMaxSize().testTag(if(myArtwork)"artwork-screen" else "gallery-screen")){
        Column(Modifier.padding(start=20.dp,end=20.dp,top=18.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){
                Column(Modifier.weight(1f)){
                    Text(stringResource(if(myArtwork)R.string.artwork_eyebrow else R.string.library_eyebrow),style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.primary)
                    Text(stringResource(if(myArtwork)R.string.my_art else R.string.colouring_book),style=MaterialTheme.typography.headlineLarge)
                }
                Box(Modifier.size(48.dp).clip(RoundedCornerShape(17.dp)).background(if(myArtwork)Color(0xFFFFE8DE)else Color(0xFFE1F1E6)),contentAlignment=Alignment.Center){
                    Icon(if(myArtwork)Icons.Rounded.Palette else Icons.Rounded.AutoAwesomeMosaic,null,tint=if(myArtwork)Color(0xFFD76C4C)else Teal,modifier=Modifier.size(27.dp))
                }
            }
            Spacer(Modifier.height(5.dp));Text(stringResource(if(myArtwork)R.string.your_art_subtitle else R.string.library_subtitle,if(myArtwork)saved.size else repository.catalog.size),style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(13.dp))
            OutlinedTextField(value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth().testTag("art-search"),singleLine=true,shape=RoundedCornerShape(18.dp),
                placeholder={Text(stringResource(R.string.search_pictures),style=MaterialTheme.typography.bodyMedium)},leadingIcon={Icon(Icons.Rounded.Search,null)},
                trailingIcon={if(query.isNotEmpty())IconButton(onClick={query=""}){Icon(Icons.Rounded.Close,stringResource(R.string.clear_search))}},
                colors=OutlinedTextFieldDefaults.colors(unfocusedContainerColor=MaterialTheme.colorScheme.surface,focusedContainerColor=MaterialTheme.colorScheme.surface,unfocusedBorderColor=MaterialTheme.colorScheme.outlineVariant))
            Spacer(Modifier.height(13.dp))
            Surface(color=MaterialTheme.colorScheme.surfaceVariant,shape=RoundedCornerShape(17.dp)){
                Row(Modifier.fillMaxWidth().padding(4.dp),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                    listOf(false,true).forEach{second->
                        val chosen=if(myArtwork)completedOnly==second else freeMode==second
                        Surface(onClick={if(myArtwork)completedOnly=second else freeMode=second},color=if(chosen)MaterialTheme.colorScheme.surface else Color.Transparent,shape=RoundedCornerShape(13.dp),shadowElevation=if(chosen)2.dp else 0.dp,
                            modifier=Modifier.weight(1f).testTag(if(myArtwork){if(second)"completed-tab" else "progress-tab"}else{if(second)"free-mode" else "number-mode"})){
                            Row(Modifier.padding(vertical=11.dp,horizontal=6.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.Center){
                                Icon(if(myArtwork){if(second)Icons.Rounded.CheckCircle else Icons.Rounded.Brush}else{if(second)Icons.Rounded.Brush else Icons.Rounded.Pin},null,Modifier.size(17.dp),tint=if(chosen)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(Modifier.width(6.dp));Text(stringResource(if(myArtwork){if(second)R.string.finished else R.string.art_in_progress}else{if(second)R.string.free_colour else R.string.numbers}),style=MaterialTheme.typography.labelMedium,maxLines=1,overflow=TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }
        LazyRow(contentPadding=PaddingValues(start=20.dp,end=20.dp,top=12.dp,bottom=10.dp),horizontalArrangement=Arrangement.spacedBy(7.dp)){
            item{CollectionChip(stringResource(R.string.all_art),category==null,MaterialTheme.colorScheme.surfaceVariant){category=null}}
            items(categoryIds){id->CollectionChip(names.getValue(id),category==id,categoryColour(id)){category=id}}
        }
        if(myArtwork && saved.isEmpty())EmptyArtwork(openGallery)
        else if(entries.isEmpty())Column(Modifier.fillMaxWidth().padding(32.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Rounded.SearchOff,null,Modifier.size(42.dp),tint=MaterialTheme.colorScheme.onSurfaceVariant);Spacer(Modifier.height(12.dp));Text(stringResource(R.string.no_matches));TextButton(onClick={query="";category=null}){Text(stringResource(R.string.clear_filters))}}
        else LazyVerticalGrid(modifier=Modifier.weight(1f).testTag("gallery-grid"),columns=GridCells.Adaptive(145.dp),contentPadding=PaddingValues(start=18.dp,end=18.dp,bottom=20.dp),horizontalArrangement=Arrangement.spacedBy(12.dp),verticalArrangement=Arrangement.spacedBy(13.dp)){
            items(entries,key={it.second?.key?:it.first.id}){(art,session)->
                ArtCard(repository,art,language,session,{openArt(art,session?.mode?:if(freeMode)ColourMode.FREE else ColourMode.NUMBERS)},Modifier.fillMaxWidth().testTag("art-"+art.id),showMode=myArtwork)
            }
        }
    }
}
@Composable private fun CollectionChip(text:String,selected:Boolean,tint:Color,onClick:()->Unit){
    Surface(onClick=onClick,color=if(selected)Ink else MaterialTheme.colorScheme.surface,shape=CircleShape,border=if(selected)null else BorderStroke(1.dp,MaterialTheme.colorScheme.outlineVariant)){
        Row(Modifier.padding(horizontal=12.dp,vertical=9.dp),verticalAlignment=Alignment.CenterVertically){
            Box(Modifier.size(8.dp).clip(CircleShape).background(if(selected)Mint else tint))
            Spacer(Modifier.width(6.dp));Text(text,style=MaterialTheme.typography.labelMedium,color=if(selected)Color.White else MaterialTheme.colorScheme.onSurface)
        }
    }
}
