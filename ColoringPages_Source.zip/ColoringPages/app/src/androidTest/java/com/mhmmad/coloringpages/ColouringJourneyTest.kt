package com.mhmmad.coloringpages

import android.graphics.Bitmap
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.platform.app.InstrumentationRegistry
import com.mhmmad.coloringpages.core.model.*
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import java.io.File

/** UI tests use the real renderer, Room, settings and actual touch gestures. */
class ColouringJourneyTest {
    @get:Rule val rule=createAndroidComposeRule<MainActivity>()
    private val repo get()=(rule.activity.application as ColoringApplication).repository
    private fun ready(){rule.waitUntil(90_000){repo.ready.value};rule.waitForIdle()}
    @Before fun resetTestData(){ready();runBlocking{repo.resetAll()};rule.waitForIdle()}
    private fun settle(){rule.waitUntil(60_000){repo.pendingSaves.value==0};rule.waitForIdle()}
    private fun screenshot(name:String){
        rule.waitForIdle()
        val device=InstrumentationRegistry.getInstrumentation().uiAutomation
        val bitmap=device.takeScreenshot()
        val dir=File(rule.activity.getExternalFilesDir(null),"screenshots").apply{mkdirs()}
        File(dir,"$name.png").outputStream().use{bitmap.compress(Bitmap.CompressFormat.PNG,100,it)}
        bitmap.recycle()
    }
    private fun tapRegion(region:ArtRegion){
        rule.onNodeWithTag("palette").performScrollToNode(hasTestTag("colour-${region.colour}"))
        rule.onNodeWithTag("colour-${region.colour}").performClick()
        val node=rule.onNodeWithTag("colouring-canvas")
        val bounds=node.fetchSemanticsNode().boundsInRoot
        val transform=CanvasTransform(bounds.width,bounds.height)
        val label=region.labels.maxBy{it.radius}
        val point=transform.toScreen(label.x,label.y)
        node.performTouchInput{click(Offset(point.first,point.second))}
        settle()
    }
    @Test fun numberColourUndoRedoResumeAndRealScreenshots(){
        ready();screenshot("01_Home_EN")
        rule.onNodeWithTag("nav-gallery").performClick();rule.waitForIdle();screenshot("02_Gallery_EN")
        rule.onNodeWithTag("art-flowers_01").performClick()
        rule.waitUntil(60_000){rule.onAllNodesWithTag("colouring-canvas").fetchSemanticsNodes().isNotEmpty()}
        val drawing=runBlocking{repo.drawing("flowers_01")}
        val region=drawing.regions.first{it.colour<4 && it.labels.any{l->l.radius>20}}
        tapRegion(region)
        rule.waitUntil(30_000){repo.sessions.value.any{it.artId=="flowers_01" && it.colours.containsKey(region.id)}}
        screenshot("03_Studio_EN")
        rule.onNodeWithTag("undo").performClick();settle()
        rule.waitUntil(30_000){repo.sessions.value.none{it.artId=="flowers_01" && it.colours.containsKey(region.id)}}
        rule.onNodeWithTag("redo").performClick();settle()
        rule.onNodeWithTag("studio-back").performClick()
        rule.onNodeWithTag("nav-artwork").performClick()
        rule.onNodeWithTag("art-flowers_01").performClick()
        rule.waitUntil(30_000){rule.onAllNodesWithTag("studio-progress").fetchSemanticsNodes().isNotEmpty()}
        assertTrue(repo.sessions.value.first{it.artId=="flowers_01"}.colours.containsKey(region.id))
        screenshot("04_Saved_Artwork_EN")
    }
    @Test fun completeEverySailboatAreaShowsActualCompletion(){
        ready();rule.onNodeWithTag("nav-gallery").performClick()
        rule.onNodeWithTag("gallery-grid").performScrollToNode(hasTestTag("art-vehicles_02"))
        rule.onNodeWithTag("art-vehicles_02").performClick()
        rule.waitUntil(60_000){rule.onAllNodesWithTag("colouring-canvas").fetchSemanticsNodes().isNotEmpty()}
        val drawing=runBlocking{repo.drawing("vehicles_02")}
        drawing.regions.forEach(::tapRegion)
        rule.waitUntil(60_000){repo.sessions.value.any{it.artId=="vehicles_02" && it.completedAt!=null}}
        rule.onNodeWithText(rule.activity.getString(R.string.completed_title)).assertIsDisplayed()
        screenshot("05_Completion_EN")
    }
    @Test fun parentalGateRejectsWrongAnswerAndSettingsOpen(){
        ready();rule.onNodeWithTag("parent-button").performClick()
        rule.onNodeWithTag("parent-digit-0").performClick()
        rule.onNodeWithTag("parent-enter").performClick()
        rule.onNodeWithText(rule.activity.getString(R.string.wrong_answer)).assertIsDisplayed()
        val question=rule.onAllNodes(SemanticsMatcher("multiplication question"){it.config.contains(SemanticsProperties.Text) && it.config[SemanticsProperties.Text].any{t->Regex("\\d+ × \\d+ = \\?").matches(t.text)}}).fetchSemanticsNodes().first().config[SemanticsProperties.Text].joinToString(""){it.text}
        val nums=Regex("\\d+").findAll(question).map{it.value.toInt()}.toList()
        rule.onNodeWithTag("parent-clear").performClick();(nums[0]*nums[1]).toString().forEach{digit->rule.onNodeWithTag("parent-digit-$digit").performClick()}
        rule.onNodeWithTag("parent-enter").performClick()
        rule.onNodeWithTag("parent-screen").assertExists();screenshot("06_Parent_Area_EN")
        rule.onNodeWithTag("privacy-setting").performScrollTo().performClick()
        rule.onNodeWithText(rule.activity.getString(R.string.privacy_body),substring=false).assertExists()
    }
}
