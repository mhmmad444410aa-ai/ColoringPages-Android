# Room generates the implementations; keep annotations used by it.
-keepattributes Signature,*Annotation*
