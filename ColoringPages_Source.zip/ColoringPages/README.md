# Coloring Pages — Version 1.2.0 (unbuilt source with Petal Ads)

Android Kotlin / Compose children's colouring app. The source contains 72 illustrated pictures and parent-gated Huawei banner/interstitial advertising integration using supplied production placement IDs.

**This ZIP is not a signed APK.** The build and signing have not been verified in this environment. Uploading the older `1.1.0` APK will not include ads. See `docs/HUAWEI_ADS_RELEASE_CHECKLIST.md` before attempting publication.

Standard build: `./gradlew :app:assembleDebug :app:testDebugUnitTest` then use original production keystore for `:app:assembleRelease` (secrets kept outside source).
