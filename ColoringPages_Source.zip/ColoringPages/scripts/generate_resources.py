"""Regenerate the complete UI strings from translations.json without changing artwork."""
from pathlib import Path
import json,xml.etree.ElementTree as E
R=Path(__file__).resolve().parents[1]
strings=json.loads((R/'scripts/translations.json').read_text())
for folder,tag in [('values','en'),('values-en-rGB','en'),('values-ar','ar'),('values-pt-rBR','pt')]:
 root=E.Element('resources')
 for key,values in strings.items():E.SubElement(root,'string',name=key).text=values[tag]
 E.indent(root,space='    ');E.ElementTree(root).write(R/'app/src/main/res'/folder/'strings.xml',encoding='utf-8',xml_declaration=True)
print('Wrote',len(strings),'strings in four complete resource sets')
