"""Static weight instances for reliable rounded type on Android API 23 and above."""
from pathlib import Path
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
R=Path(__file__).resolve().parents[1]
source=R/'scripts/font-source/Nunito-Variable.ttf'
for label,weight,style in [('regular',400,'Regular'),('bold',700,'Bold'),('extrabold',800,'ExtraBold')]:
 font=instantiateVariableFont(TTFont(source),{'wght':weight},inplace=False)
 for name in font['name'].names:
  values={1:'Colouring Rounded',2:style,3:'ColouringRounded-'+style,4:'Colouring Rounded '+style,6:'ColouringRounded-'+style,16:'Colouring Rounded',17:style}
  if name.nameID in values:name.string=values[name.nameID].encode(name.getEncoding(),errors='replace')
 font.save(R/'app/src/main/res/font'/('rounded_'+label+'.ttf'))
print('Generated static 400, 700 and 800 font weights')
