"""Build-independent integrity checks for catalogue, translations, paths and disclosure."""
from pathlib import Path
from collections import Counter
import json,xml.etree.ElementTree as E,hashlib
from svgpathtools import parse_path
from shapely.geometry import Polygon,Point
from shapely.ops import unary_union
R=Path(__file__).resolve().parents[1]
catalog=json.loads((R/'app/src/main/assets/catalog.json').read_text())
assert len(catalog)==72
assert set(Counter(a['category'] for a in catalog).values())=={12}
seen=set();total=0
for summary in catalog:
 art=json.loads((R/'app/src/main/assets/art'/(summary['id']+'.json')).read_text())
 assert art['id'] not in seen;seen.add(art['id'])
 assert hashlib.sha256((R/'app/src/main/assets/art'/(summary['id']+'.json')).read_bytes()).hexdigest()==summary['sha256']
 assert len(art['regions'])==summary['regionCount']
 assert len({r['id'] for r in art['regions']})==len(art['regions'])
 for region in art['regions']:
  path=parse_path(region['d']);assert len(path)>2
  assert 0<=region['colour']<len(art['palette'])
  assert region['labels']
  for x,y,r in region['labels']:assert 0<=x<=1000 and 0<=y<=1000 and r>=8
 total+=len(art['regions'])
res=R/'app/src/main/res'
base={e.get('name') for e in E.parse(res/'values/strings.xml').getroot()}
for locale in ['values-ar','values-en-rGB','values-pt-rBR']:
 root=E.parse(res/locale/'strings.xml').getroot()
 assert {e.get('name') for e in root}==base
 assert all((e.text or '').strip() for e in root)
manifest=E.parse(R/'app/src/main/AndroidManifest.xml').getroot()
assert manifest.find('uses-permission') is None
assert not any('com.huawei.hms' in p.read_text() for p in R.glob('**/*.gradle.kts'))
print(f'PASS: {len(catalog)} distinct pictures, {total} regions, 6 × 12 collections, {len(base)} complete strings × 4 resource sets; no declared permissions or ads SDK.')
