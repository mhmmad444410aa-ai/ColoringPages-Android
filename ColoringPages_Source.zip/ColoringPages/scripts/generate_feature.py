"""Store feature graphic made from the app's original vector art and brand icon."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parents[1]
im=Image.new('RGB',(1024,500),'#E4F4E9');d=ImageDraw.Draw(im)
fp=str(R/'scripts/font-source/Nunito-Variable.ttf')
def font(n,bold=False):
 f=ImageFont.truetype(fp,n)
 try:f.set_variation_by_axes([800 if bold else 500])
 except Exception:pass
 return f
d.ellipse((730,-210,1180,260),fill='#D2EBD8');d.ellipse((-200,360,290,840),fill='#D2EBD8')
icon=Image.open(R/'store/ColoringPages_Icon_512.png').resize((66,66),Image.Resampling.LANCZOS)
mask=Image.new('L',(66,66));ImageDraw.Draw(mask).rounded_rectangle((0,0,66,66),radius=16,fill=255);im.paste(icon,(48,38),mask)
d.text((130,45),'YOUR LITTLE ART STUDIO',font=font(17,True),fill='#168575')
d.text((47,125),'Coloring',font=font(73,True),fill='#283C47');d.text((47,207),'Pages',font=font(73,True),fill='#283C47')
d.text((51,308),'Little colours. Big imagination.',font=font(23),fill='#52766D')
x=50
for text in ['By number','Free colour','Offline']:
 w=int(d.textlength(text,font=font(15,True)))+30;d.rounded_rectangle((x,363,x+w,405),radius=20,fill='#FFFFFF');d.text((x+15,373),text,font=font(15,True),fill='#168575');x+=w+8
for ident,xy,size,angle in [('buildings_09',(686,53),225,-8),('vehicles_09',(738,265),197,7),('flowers_09',(508,151),235,5)]:
 art=Image.open(R/'store/art-previews'/(ident+'.png')).convert('RGB').resize((size,size),Image.Resampling.LANCZOS)
 paper=Image.new('RGBA',(size+18,size+18),'#FFFFFF');paper.alpha_composite(art.convert('RGBA'),(9,9));paper=paper.rotate(angle,resample=Image.Resampling.BICUBIC,expand=True)
 im.paste(paper,xy,paper)
d.text((52,443),'72 original pictures · 6 illustrated collections',font=font(18,True),fill='#283C47')
im.save(R/'store/ColoringPages_Feature_1024x500.jpg',quality=96)
print(im.mode,im.size)
