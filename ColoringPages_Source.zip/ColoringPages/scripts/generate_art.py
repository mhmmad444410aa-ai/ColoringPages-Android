"""Original vector library. Run with Python + shapely/cairosvg/Pillow.
Every numbered region is a disjoint visible polygon, not a raster flood fill.
All 48 compositions are authored here; no external images or fonts are copied.
"""
from pathlib import Path
from math import sin, cos, pi
import json, hashlib
from shapely.geometry import Point, Polygon, box, MultiPolygon
from shapely.affinity import scale, rotate
from shapely.ops import unary_union, polylabel
from PIL import Image, ImageDraw, ImageFont
import cairosvg
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'app/src/main/assets/art'
OUT.mkdir(parents=True,exist_ok=True)
PALETTE=['#FFD35A','#FF7895','#7856E8','#59C8F5','#70D8AB','#F4A35D','#B49BF5','#477DAD']

def ellipse(x,y,rx,ry):return scale(Point(x,y).buffer(1,quad_segs=24),rx,ry,origin=(x,y))
def poly(pts):return Polygon(pts).buffer(0)
def rounded(x,y,w,h,r=18):return box(x+r,y+r,x+w-r,y+h-r).buffer(r,quad_segs=8)
def star(x,y,r,n=5,inner=.46,angle=-pi/2):return poly([(x+(r if i%2==0 else r*inner)*cos(angle+i*pi/n),y+(r if i%2==0 else r*inner)*sin(angle+i*pi/n)) for i in range(n*2)])
def regular(x,y,r,n,ang=-pi/2):return poly([(x+r*cos(ang+i*2*pi/n),y+r*sin(ang+i*2*pi/n)) for i in range(n)])
def leaf(x,y,rx=45,ry=95,a=0):return rotate(ellipse(x,y,rx,ry),a,origin=(x,y))
class Scene:
 def __init__(self,id,category,titles,difficulty):self.id=id;self.category=category;self.titles=dict(zip(['en','ar','pt'],titles));self.difficulty=difficulty;self.layers=[]
 def add(self,g,c):
  if not g.is_valid:g=g.buffer(0)
  self.layers.append((g.intersection(box(35,35,965,965)),c%8));return self
 def rect(self,x,y,w,h,c,r=0):return self.add(rounded(x,y,w,h,r) if r else box(x,y,x+w,y+h),c)
 def oval(self,x,y,rx,ry,c):return self.add(ellipse(x,y,rx,ry),c)
 def polygon(self,pts,c):return self.add(poly(pts),c)
 def disk(self,x,y,r,c):return self.oval(x,y,r,r,c)
 def star(self,x,y,r,c,n=5):return self.add(star(x,y,r,n),c)
 def plant(self,x,y,size=1,c=1,petals=6):
  self.rect(x-9*size,y,18*size,240*size,4,7*size)
  self.add(leaf(x-53*size,y+150*size,30*size,80*size,55),4)
  self.add(leaf(x+52*size,y+100*size,28*size,72*size,-55),4)
  for i in range(petals):
   a=2*pi*i/petals
   self.add(rotate(ellipse(x+70*size*cos(a),y+70*size*sin(a),45*size,62*size),a*180/pi+90,origin=(x+70*size*cos(a),y+70*size*sin(a))),c)
  self.disk(x,y,47*size,0);return self
 def cloud(self,x,y,s=1):
  g=unary_union([ellipse(x,y,90*s,35*s),Point(x-45*s,y-10*s).buffer(40*s),Point(x+12*s,y-28*s).buffer(50*s)])
  return self.add(g,3)
 def pine(self,x,y,s=1):
  self.rect(x-12*s,y,24*s,200*s,5)
  for i in range(3):
   yy=y+50*s-i*70*s;ww=(120-i*24)*s
   self.polygon([(x-ww,yy+90*s),(x,yy-100*s),(x+ww,yy+90*s)],4)
  return self
 def wheel(self,x,y,r):
  self.disk(x,y,r,7);self.disk(x,y,r*.55,6);self.disk(x,y,r*.19,0);return self
 def windows(self,x,y,n=3,rows=1,w=50,h=70,gap=26):
  for row in range(rows):
   for col in range(n):self.rect(x+col*(w+gap),y+row*(h+gap),w,h,3,8)
  return self
 def build(self):
  regions=[];above=Polygon()
  for geom,c in reversed(self.layers):
   g=geom.difference(above).buffer(0)
   above=unary_union([above,geom])
   parts=list(g.geoms) if isinstance(g,MultiPolygon) else ([g] if g.geom_type=='Polygon' else [p for p in getattr(g,'geoms',[]) if p.geom_type=='Polygon'])
   parts=[p for p in parts if p.area>180]
   if not parts:continue
   d=[];labels=[]
   for p in parts:
    for ring in [p.exterior,*p.interiors]:
     pts=list(ring.coords)
     d.append('M'+' L'.join(f'{x:.1f},{y:.1f}' for x,y in pts[:-1])+' Z')
    q=polylabel(p,tolerance=1)
    radius=q.distance(p.boundary)
    if radius>=9:labels.append([round(q.x,1),round(q.y,1),round(min(radius,30),1)])
   if not labels:
    # Tiny visible decorations are united with a neighbouring region of the same colour later.
    q=max(parts,key=lambda p:p.area).representative_point();labels=[[round(q.x,1),round(q.y,1),8]]
   regions.append({'id':f'r{len(regions):03}','d':' '.join(d),'colour':c,'labels':labels})
  regions.reverse()
  # Stable identifiers follow visible drawing order.
  for i,r in enumerate(regions):r['id']=f'r{i:03}'
  data=dict(id=self.id,category=self.category,titles=self.titles,difficulty=self.difficulty,palette=PALETTE,regions=regions)
  (OUT/(self.id+'.json')).write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')))
  paths=''.join(f'<path d="{r["d"]}" fill="{PALETTE[r["colour"]]}" fill-rule="evenodd" stroke="#25304A" stroke-width="4" stroke-linejoin="round"/>' for r in regions)
  svg=f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000"><rect width="1000" height="1000" fill="white"/>{paths}</svg>'
  preview=ROOT/'store/art-previews';preview.mkdir(exist_ok=True,parents=True)
  (preview/(self.id+'.svg')).write_text(svg)
  cairosvg.svg2png(bytestring=svg.encode(),write_to=str(preview/(self.id+'.png')),output_width=400,output_height=400)
  return {k:v for k,v in data.items() if k not in ['regions','palette']}|{'regionCount':len(regions),'sha256':hashlib.sha256((OUT/(self.id+'.json')).read_bytes()).hexdigest()}
SCENES=[]
def scene(id,cat,titles,diff=0):
 s=Scene(id,cat,titles,['easy','medium','hard'][diff]);SCENES.append(s);return s
# Flowers: eight distinct arrangements.
s=scene('flowers_01','flowers',('Sunshine bloom','زهرة الشمس','Flor de sol'))
s.rect(250,865,500,35,4,15).plant(500,330,1.35,0,10).polygon([(360,700),(640,700),(600,865),(400,865)],2).rect(342,687,316,50,6,15)
s=scene('flowers_02','flowers',('Tulip trio','ثلاث زهور توليب','Trio de tulipas'))
for x,y,c in [(300,380,1),(500,270,2),(700,400,5)]:
 s.rect(x-10,y+50,20,400-(y-270),4,8).add(leaf(x-55,y+210,35,100,55),4).add(leaf(x+50,y+155,35,95,-55),4)
 s.polygon([(x-90,y-70),(x-35,y-20),(x,y-90),(x+35,y-20),(x+90,y-70),(x+70,y+70),(x,y+110),(x-70,y+70)],c)
s.polygon([(200,710),(800,710),(730,890),(270,890)],5).rect(180,690,640,45,0,12)
s=scene('flowers_03','flowers',('Cactus corner','حديقة الصبّار','Cantinho dos cactos'))
for x,y,r,h,c in [(240,440,65,330,4),(490,300,80,450,4),(760,500,90,250,3)]:
 s.add(rounded(x-r,y,2*r,h, r),c).rect(x-r-25,740,2*r+50,120,5,22).rect(x-r-40,720,2*r+80,40,0,12)
 if x<600:s.add(rounded(x-r-75,y+100,80,130,35).union(box(x-r-25,y+175,x,y+225)),c)
s.star(242,407,37,1,6).plant(770,470,.32,1)
s=scene('flowers_04','flowers',('Watering day','يوم سقي الزهور','Dia de regar'),1)
s.plant(270,410,.9,1).plant(700,300,1.1,6).rect(135,745,700,115,4,28)
s.add(ellipse(580,650,180,170).difference(ellipse(580,650,125,115)),2).rect(350,590,250,210,3,45).polygon([(365,640),(230,560),(195,590),(350,735)],3).oval(205,566,45,22,0)
for i in range(3):s.oval(160+i*45,640+i*38,11,18,3)
s=scene('flowers_05','flowers',('Glass garden','حديقة زجاجية','Jardim de vidro'),1)
s.polygon([(260,760),(200,330),(500,140),(800,330),(740,760)],3).polygon([(255,680),(745,680),(730,780),(270,780)],5)
for x,y,k in [(360,590,.55),(620,560,.65),(490,440,.7)]:s.plant(x,y,k,1 if x<500 else 2)
s.polygon([(200,330),(500,390),(800,330),(500,140)],6).rect(245,780,510,45,2,10)
s=scene('flowers_06','flowers',('Window blossoms','زهور النافذة','Flores na janela'),1)
s.rect(175,140,650,620,2,28).rect(210,175,580,540,3,12).rect(478,175,44,540,6).rect(210,420,580,35,6)
for x,y,c in [(300,490,1),(500,470,0),(700,500,2)]:s.plant(x,y,.65,c)
s.rect(200,730,600,140,5,20).rect(175,715,650,40,0,12)
s=scene('flowers_07','flowers',('Hanging baskets','سلال الزهور المعلّقة','Cestas suspensas'),2)
s.rect(100,95,800,25,5,8)
for x,y in [(300,450),(700,570)]:
 s.polygon([(x-130,y+130),(x,y-300),(x+130,y+130),(x+110,y+140),(x,y-265),(x-110,y+140)],7)
 for dx,dy,c in [(-90,0,1),(70,-50,6),(0,-130,0)]:s.plant(x+dx,y+dy,.48,c)
 s.polygon([(x-140,y+105),(x+140,y+105),(x+100,y+250),(x-100,y+250)],5)
 for j in range(3):s.rect(x-105,y+135+j*35,210,13,0,5)
s=scene('flowers_08','flowers',('Garden gate','بوابة الحديقة','Portão do jardim'),2)
s.rect(100,700,800,110,4,30)
for x in [250,500,750]:s.rect(x-22,250,44,500,5,14)
for y in [390,610]:s.rect(180,y,640,30,5,10)
for x,y,k,c in [(230,300,.62,1),(510,380,.75,0),(760,240,.65,6),(350,640,.55,2),(690,650,.58,1)]:s.plant(x,y,k,c)
# Nature
s=scene('nature_01','nature',('Alpine lake','بحيرة الجبال','Lago alpino'))
s.disk(760,220,95,0).polygon([(80,580),(320,180),(600,580)],6).polygon([(400,590),(650,240),(930,590)],2)
s.polygon([(222,343),(320,180),(426,343),(355,320),(315,370),(280,320)],3).oval(510,730,420,150,3).pine(180,640,.7).pine(830,670,.6)
s=scene('nature_02','nature',('Sunset island','جزيرة الغروب','Ilha ao pôr do sol'))
s.disk(500,370,165,0).rect(80,520,840,340,3,50).oval(520,680,250,85,5)
s.polygon([(520,660),(560,340),(585,340),(560,670)],5)
for a in [-70,-30,10,50,90]:s.add(leaf(560+110*cos(a*pi/180),350+50*sin(a*pi/180),45,150,a-90),4)
for i in range(4):s.rect(150+i*100,760+(i%2)*45,120,10,7,5)
s=scene('nature_03','nature',('Desert dunes','كثبان الصحراء','Dunas do deserto'))
s.disk(730,230,100,0).polygon([(60,650),(330,390),(640,710),(940,510),(940,900),(60,900)],5).polygon([(60,810),(520,490),(940,790),(940,920),(60,920)],0)
s.add(rounded(230,340,65,300,30),4).add(rounded(160,430,80,55,20),4).add(rounded(160,380,40,90,18),4).rect(280,490,80,40,4,15).rect(330,430,35,90,4,16)
s=scene('nature_04','nature',('Waterfall valley','وادي الشلّال','Vale da cachoeira'),1)
s.cloud(240,180,.8).disk(770,170,70,0).polygon([(80,740),(100,350),(390,260),(550,500),(800,300),(930,800)],5)
s.polygon([(380,300),(570,310),(550,540),(630,730),(400,800),(450,550)],3).oval(510,810,340,90,3)
for x,y,k in [(200,570,.65),(780,580,.8),(850,760,.45)]:s.pine(x,y,k)
for x,y in [(440,400),(485,570),(530,690)]:s.rect(x,y,12,90,7,6)
s=scene('nature_05','nature',('Forest trail','درب الغابة','Trilha na floresta'),1)
s.disk(520,220,75,0).oval(500,800,440,115,4).polygon([(450,900),(600,900),(540,700),(590,550),(480,550),(470,700)],5)
for x,y,k in [(150,500,.85),(350,450,.65),(770,480,.8),(850,700,.6),(240,720,.55)]:s.pine(x,y,k)
s=scene('nature_06','nature',('River bridge','جسر النهر','Ponte do rio'),1)
s.cloud(240,200,1).disk(760,210,65,0).polygon([(60,600),(250,400),(470,590),(700,390),(950,620),(950,860),(60,860)],4)
s.polygon([(440,560),(565,560),(720,900),(240,900)],3)
s.add(box(150,530,850,650).difference(ellipse(500,650,180,95)),5).rect(150,510,700,32,2,10)
for x in [190,290,390,490,590,690,790]:s.rect(x,450,18,60,2,5)
s=scene('nature_07','nature',('Snowy retreat','كوخ الثلوج','Refúgio na neve'),2)
s.cloud(240,160,.7).polygon([(50,610),(290,230),(530,610)],6).polygon([(460,610),(720,190),(950,610)],7)
for x,y in [(290,230),(720,190)]:s.polygon([(x-80,y+125),(x,y),(x+80,y+125),(x+30,y+105),(x,y+140),(x-40,y+105)],3)
s.oval(500,840,450,80,3).rect(340,580,320,230,5,10).polygon([(290,590),(500,390),(710,590)],2).polygon([(310,570),(500,390),(690,570),(620,550),(500,445),(380,550)],3).rect(465,680,70,130,2,12).windows(375,625,2,1,55,65,140)
s.pine(160,650,.65).pine(820,630,.8)
for x,y in [(180,320),(450,220),(620,310),(850,390),(100,450)]:s.star(x,y,20,0,6)
s=scene('nature_08','nature',('Meadow morning','صباح في المرج','Manhã no campo'),2)
s.disk(230,200,90,0).cloud(680,210,1).polygon([(60,600),(250,430),(500,560),(750,450),(940,600),(940,880),(60,880)],4).polygon([(60,780),(400,650),(940,780),(940,900),(60,900)],0)
s.pine(780,580,.7)
for x,y,k in [(200,700,.42),(420,630,.38),(650,760,.48),(820,800,.3)]:s.plant(x,y,k,1,5)
# Vehicles
s=scene('vehicles_01','vehicles',('Colour express','قطار الألوان','Expresso das cores'))
s.rect(80,790,840,20,7,5).rect(120,500,440,220,2,35).rect(530,300,220,420,1,30).rect(505,280,270,45,0,12).rect(180,385,65,120,5,12).rect(120,365,180,35,0,12).windows(575,350,1,1,125,130)
for x in [220,430,650]:s.wheel(x,720,80)
s.cloud(250,220,.7)
s=scene('vehicles_02','vehicles',('Little sailboat','القارب الشراعي','Pequeno veleiro'))
s.rect(70,780,860,90,3,40).polygon([(150,650),(850,650),(700,790),(300,790)],5).rect(485,175,25,480,7,8).polygon([(475,200),(475,620),(170,620)],2).polygon([(525,270),(525,620),(820,620)],1).disk(760,190,75,0).cloud(230,200,.7)
s=scene('vehicles_03','vehicles',('Balloon adventure','رحلة المنطاد','Aventura de balão'))
s.oval(500,380,245,280,0)
for dx,c in [(-150,1),(0,2),(150,3)]:s.add(ellipse(500+dx*.55,380,65,267),c)
s.rect(390,640,15,130,7,5).rect(595,640,15,130,7,5).rect(370,750,260,140,5,25).rect(350,730,300,40,6,10).cloud(180,600,.8).cloud(820,240,.75)
s=scene('vehicles_04','vehicles',('Busy excavator','الحفّار النشيط','Escavadeira em ação'),1)
s.rect(180,720,550,130,7,65)
for x in [250,370,490,610]:s.disk(x,785,37,6)
s.rect(240,500,400,220,0,25).rect(320,340,250,200,5,20).rect(350,370,185,130,3,10).polygon([(620,520),(720,300),(790,330),(700,590)],0).polygon([(740,330),(850,470),(810,510),(690,380)],5).polygon([(810,470),(925,510),(905,670),(800,630)],0).rect(80,870,840,20,4,10)
s=scene('vehicles_05','vehicles',('Garden tractor','جرّار الحديقة','Trator de jardim'),1)
s.rect(160,550,600,170,4,25).rect(230,350,230,240,2,15).rect(200,325,290,35,0,12).windows(270,390,1,1,145,140).rect(620,380,35,180,7,8)
s.wheel(300,700,145).wheel(690,735,95)
for x in [520,565,610]:s.rect(x,590,20,75,0,5)
s.rect(90,875,820,25,5,10)
s=scene('vehicles_06','vehicles',('Weekend camper','حافلة الرحلات','Van de fim de semana'),1)
s.rect(120,360,760,390,3,85).rect(120,540,760,200,1,30).windows(180,410,3,1,130,125,50).rect(750,600,90,50,0,15).rect(125,615,50,60,5,10).wheel(300,745,100).wheel(720,745,100).rect(265,265,430,90,5,20)
for x in [320,520,630]:s.rect(x,260,15,100,2,4)
s=scene('vehicles_07','vehicles',('Airport glider','طائرة المطار','Planador do aeroporto'),2)
s.cloud(190,260,.8).cloud(810,650,.9).polygon([(100,570),(390,490),(500,190),(575,190),(530,490),(850,540),(920,620),(510,600),(290,780),(220,780),(340,590)],3)
s.oval(520,535,265,65,0).polygon([(280,500),(220,380),(280,365),(390,510)],2).polygon([(650,540),(620,680),(680,690),(740,560)],6)
for x in [390,455,520,585,650]:s.disk(x,525,18,2)
s=scene('vehicles_08','vehicles',('City bicycle','دراجة المدينة','Bicicleta urbana'),2)
for x in [250,760]:s.add(ellipse(x,700,170,170).difference(ellipse(x,700,145,145)),7);s.disk(x,700,20,0)
s.polygon([(250,700),(425,460),(570,700),(250,700),(455,680),(610,450),(630,465),(480,720),(250,720)],1)
s.polygon([(570,700),(550,570),(610,360),(630,365),(575,575),(590,700)],2).rect(355,435,150,30,5,15).rect(590,330,150,25,5,10).rect(705,330,25,80,5,10)
s.disk(465,705,45,6).rect(470,700,80,16,0,6).rect(520,705,45,15,7,5).rect(100,900,800,15,4,6)
# Architecture
s=scene('buildings_01','buildings',('Cosy cottage','الكوخ الدافئ','Chalé aconchegante'))
s.rect(230,450,540,380,5,18).polygon([(160,470),(500,180),(840,470)],2).rect(440,630,120,200,6,35).windows(285,540,2,1,95,110,240).disk(500,375,50,0).rect(650,250,65,150,1,10).rect(160,835,680,35,4,15)
s=scene('buildings_02','buildings',('Seaside light','منارة الساحل','Farol à beira-mar'))
s.rect(80,800,840,80,3,30).polygon([(340,780),(410,300),(590,300),(660,780)],1)
s.polygon([(390,440),(610,440),(630,560),(370,560)],0).rect(385,250,230,100,3,10).polygon([(355,250),(500,130),(645,250)],2).rect(350,340,300,25,7,8).rect(465,650,70,130,2,20).disk(800,190,60,0).cloud(180,300,.7)
s=scene('buildings_03','buildings',('Windmill hill','طاحونة التل','Moinho da colina'))
s.oval(500,850,430,80,4).polygon([(350,810),(400,350),(600,350),(650,810)],5).polygon([(365,350),(500,190),(635,350)],2)
for a in [0,90,180,270]:s.add(rotate(poly([(485,480),(480,170),(550,170),(520,485)]),a,origin=(500,490)),0)
s.disk(500,490,42,1).rect(460,680,80,130,2,20).cloud(800,250,.7)
s=scene('buildings_04','buildings',('Rainbow castle','قلعة الألوان','Castelo das cores'),1)
s.rect(230,500,540,320,6,15)
for x in [230,680]:
 s.rect(x-60,330,150,490,1,15).polygon([(x-100,340),(x+15,150),(x+130,340)],2).windows(x-15,405,1,2,60,85,50)
s.rect(380,350,240,450,5,12).polygon([(345,350),(500,175),(655,350)],2).rect(430,650,140,170,0,65).windows(445,430,1,1,110,110).rect(150,825,700,35,4,15)
s=scene('buildings_05','buildings',('Peaceful courtyard','فناء المسجد','Pátio tranquilo'),1)
s.rect(280,500,480,300,5,15).add(ellipse(520,500,200,180).intersection(box(280,280,760,500)),4).rect(505,275,20,60,7,5)
s.rect(140,280,100,520,6,10).polygon([(125,285),(190,140),(255,285)],2).rect(120,400,140,25,0,6)
s.rect(465,620,115,180,2,55).windows(325,580,2,1,70,125,245).rect(110,810,760,45,4,15).disk(810,180,70,0)
s=scene('buildings_06','buildings',('Lantern pavilion','جناح الحديقة','Pavilhão do jardim'),1)
s.rect(260,700,480,35,5,10)
for x in [300,650]:s.rect(x,420,50,280,1,10)
s.polygon([(170,450),(340,360),(500,230),(660,360),(830,450)],2).polygon([(240,400),(500,200),(760,400),(660,380),(500,290),(340,380)],6)
s.rect(460,450,80,140,0,28).rect(490,590,20,45,5,6).rect(200,740,600,40,5,12).rect(160,800,680,40,4,12).cloud(200,200,.6)
s=scene('buildings_07','buildings',('Little town','المدينة الصغيرة','Pequena cidade'),2)
for x,y,w,h,c in [(110,400,220,400,1),(360,260,260,540,6),(650,460,240,340,5)]:
 s.rect(x,y,w,h,c,15).polygon([(x-20,y),(x+w/2,y-140),(x+w+20,y)],2).windows(x+30,y+55,2,2,55,80,35).rect(x+w/2-30,700,60,100,0,20)
s.rect(80,815,840,40,4,15)
for x in [150,500,830]:s.rect(x,850,80,15,0,5)
s=scene('buildings_08','buildings',('Treehouse hideaway','بيت الشجرة','Casa na árvore'),2)
s.add(ellipse(500,380,370,270).union(ellipse(250,490,160,150)).union(ellipse(760,500,160,150)),4).rect(450,520,100,380,5,20).rect(280,400,440,270,0,20).polygon([(225,410),(500,180),(775,410)],2).windows(325,465,2,1,95,120,145).rect(240,675,520,30,5,10)
s.rect(590,705,22,200,5,7).rect(730,705,22,200,5,7)
for y in [735,785,835,885]:s.rect(590,y,162,18,5,5)
s.disk(170,200,55,0)
# Space
s=scene('space_01','space',('Solar dance','رقصة الكواكب','Dança dos planetas'))
s.disk(500,500,145,0)
for x,y,r,c in [(220,250,70,1),(780,250,90,3),(220,750,95,2),(780,740,80,4)]:s.disk(x,y,r,c)
for x,y in [(120,480),(470,150),(570,850),(900,470)]:s.star(x,y,33,6)
s.add(rotate(ellipse(780,740,145,28).difference(ellipse(780,740,108,13)),-25,origin=(780,740)),5)
s=scene('space_02','space',('Moon rocket','صاروخ القمر','Foguete lunar'))
s.disk(780,230,120,0).disk(815,220,35,5).disk(740,270,22,5)
s.polygon([(320,700),(240,820),(250,600),(330,490)],2).polygon([(600,700),(680,820),(670,600),(590,490)],2).rect(320,300,280,440,1,70).polygon([(320,330),(460,120),(600,330)],2).disk(460,440,80,3).disk(460,440,50,6).polygon([(380,750),(460,920),(540,750)],0)
for x,y in [(150,210),(160,470),(800,620),(740,880)]:s.star(x,y,35,0)
s=scene('space_03','space',('Stargazing','رصد النجوم','Observando estrelas'))
s.polygon([(485,520),(290,880),(320,890),(500,560),(680,890),(710,880),(520,520)],5).rect(485,530,28,360,5,8)
s.add(rotate(rounded(260,360,480,140,40),-28,origin=(500,430)),2).add(rotate(rounded(665,315,70,180,15),-28,origin=(500,430)),6).disk(500,530,40,0)
for x,y,r in [(160,210,40),(560,160,45),(820,580,30),(800,180,60)]:s.star(x,y,r,0)
s=scene('space_04','space',('Orbit satellite','القمر الصناعي','Satélite em órbita'),1)
s.disk(190,780,150,3).rect(370,350,260,280,0,28)
for x in [100,660]:
 s.rect(x,370,240,230,2,12)
 for dx in [15,90,165]:
  for yy in [390,495]:s.rect(x+dx,yy,60,85,3,5)
s.rect(340,465,30,35,7).rect(630,465,30,35,7).rect(485,240,30,110,7,8).add(ellipse(500,230,140,70).intersection(box(350,230,650,310)),1).star(800,180,50,0)
s=scene('space_05','space',('Lunar explorer','عربة القمر','Explorador lunar'),1)
s.oval(500,840,440,75,6)
s.rect(230,550,540,170,0,25).rect(345,380,280,180,2,25).windows(380,420,2,1,80,90,45)
for x in [300,500,700]:s.wheel(x,740,75)
s.rect(620,280,18,220,7,6).add(ellipse(628,260,100,60).intersection(box(500,260,750,330)),1).star(780,150,40,0).disk(200,200,80,3)
s=scene('space_06','space',('Space greenhouse','الدفيئة الفضائية','Estufa espacial'),1)
s.add(ellipse(500,520,320,310).intersection(box(150,200,850,610)),3).rect(180,600,640,160,6,25)
s.rect(488,210,24,390,7,8).rect(190,460,620,20,7,8)
s.plant(360,490,.55,1).plant(650,450,.65,0).rect(300,735,400,65,2,15)
s.star(150,220,40,0).star(850,300,45,0).disk(800,110,45,1)
s=scene('space_07','space',('Cosmic rings','الحلقات الكونية','Anéis cósmicos'),2)
for x,y,r,c in [(320,300,160,2),(730,630,170,3),(230,760,80,1),(770,200,65,4)]:
 s.disk(x,y,r,c)
 if r>100:s.add(rotate(ellipse(x,y,r*1.55,r*.36).difference(ellipse(x,y,r*1.25,r*.20)),-30,origin=(x,y)),0)
for x,y in [(100,470),(500,520),(500,850),(900,400),(480,100)]:s.star(x,y,30,6,6)
s=scene('space_08','space',('Orbital workshop','ورشة المدار','Oficina orbital'),2)
s.rect(390,370,220,260,0,35).rect(360,450,280,110,1,20).rect(480,200,40,170,7,10).rect(440,170,120,50,6,15).rect(480,630,40,180,7,10).rect(440,800,120,40,6,12)
for x in [90,680]:
 s.rect(x,330,230,340,2,15)
 for xx in [15,85,155]:
  for yy in [20,120,220]:s.rect(x+xx,330+yy,55,80,3,6)
s.rect(320,480,40,35,7).rect(640,480,40,35,7).disk(500,500,45,3)
for x,y in [(200,170),(800,820),(170,830)]:s.star(x,y,35,0)
# Geometry: each is an independently constructed composition.
s=scene('geometric_01','geometric',('Prism star','نجمة المنشور','Estrela de prisma'))
for i in range(8):
 a=i*pi/4;b=(i+1)*pi/4;m=(a+b)/2
 s.polygon([(500,500),(500+360*cos(a),500+360*sin(a)),(500+190*cos(m),500+190*sin(m))],i)
 s.polygon([(500,500),(500+190*cos(m),500+190*sin(m)),(500+360*cos(b),500+360*sin(b))],(i+3)%8)
s.disk(500,500,55,0)
s=scene('geometric_02','geometric',('Patchwork quilt','رقع الألوان','Colcha de retalhos'),2)
for row in range(4):
 for col in range(4):
  x=140+col*180;y=140+row*180;c=(row*3+col)%8
  s.polygon([(x,y),(x+180,y),(x+90,y+90)],c).polygon([(x+180,y),(x+180,y+180),(x+90,y+90)],c+2).polygon([(x+180,y+180),(x,y+180),(x+90,y+90)],c+4).polygon([(x,y+180),(x,y),(x+90,y+90)],c+6)
s=scene('geometric_03','geometric',('Circle garden','حديقة الدوائر','Jardim de círculos'))
for x,y,r,c in [(500,500,360,2),(500,260,110,1),(740,500,110,3),(500,740,110,0),(260,500,110,4)]:s.disk(x,y,r,c)
s.disk(500,500,170,6).star(500,500,130,0,8).disk(500,500,50,1)
s=scene('geometric_04','geometric',('Glass arch','قوس الزجاج','Arco de vitral'),1)
s.add(rounded(200,160,600,720,280),2)
for i in range(7):
 a=pi+i*pi/7;b=pi+(i+1)*pi/7
 s.polygon([(500,470),(500+270*cos(a),470+270*sin(a)),(500+270*cos(b),470+270*sin(b))],i)
for row in range(3):
 for col in range(3):s.rect(240+col*175,490+row*110,165,100,(row*2+col)%8,8)
s.disk(500,470,50,0)
s=scene('geometric_05','geometric',('Isometric blocks','مكعّبات الألوان','Blocos isométricos'),1)
for row in range(3):
 for col in range(3):
  x=230+col*245+(row%2)*45;y=180+row*230;c=(col+row)%6
  s.polygon([(x,y),(x+90,y-50),(x+180,y),(x+90,y+55)],c)
  s.polygon([(x,y),(x+90,y+55),(x+90,y+165),(x,y+110)],c+2)
  s.polygon([(x+90,y+55),(x+180,y),(x+180,y+110),(x+90,y+165)],c+4)
s=scene('geometric_06','geometric',('Woven ribbons','شرائط منسوجة','Fitas entrelaçadas'),1)
for i in range(5):
 x=120+i*155
 s.polygon([(x,120),(x+90,120),(x+250,880),(x+160,880)],i)
for j in range(5):
 y=160+j*145
 s.polygon([(90,y),(910,y+110),(910,y+180),(90,y+70)],j+3)
s=scene('geometric_07','geometric',('Honeycomb mosaic','فسيفساء سداسية','Mosaico hexagonal'),2)
for row in range(5):
 for col in range(5):
  x=145+col*155+(row%2)*77;y=155+row*140
  if x<910:s.add(regular(x,y,84,6,pi/6),(row+col*2)%8).add(regular(x,y,44,6,pi/6),(row*2+col+3)%8)
s=scene('geometric_08','geometric',('Kaleidoscope petals','بتلات هندسية','Pétalas caleidoscópicas'),2)
for radius,n,rr in [(340,12,95),(215,12,70),(100,8,45)]:
 for i in range(n):
  a=2*pi*i/n
  s.add(rotate(ellipse(500+radius*cos(a),500+radius*sin(a),rr,rr*.48),a*180/pi,origin=(500+radius*cos(a),500+radius*sin(a))),(i+radius//100)%8)
s.star(500,500,70,0,8).disk(500,500,27,1)

if __name__=='__main__':
 catalog=[s.build() for s in SCENES]
 (ROOT/'app/src/main/assets/catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2))
 sheet=Image.new('RGB',(8*210,6*250),'#F8F7FF');d=ImageDraw.Draw(sheet)
 for i,s in enumerate(catalog):
  im=Image.open(ROOT/'store/art-previews'/(s['id']+'.png')).convert('RGB').resize((200,200))
  x=(i%8)*210+5;y=(i//8)*250
  sheet.paste(im,(x,y));d.text((x+5,y+205),s['id'],fill='#25304A');d.text((x+5,y+222),str(s['regionCount'])+' regions',fill='#7856E8')
 sheet.save(ROOT/'store/48-artworks-contact-sheet.jpg',quality=92)
 print('Original drawings:',len(catalog),'Regions:',sum(s['regionCount'] for s in catalog),'Range:',min(s['regionCount'] for s in catalog),max(s['regionCount'] for s in catalog))
