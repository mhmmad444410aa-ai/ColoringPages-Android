"""Original palette-and-pencil icon. SVG, Android adaptive vector and opaque PNGs."""
from pathlib import Path
from math import sin,cos,pi
from PIL import Image
import cairosvg,xml.etree.ElementTree as E
R=Path(__file__).resolve().parents[1]
shapes=[]
def path(d,c,dy=0):shapes.append((d,c,dy))
def polygon(points,c):path('M'+' L'.join(f'{x:.2f},{y:.2f}' for x,y in points)+' Z',c)
def circle(x,y,r,c):path(f'M{x-r},{y} a{r},{r} 0 1,0 {2*r},0 a{r},{r} 0 1,0 {-2*r},0',c)
def rotate(points,angle=43):
 a=angle*pi/180
 return [(326+(x-326)*cos(a)-(y-255)*sin(a),255+(x-326)*sin(a)+(y-255)*cos(a)) for x,y in points]
palette='M112,309 C69,230 105,141 187,112 C269,82 371,117 399,188 C418,236 391,280 352,275 C322,271 308,285 312,311 C319,358 273,397 225,384 C176,371 136,353 112,309 Z'
path(palette,'#10766B',12);path(palette,'#FFFEF4')
path('M112,309 C132,344 172,359 223,370 C260,380 292,361 307,338 C295,379 262,398 225,384 C176,371 136,353 112,309 Z','#E4EDDC')
for x,y,r,c in [(151,226,24,'#FF927E'),(199,160,25,'#FFD15C'),(276,147,25,'#9D85DF'),(347,193,23,'#70CBE1'),(159,300,23,'#8DCE9D')]:
 circle(x,y,r,c);circle(x-5,y-6,r*.22,'#FFFFFF')
circle(305,236,23,'#168575');circle(305,242,17,'#116F65')
# A diagonal pencil casts a short shadow and has an eraser, ferrule, facets and graphite tip.
for pts,c in [([(300,154),(352,154),(352,349),(326,396),(300,349)],'#116F65'),
 ([(300,147),(352,147),(352,337),(300,337)],'#FF896B'),
 ([(300,147),(317,147),(317,337),(300,337)],'#FFAA81'),
 ([(340,147),(352,147),(352,337),(340,337)],'#E97061'),
 ([(300,337),(326,390),(352,337)],'#FFE0AE'),
 ([(317,372),(326,390),(335,372)],'#283C47'),
 ([(300,132),(352,132),(352,165),(300,165)],'#FFF8EB'),
 ([(300,142),(352,142),(352,151),(300,151)],'#DADFD8'),
 ([(300,116),(307,106),(345,106),(352,116),(352,132),(300,132)],'#D6BDF2')]:polygon(rotate(pts),c)
polygon([(422,81),(429,102),(450,109),(429,116),(422,137),(415,116),(394,109),(415,102)],'#FFFFEF')
circle(96,133,9,'#AAE5C6');circle(403,398,7,'#FFE5A6')
paths=''.join(f'<path d="{d}" fill="{c}" transform="translate(0 {dy})"/>' for d,c,dy in shapes)
svg=f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><defs><linearGradient id="bg" x2="1" y2="1"><stop stop-color="#33B49B"/><stop offset="1" stop-color="#117D77"/></linearGradient></defs><rect width="512" height="512" fill="url(#bg)"/>{paths}</svg>'
(R/'store/ColoringPages_Icon.svg').write_text(svg)
raw=cairosvg.svg2png(bytestring=svg.encode(),output_width=512,output_height=512)
import io
im=Image.open(io.BytesIO(raw)).convert('RGB');im.save(R/'store/ColoringPages_Icon_512.png')
brand=R/'app/src/main/res/drawable-nodpi';brand.mkdir(exist_ok=True);im.resize((256,256),Image.Resampling.LANCZOS).save(brand/'brand_mark.png')
ns='http://schemas.android.com/apk/res/android';E.register_namespace('android',ns)
def a(k):return '{'+ns+'}'+k
v=E.Element('vector',{a('width'):'108dp',a('height'):'108dp',a('viewportWidth'):'768',a('viewportHeight'):'768'})
g=E.SubElement(v,'group',{a('translateX'):'128',a('translateY'):'128'})
for d,c,dy in shapes:
 parent=E.SubElement(g,'group',{a('translateY'):str(dy)}) if dy else g
 E.SubElement(parent,'path',{a('fillColor'):c,a('pathData'):d})
p=R/'app/src/main/res/drawable';E.ElementTree(v).write(p/'ic_launcher_foreground.xml',encoding='utf-8',xml_declaration=True)
(p/'ic_launcher_background.xml').write_text('<shape xmlns:android="http://schemas.android.com/apk/res/android"><gradient android:angle="315" android:startColor="#33B49B" android:endColor="#117D77"/></shape>')
for folder,size in [('mipmap-mdpi',48),('mipmap-hdpi',72),('mipmap-xhdpi',96),('mipmap-xxhdpi',144),('mipmap-xxxhdpi',192)]:
 p=R/'app/src/main/res'/folder;p.mkdir(exist_ok=True)
 for name in ['ic_launcher','ic_launcher_round']:im.resize((size,size),Image.Resampling.LANCZOS).save(p/(name+'.png'))
p=R/'app/src/main/res/mipmap-anydpi-v26'
for name in ['ic_launcher','ic_launcher_round']:(p/(name+'.xml')).write_text('<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android"><background android:drawable="@drawable/ic_launcher_background"/><foreground android:drawable="@drawable/ic_launcher_foreground"/></adaptive-icon>')
(R/'app/src/main/res/values/colors.xml').write_text('<resources><color name="launcher_background">#168575</color></resources>')
print('Generated original palette icon in all Android densities')
