"""24 additional original, richer compositions. Does not modify the original 48 IDs."""
from generate_art import Scene,ellipse,poly,rounded,star,regular,leaf
from shapely.geometry import box
from shapely.ops import unary_union
from shapely.affinity import rotate
from math import sin,cos,pi
from pathlib import Path
from PIL import Image,ImageDraw
import json
R=Path(__file__).resolve().parents[1]
SC=[]
def new(cat,n,titles):
 s=Scene(cat+'_'+str(n).zfill(2),cat,titles,'hard' if n in [10,12] else 'medium');SC.append(s);return s
def sky(s):s.rect(65,65,870,870,3,60);s.disk(780,205,75,0);s.cloud(270,180,.65)
def ground(s,c=4):s.add(ellipse(500,870,580,180),c)
def bloom(s,x,y,k,c=1):s.plant(x,y,k,c,7)
def fence(s,y):
 for x in range(130,900,80):s.rect(x,y,25,130,5,7)
 s.rect(110,y+25,780,20,0,5)
def cottage(s,x,y,k,c=5):
 s.rect(x-120*k,y,240*k,210*k,c,12*k).polygon([(x-155*k,y),(x,y-145*k),(x+155*k,y)],2)
 s.rect(x-27*k,y+100*k,54*k,110*k,6,22*k)
 for dx in [-77,45]:s.rect(x+dx*k,y+35*k,38*k,55*k,3,9*k)
def waves(s,y):
 for row in range(3):
  for col in range(4):s.oval(170+col*220+(row%2)*45,y+row*62,65,10,7 if row%2 else 6)
# Botanical compositions
s=new('flowers',9,('Blossom bouquet','باقة الأزهار','Buquê de flores'))
s.oval(500,875,360,48,6)
for x,y,k,c in [(290,400,.75,1),(700,425,.75,2),(390,270,.85,6),(600,260,.86,1),(510,465,.8,0)]:bloom(s,x,y,k,c)
s.polygon([(320,650),(680,650),(625,890),(375,890)],3).rect(315,630,370,45,7,18)
for x in [385,465,545]:s.rect(x,710,48,110,6,18)
s.star(180,270,26,0,4).star(815,310,26,1,4)
s=new('flowers',10,('Glasshouse morning','صباح الدفيئة','Manhã na estufa'))
s.rect(115,250,770,630,3,25).polygon([(100,280),(500,80),(900,280)],6)
for x in [120,360,610,860]:s.rect(x,275,20,600,7,8)
for y in [420,670]:s.rect(120,y,760,20,7,6)
for x,y,k,c in [(235,490,.47,1),(490,420,.58,0),(740,500,.48,2)]:
 bloom(s,x,y,k,c);s.polygon([(x-75,650),(x+75,650),(x+55,770),(x-55,770)],5)
s.rect(100,780,800,45,5,12).rect(130,835,45,90,2,8).rect(825,835,45,90,2,8)
s=new('flowers',11,('Succulent studio','مرسم الصبّار','Ateliê de suculentas'))
for row in range(2):
 y=430+row*390;s.rect(95,y+55,810,32,5,12)
 for col in range(3):
  x=230+col*270
  if (row+col)%2:
   for angle in [-55,0,55]:s.add(leaf(x+45*sin(angle*pi/180),y-155,38,125,angle),4 if col!=1 else 3)
  else:
   s.rect(x-40,y-255,80,225,4,40).rect(x-95,y-170,70,40,4,17).rect(x+20,y-210,70,40,4,17)
   s.star(x,y-255,30,1,6)
  s.polygon([(x-80,y-55),(x+80,y-55),(x+60,y+55),(x-60,y+55)],(col+row+1)%7)
  s.rect(x-86,y-66,172,22,0,8)
s=new('flowers',12,('Garden archway','قوس الحديقة','Arco do jardim'))
s.add(ellipse(500,485,345,360).union(box(155,460,845,900)).difference(ellipse(500,495,260,275).union(box(240,485,760,930))),5)
for x in [285,395,505,615,725]:s.rect(x,550,22,340,6,8)
for y in [670,800]:s.rect(250,y,500,24,6,8)
for x,y,k,c in [(170,460,.55,1),(290,235,.55,2),(520,150,.6,1),(750,260,.5,0),(825,500,.55,2)]:bloom(s,x,y,k,c)
s.rect(120,900,760,25,4,10)
# Scenic art with layered foregrounds
s=new('nature',9,('Sunset valley','وادي الغروب','Vale ao pôr do sol'));sky(s)
s.disk(565,400,140,0)
s.polygon([(65,670),(260,260),(520,700)],6).polygon([(320,730),(690,280),(935,690)],2)
s.polygon([(587,413),(690,280),(785,445),(710,410),(678,457),(645,420)],0)
ground(s);s.polygon([(560,640),(640,650),(770,935),(300,935)],3)
cottage(s,260,660,.62);s.pine(800,700,.55)
for x,y in [(135,845),(770,880),(850,845)]:bloom(s,x,y,.2,1)
s=new('nature',10,('Beach daydream','أحلام الشاطئ','Sonho de praia'));sky(s)
s.rect(65,510,870,370,3,15).polygon([(65,700),(400,620),(935,730),(935,935),(65,935)],0)
s.rect(395,430,20,320,5,6)
for i in range(5):
 a=pi+i*pi/5;b=a+pi/5;s.polygon([(405,460),(405+240*cos(a),460+190*sin(a)),(405+240*cos(b),460+190*sin(b))],i%3)
s.rect(265,770,430,110,1,18)
for x in [295,395,495,595]:s.rect(x,775,38,100,6,9)
s.add(ellipse(760,690,90,95).difference(ellipse(760,680,58,60)),5).rect(665,710,190,110,5,15).rect(665,738,190,18,0)
s=new('nature',11,('Riverside meadow','مرج النهر','Campo à beira-rio'));sky(s);ground(s)
s.polygon([(480,470),(575,470),(680,935),(220,935)],3)
s.rect(170,400,60,380,5,14)
for x,y,rx,ry in [(180,340,130,160),(270,400,110,140),(100,460,80,100)]:s.oval(x,y,rx,ry,4)
s.pine(810,625,.65)
for x,y in [(300,780),(405,840),(510,890)]:s.oval(x,y,60,24,7)
for x,y,c in [(690,730,1),(800,830,6),(130,850,0)]:bloom(s,x,y,.27,c)
s=new('nature',12,('Midnight mountain','جبال الليل','Montanhas à meia-noite'))
s.rect(65,65,870,870,7,60)
for i in range(4):s.polygon([(80+i*200,120),(190+i*200,90),(590+i*110,600),(490+i*110,640)],4 if i%2 else 3)
s.disk(770,240,75,0)
s.polygon([(65,800),(280,350),(610,865)],6).polygon([(340,840),(710,320),(935,790)],2)
s.polygon([(213,465),(280,350),(372,495),(300,465)],3).oval(520,910,500,105,3)
cottage(s,520,730,.62)
for x,y in [(180,160),(380,200),(610,120),(870,480)]:s.star(x,y,22,0,4)
# Journeys, vehicles and construction. No characters.
s=new('vehicles',9,('Paintbox camper','حافلة صندوق الألوان','Van das cores'));sky(s);ground(s)
s.polygon([(70,650),(300,350),(560,650)],6).polygon([(520,640),(770,370),(935,620)],4)
s.rect(145,430,710,350,1,70).rect(145,600,710,155,5,30)
s.windows(195,470,3,1,120,105,65)
s.rect(300,330,350,85,2,24)
for x in [340,570]:s.rect(x,325,18,100,7,7)
s.wheel(310,770,90).wheel(710,770,90).rect(785,660,48,42,0,10)
for x,y in [(115,820),(850,850)]:bloom(s,x,y,.2,6)
s=new('vehicles',10,('Harbour sails','أشرعة الميناء','Velas no porto'));sky(s)
s.rect(65,680,870,255,3,20);waves(s,770)
s.polygon([(180,620),(810,620),(690,755),(300,755)],5).rect(465,200,20,430,7,8)
s.polygon([(450,220),(450,580),(170,580)],1).polygon([(500,280),(500,580),(755,580)],0)
for y in [420,495]:s.polygon([(500,y),(500,y+25),(625+(y-420)*.6,y+25),(603+(y-420)*.6,y)],6)
for x in [360,480,600]:s.disk(x,670,26,7).disk(x,670,16,3)
s.rect(90,440,40,240,2,8).rect(860,470,35,220,2,8)
s=new('vehicles',11,('Rainbow railway','سكة الألوان','Ferrovia do arco-íris'));sky(s);ground(s)
s.rect(65,795,870,32,5,10)
for x in range(110,920,90):s.rect(x,825,45,45,7,5)
s.rect(140,500,340,230,2,25).rect(365,330,165,380,1,18).rect(335,315,220,35,0,10).windows(390,370,1,1,100,110)
s.rect(190,390,50,120,5,8).cloud(200,300,.5)
s.rect(570,480,300,240,4,25).rect(550,455,340,35,0,10).windows(600,520,3,1,60,85,25)
for x in [220,400,620,820]:s.wheel(x,735,63)
s=new('vehicles',12,('Warehouse colours','ألوان المستودع','Cores do armazém'))
s.rect(80,100,840,770,3,35)
for x in [110,670]:
 s.rect(x,210,220,150,5,10).rect(x+20,210,35,150,0).rect(x+165,210,35,150,0)
 s.rect(x,380,220,150,5,10).rect(x+20,380,35,150,0).rect(x+165,380,35,150,0)
s.rect(110,560,780,25,7,5)
s.rect(240,625,330,155,0,25).rect(355,360,160,260,2,15).rect(370,380,125,210,3,10)
s.rect(600,345,35,445,7,6).rect(630,760,230,25,7,6).rect(600,560,35,25,7)
s.wheel(310,785,75).wheel(530,790,65).rect(680,635,140,120,1,7)
# Places
s=new('buildings',9,('Storybook village','قرية الحكايات','Vila de histórias'));sky(s);ground(s)
s.polygon([(400,935),(570,935),(590,710),(520,610),(485,700)],5)
cottage(s,280,500,.85,1);cottage(s,700,560,.85,0);cottage(s,505,320,.68,6)
s.pine(115,670,.4).pine(855,680,.5)
for x,y in [(350,820),(660,830)]:bloom(s,x,y,.24,2)
s=new('buildings',10,('Grand courtyard','الفناء الكبير','Grande pátio'));sky(s);ground(s)
s.rect(200,430,600,380,5,12)
for x in [250,500,750]:
 s.rect(x-65,250,130,550,6,12).add(ellipse(x,260,90,95).intersection(box(x-100,150,x+100,270)),2)
 for y in [340,480]:s.rect(x-28,y,56,88,3,23)
s.rect(440,630,120,185,2,50).rect(135,820,730,35,0,12)
s.oval(500,890,210,45,3).rect(490,780,20,110,7,8).oval(500,800,115,25,3).disk(500,756,22,0)
s=new('buildings',11,('Little bookshop','مكتبة الحي','Pequena livraria'))
s.rect(200,170,600,670,5,25).rect(260,220,480,110,6,18)
for x in [300,400,500,600]:s.rect(x,240,45,70,(x//100)%4,5)
s.rect(240,410,520,350,3,10).rect(465,460,130,370,2,22).rect(480,480,100,190,3,8)
for i in range(6):s.rect(200+i*100,350,100,90,1 if i%2 else 0,13)
for row in range(2):
 for col in range(4):s.rect(265+col*42,540+row*100,28,70,(row+col)%6,5)
s.rect(230,840,540,30,7,10)
for x in [145,850]:bloom(s,x,620,.42,1);s.rect(x-55,760,110,100,6,15)
s=new('buildings',12,('Lighthouse bay','خليج المنارة','Baía do farol'));sky(s)
s.rect(65,660,870,275,3,20);waves(s,750)
s.polygon([(170,780),(270,570),(610,600),(740,800)],5)
s.polygon([(320,705),(375,270),(535,270),(595,705)],1)
for y in [400,565]:s.polygon([(358-(y-400)*.13,y),(554+(y-400)*.13,y),(563+(y-400)*.13,y+55),(351-(y-400)*.13,y+55)],0)
s.rect(360,210,190,100,3,8).polygon([(335,215),(455,110),(575,215)],2).rect(330,310,250,25,7,6).rect(425,590,60,115,2,26)
cottage(s,690,650,.5)
# Space
s=new('space',9,('Cosmic postcard','بطاقة من الفضاء','Cartão do cosmos'))
s.rect(65,65,870,870,7,60)
for x,y,r,c in [(775,230,120,6),(200,720,95,3),(745,790,115,4)]:s.disk(x,y,r,c)
s.add(rotate(ellipse(745,790,185,33).difference(ellipse(745,790,140,16)),-25,origin=(745,790)),0)
s.rect(360,300,240,400,1,90).polygon([(360,350),(480,130),(600,350)],2)
s.polygon([(360,530),(260,730),(360,690)],6).polygon([(600,530),(700,730),(600,690)],6)
s.disk(480,430,78,0).disk(480,430,52,3).polygon([(400,720),(480,905),(560,720)],0).polygon([(437,720),(480,835),(523,720)],5)
for x,y in [(170,200),(250,390),(810,500),(680,100),(880,650)]:s.star(x,y,28,0,4)
s=new('space',10,('Moon observatory','مرصد القمر','Observatório lunar'))
s.rect(65,65,870,870,7,60).disk(775,205,100,0).disk(800,190,28,5)
s.oval(500,895,520,180,6)
s.rect(260,560,440,250,3,18).add(ellipse(480,560,220,220).intersection(box(200,250,740,560)),2)
s.rect(460,350,42,210,6,12).rect(225,555,510,30,0,10).windows(315,640,3,1,65,95,65)
s.polygon([(680,480),(805,330),(850,360),(730,510)],0).rect(675,500,25,220,5,8)
for x,y in [(150,220),(360,155),(620,220),(820,600)]:s.star(x,y,25,0,4)
s=new('space',11,('Orbit garden','حديقة المدارات','Jardim de órbitas'))
s.rect(65,65,870,870,7,60)
for x,y,r,c in [(300,300,150,1),(720,340,130,3),(420,730,185,6)]:
 s.add(rotate(ellipse(x,y,r*1.4,r*.38).difference(ellipse(x,y,r*1.15,r*.2)),-25,origin=(x,y)),0)
 s.disk(x,y,r,c);s.disk(x-r*.3,y-r*.2,r*.24,c+2)
for x,y in [(150,580),(550,135),(840,730),(230,900),(740,560)]:s.star(x,y,30,4,5)
s=new('space',12,('Shooting-star sky','سماء الشهب','Céu de estrelas cadentes'))
s.rect(65,65,870,870,2,60)
for x,y in [(260,270),(650,500),(400,780)]:
 s.polygon([(x-20,y-30),(x+260,y-160),(x+120,y+10)],3).polygon([(x-10,y+5),(x+245,y-80),(x+145,y+50)],6).star(x,y,90,0,5)
s.disk(755,220,105,1).add(ellipse(755,220,165,35).difference(ellipse(755,220,120,15)),4)
for x,y in [(150,560),(780,800),(520,160),(840,580),(180,870)]:s.star(x,y,25,5,4)
# Pattern studio
s=new('geometric',9,('Bloom mandala','مندالا الزهور','Mandala em flor'))
for radius,n,rx,ry in [(330,12,95,50),(215,12,95,42),(108,8,66,34)]:
 for i in range(n):
  a=2*pi*i/n;x=500+radius*cos(a);y=500+radius*sin(a)
  s.add(rotate(ellipse(x,y,rx,ry),a*180/pi,origin=(x,y)),(i+int(radius/100))%7)
s.star(500,500,75,0,8).disk(500,500,35,1)
s=new('geometric',10,('Moroccan mosaic','الزخرفة المغربية','Mosaico marroquino'))
for row in range(3):
 for col in range(3):
  x=215+col*285;y=215+row*285
  s.add(regular(x,y,140,4,0),(row+col)%7).star(x,y,118,(row+col+2)%7,8).add(regular(x,y,56,8),(row*2+col)%7)
s=new('geometric',11,('Rainbow petals','بتلات قوس الألوان','Pétalas do arco-íris'))
for row in range(4):
 for col in range(4):
  x=170+col*220;y=170+row*220
  s.add(rotate(ellipse(x,y,98,50),45 if (row+col)%2 else -45,origin=(x,y)),(row+col)%7)
  s.disk(x,y,25,(row+col+3)%7)
s=new('geometric',12,('Crystal garden','حديقة البلّور','Jardim de cristais'))
for x,y,k,c in [(280,300,1.1,2),(685,240,.9,3),(530,620,1.2,1),(200,760,.65,4),(820,745,.7,6)]:
 pts=[(x,y-160*k),(x+100*k,y-60*k),(x+80*k,y+120*k),(x,y+180*k),(x-90*k,y+100*k),(x-110*k,y-60*k)]
 for i in range(6):s.polygon([(x,y),pts[i],pts[(i+1)%6]],c+i%3)
for x,y in [(510,165),(125,510),(850,480)]:s.star(x,y,30,0,4)
if __name__=='__main__':
 catalog=json.loads((R/'app/src/main/assets/catalog.json').read_text());old=[a for a in catalog if int(a['id'].split('_')[-1])<=8]
 added=[s.build() for s in SC]
 # New work leads the collection. Original IDs and geometry remain unchanged for saved art.
 catalog=added+old
 (R/'app/src/main/assets/catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2))
 sheet=Image.new('RGB',(6*240,4*265),'#FFFCF7');d=ImageDraw.Draw(sheet)
 for i,a in enumerate(added):
  im=Image.open(R/'store/art-previews'/(a['id']+'.png')).convert('RGB').resize((225,225));x=(i%6)*240+7;y=(i//6)*265
  sheet.paste(im,(x,y));d.text((x,y+230),a['titles']['en'],fill='#283C47')
 sheet.save(R/'store/new-artworks-contact-sheet.jpg',quality=93)
 print('Catalogue:',len(catalog),'new:',len(added),'regions:',sum(a['regionCount'] for a in catalog))
