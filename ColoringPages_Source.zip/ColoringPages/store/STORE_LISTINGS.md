# Store listings · 1.1.0

## English (UK)

**Name:** Coloring Pages

**Short description:** Colour 72 original pictures by number or freely, with offline saving.

**Long description**

A little colour, a lot of wonder. Coloring Pages gives children and families a calm place to create, with 72 original pictures ready to use without an internet connection.

Explore six collections: Flowers & Gardens, Nature & Landscapes, Vehicles & Machines, Buildings & Architecture, Space & Stars and Geometric Art. Choose large, simple areas or more detailed patterns.

In Colour by Number, choose a numbered colour and tap a matching area. Matching areas are highlighted, a hint helps find the next one, and the progress bar follows the areas you have actually coloured. In Free Colour, choose your own colours and make the picture your own. Each mode keeps its own saved picture.

Pinch to zoom into small details, drag to move around the page, and use Undo or Redo whenever you change your mind. Colours and editing history are saved on your device so you can close the app and return later.

A local daily challenge offers a picture selected from the included collection. There are no timers or advertising requirements. Finished artwork appears in your personal gallery, and you can export a clean PNG image through Android’s file picker.

The parent area contains language, light/dark appearance, optional non-musical click sounds, privacy information and local data deletion. The interface is available in English (UK), Arabic with right-to-left support, and Portuguese (Brazil).

This version contains no adverts, purchases, accounts, chat, analytics or music. The pictures feature plants, landscapes, buildings, vehicles, space objects and geometric patterns, with no people or animals. Core play works offline.

**Keywords:** colouring pages, colour by number, offline colouring, free colouring, geometric art, creative play

## العربية

**الاسم:** رسومات تلوين للأطفال

**الوصف القصير:** لوّن ٧٢ رسمة أصلية بالأرقام أو بحرية، مع حفظ التقدّم والعمل دون إنترنت.

**الوصف الطويل**

ألوان صغيرة وفرحة كبيرة. يمنح تطبيق رسومات تلوين للأطفال الطفل والعائلة مساحة هادئة للإبداع، مع ٧٢ رسمة أصلية متاحة دون اتصال بالإنترنت.

استكشف ست مجموعات: الزهور والحدائق، الطبيعة والمناظر، المركبات والآلات، المباني والعمارة، الفضاء والنجوم، والفنون الهندسية. اختر مناطق كبيرة وبسيطة أو لوحات أكثر تفصيلًا.

في وضع التلوين بالأرقام، اختر لونًا مرقّمًا واضغط المنطقة التي تحمل الرقم المطابق. يساعدك تمييز المناطق والتلميح على إيجاد الجزء التالي، ويحسب شريط التقدّم المناطق الملوّنة فعلًا. وفي وضع التلوين الحر، اختر ألوانك بنفسك. يحتفظ كل وضع برسمة محفوظة مستقلة.

كبّر اللوحة بإصبعين لرؤية التفاصيل، واسحب للتحريك، واستخدم التراجع والإعادة عند تغيير رأيك. تُحفظ الألوان وسجلّ التعديلات على الجهاز لتعود لاحقًا وتكمل من حيث توقفت.

يقدّم تحدّي اليوم لوحة مختارة محليًا من الرسومات المدمجة، دون مؤقّت أو اشتراط مشاهدة إعلان. تجد أعمالك في معرض رسوماتي، ويمكنك حفظ نسخة PNG نظيفة بواسطة منتقي ملفات Android.

تحتوي منطقة الوالدين على اختيار اللغة والمظهر الفاتح أو الداكن ومؤثرات نقر اختيارية غير موسيقية وسياسة الخصوصية وحذف التقدّم المحلي. يدعم التطبيق العربية باتجاه صحيح والإنجليزية البريطانية والبرتغالية البرازيلية.

لا يتضمّن هذا الإصدار إعلانات أو مشتريات أو حسابات أو دردشة أو تحليلات أو موسيقى. تقتصر الرسومات على النباتات والطبيعة والمباني والمركبات والفضاء والزخارف الهندسية، دون أشخاص أو حيوانات. تعمل تجربة التلوين الأساسية دون إنترنت.

**الكلمات المفتاحية:** رسومات تلوين، تلوين بالأرقام، تلوين دون إنترنت، تلوين حر، زخارف هندسية، ألعاب إبداعية

## Português (Brasil)

**Nome:** Desenhos para Colorir

**Descrição curta:** Pinte 72 desenhos originais por números ou livremente, mesmo sem internet.

**Descrição longa**

Um pouco de cor, muita imaginação. Desenhos para Colorir oferece às crianças e às famílias um espaço tranquilo para criar, com 72 desenhos originais disponíveis sem conexão com a internet.

Explore seis coleções: Flores e Jardins, Natureza e Paisagens, Veículos e Máquinas, Construções e Arquitetura, Espaço e Estrelas e Arte Geométrica. Escolha áreas grandes e simples ou padrões mais detalhados.

No modo Por Números, escolha uma cor numerada e toque na área correspondente. As áreas compatíveis ficam destacadas, a dica ajuda a encontrar a próxima e a barra de progresso acompanha as áreas realmente coloridas. No modo Cores Livres, use suas próprias combinações. Cada modo mantém um desenho salvo separado.

Use o gesto de pinça para ampliar detalhes, arraste para mover a página e use Desfazer ou Refazer quando mudar de ideia. As cores e o histórico de edição ficam salvos no dispositivo para você fechar o app e continuar depois.

O desafio diário escolhe localmente uma imagem da coleção incluída. Não há cronômetro nem exigência de assistir a anúncios. Suas obras aparecem na galeria, e você pode exportar uma imagem PNG pelo seletor de arquivos do Android.

A Área dos Responsáveis reúne idioma, aparência clara ou escura, cliques opcionais sem música, política de privacidade e exclusão do progresso local. A interface está disponível em português do Brasil, inglês do Reino Unido e árabe com suporte da direita para a esquerda.

Esta versão não contém anúncios, compras, contas, chat, análises ou música. Os desenhos apresentam plantas, paisagens, construções, veículos, objetos espaciais e padrões geométricos, sem pessoas ou animais. A experiência principal funciona sem internet.

**Palavras-chave:** desenhos para colorir, colorir por números, colorir sem internet, cores livres, arte geométrica, criatividade
