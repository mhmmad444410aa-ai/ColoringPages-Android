# Screenshot provenance

All numbered screenshots in rendered-screenshots are captured from the actual Compose app, rendered using Robolectric 4.16 native Android graphics at API 29. They are not physical-device or Android emulator screenshots. Their pixels are not retouched; only the fully opaque alpha channel is removed for store-compatible RGB PNG output.

Motion frames come from the same running app with its Compose test clock manually advanced. The GIF is a preview assembled from those native UI frames, not a phone recording.
