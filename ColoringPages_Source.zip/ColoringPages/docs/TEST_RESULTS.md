# Validation · 1.1.0

31 automated tests passed, zero failures/errors. Full build and lint passed. Android Lint: zero errors, 41 warnings. An additional rerun verifies eight distinct native UI animation frames and the motion-off preference. See test-evidence for exact XML and build output.

The APK signature, archive CRC, artwork hashes and 16KB library alignment passed. UI screenshots are native Robolectric API-29 renders of the actual Compose app. No physical-device or emulator APK installation is claimed.

Language regression: a fresh Arabic-device configuration starts in English, all three choices are visible, Arabic applies RTL, Portuguese strings and free colouring work, and selection persists after recreation. Old drawing IDs/paths remain unchanged.
