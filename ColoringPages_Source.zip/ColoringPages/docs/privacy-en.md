# Privacy policy

Last updated: 13 November 2026

Coloring Pages is an offline colouring app for children and families. We do not collect, transmit, sell or share personal data. There are no accounts, analytics, tracking, advertising SDKs, purchases, chat or cloud services. The app has no internet, location, camera, microphone or storage permissions.

Saved colours, undo history, completion dates and daily challenge history are kept in the app’s private Room database. Language, appearance and click settings are stored locally with AndroidX DataStore. AndroidX Compose, AppCompat and Android platform libraries provide the interface; they are not analytics or advertising services. Android app backup is disabled.

Exporting a drawing opens the Android file picker. The image is written only to the location chosen by the adult or child; a chosen cloud provider may process it under its own policy. No image is sent by this app to our servers. Exported images contain the drawing only, with no added name, location or child identifier.

A parent may delete all local progress from the Parent area. Exported files and files retained by a document provider must be deleted separately through that provider. Uninstalling removes private app data. The parent gate is a convenience barrier, not identity or age verification.

For support, contact the developer through the contact details on the store listing. Store operators and your device software may process data separately under their own policies.