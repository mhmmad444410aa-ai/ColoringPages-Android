Atualizado em 14 de novembro de 2026

O Desenhos para Colorir guarda o progresso localmente e funciona offline para colorir, mas anúncios exigem internet. Após autorização do responsável, Huawei Petal Ads pode apresentar anúncios não personalizados para crianças. O SDK pode processar informações do dispositivo, rede e eventos de publicidade segundo seus termos. Não pedimos localização precisa e definimos sinalização infantil, menores de idade, classificação geral e anúncios não personalizados. Os desenhos não são compartilhados com o serviço de publicidade.

O progresso e as preferências ficam armazenados localmente. Imagens PNG são exportadas apenas para o provedor de documentos escolhido no Android. O backup está desativado. O responsável pode apagar o progresso e retirar a autorização para anúncios na área dos responsáveis. O jogo funciona sem autorização.

Consulte a política de privacidade publicada e a declaração de privacidade da Huawei Petal Ads; para suporte, veja o contato na loja.