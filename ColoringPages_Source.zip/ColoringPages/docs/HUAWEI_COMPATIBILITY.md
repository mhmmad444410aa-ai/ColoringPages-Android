# Huawei AppGallery compatibility — proposed 1.2.0

Huawei Petal Ads SDK is now integrated in the SOURCE. This is unbuilt and requires SDK validation, actual-device testing and updated public privacy policy. See HUAWEI_ADS_RELEASE_CHECKLIST.md. Never submit the 1.1.0 APK expecting this source modification to be present in that APK.
