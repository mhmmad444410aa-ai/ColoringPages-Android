Last updated: 14 November 2026

Coloring Pages keeps colouring progress locally and works offline for drawing, but advertising requires internet access. Following parental acknowledgement, Huawei Petal Ads may serve child-directed non-personalised ads. Ads SDK may process limited device and network data and advertising events under its privacy terms. We request no precise location and set child-protection, under-age, general-audience and non-personalised request flags. No saved artwork is transmitted to the advertising service.

We store coloured regions, completion history and local preferences in private Android storage. Exported PNG images go only to the Android document provider you choose. Backups are disabled. The adult can delete local colouring progress in the Parents area and withdraw advertising agreement there. The game remains usable without consent.

See the published privacy policy and Huawei Petal Ads privacy statement for details. Contact the developer through the store listing.