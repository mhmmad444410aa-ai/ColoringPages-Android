# Test signing continuity

The 1.1.0 APK is signed with a new Android Debug certificate (SHA-256 9229243969c8e3f9cb2aa0af5777109f289b853cc8b59e2fd3ea4ca9b0cbe631). It cannot update the separately signed 1.0.0 test APK in place. Export desired pictures before removing that older test installation. Uninstalling deletes its private progress.

The current test keystore is retained as a separate private file named ColoringPages_Test_Signing_Key.jks, outside this source archive. Reuse it for later test APKs. It is an Android Debug key, not a production release key, and must not be committed to a public repository. Store release signing still requires a production keystore.
