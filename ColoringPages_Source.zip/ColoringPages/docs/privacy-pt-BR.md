# Política de privacidade

Última atualização: 13 de novembro de 2026

Desenhos para Colorir é um aplicativo de colorir sem internet para crianças e famílias. Não coletamos, transmitimos, vendemos nem compartilhamos dados pessoais. Não há contas, análises, rastreamento, SDKs de publicidade, compras, chat ou serviços em nuvem. O app não solicita permissões de internet, localização, câmera, microfone ou armazenamento.

Cores salvas, histórico de desfazer, datas de conclusão e desafios diários ficam no banco Room privado do app. Idioma, aparência e sons de clique são armazenados localmente com AndroidX DataStore. Compose, AppCompat e bibliotecas Android fornecem a interface; não são serviços de análise ou publicidade. O backup de dados do app está desativado.

Ao exportar um desenho, o seletor de arquivos do Android é aberto. A imagem é gravada apenas no local escolhido. Um provedor de nuvem escolhido pode processá-la segundo sua própria política. Este app não envia a imagem aos nossos servidores. A imagem contém apenas o desenho, sem adicionar nome, localização ou identificador da criança.

Um adulto pode apagar o progresso na Área dos responsáveis. Arquivos exportados e cópias mantidas por provedores devem ser apagados separadamente. A desinstalação remove os dados privados. A barreira para adultos é uma conveniência, não uma verificação de identidade ou idade.

Para suporte, use os dados de contato do desenvolvedor na página da loja. A loja e o software do dispositivo podem processar dados separadamente, conforme suas próprias políticas.