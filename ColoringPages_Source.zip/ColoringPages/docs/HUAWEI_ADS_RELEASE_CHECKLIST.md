# Coloring Pages 1.2.0 — Huawei Petal Ads integration / pre-release checklist

- Bundle `com.huawei.hms:ads-lite:13.4.91.300` via the Huawei Maven repository.
- Banner ID: `k1i3em3bm0`; interstitial ID: `s9jruxhcil`.
- All requests flagged: COPPA child-directed, under age of consent, non-personalised, W rating, requestLocation(false).
- Child-directed banners: home/gallery/artwork browsing pages, away from canvas controls.
- Interstitial: only after completion + request for another picture, max one per 4 completions and minimum 5 minutes between shown ads.
- No ads requested or SDK initialisation before a parent acknowledges privacy terms; parent can decline and play remains available.
- No regular user-facing settings switch to show/hide advertisements; parental re-review exists for legal compliance.
- CHECK BEFORE ANY RELEASE: update the public privacy policy URL because its currently published text describes a no-ad app.
- CHECK BEFORE ANY RELEASE: verify third-party ad-category blocking, parental consent rules and children-related AppGallery declarations; test on actual Huawei device.
- CHECK BEFORE ANY RELEASE: Gradle build + tests + signed APK + apksigner certificate comparison against release 1.1.0. Build was NOT executed by this patch environment.
- This ZIP is SOURCE CODE, not APK. No signing secrets are included.
