# فتح المشروع وبناؤه

الحزمة: com.mhmmad.coloringpages. ملف APK الحالي Debug للتجربة.

## Android Studio

فك أرشيف المصدر وافتح مجلد ColoringPages نفسه. اختر JDK 17 وثبّت Android SDK 36 وBuild Tools 36.0.0. نفّذ `./gradlew assembleDebug`؛ على Windows استخدم `gradlew.bat assembleDebug`. لا يلزم Python لبناء التطبيق؛ ملفات الرسومات الجاهزة مضمّنة بالفعل.

## GitHub العام

أنشئ مستودع Public فارغًا باسم ColoringPages في حسابك. ارفع محتويات مجلد المشروع إلى جذر المستودع، بما فيها مجلد .github وGradle Wrapper. لا ترفع ملف ZIP فقط بدل فك محتوياته. لا ترفع أي keystore أو كلمة مرور. عند إتاحة المستودع في الحساب المرتبط يمكن رفع المصدر إليه بالأدوات المخصّصة.

ملف Actions جاهز لتجميع Debug وفحصه ورفع APK ضمن Artifacts. لم يُشغّل على GitHub في جلسة التسليم الحالية. ينشئ Job الإصدار الموقّع فقط إذا وُجدت الأسرار الأربعة المبيّنة في README. لا ترسل كلمات المرور في المحادثة؛ ضعها في Secrets داخل حساب GitHub.

سياسة الخصوصية منشورة بالفعل: https://coloring-pages-privacy-mhmmad.mhmmad444410aa.chatgpt.site . ضع هذا الرابط في بيانات المتجر. يوجد أيضًا في store/PRIVACY_URL.txt وفي منطقة الوالدين داخل التطبيق.
